import json

import streamlit as st
import dotenv

from recursion_workflow import run_workflow


dotenv.load_dotenv()


# ============================================================
# PAGE
# ============================================================

st.set_page_config(
    page_title="Business Advisor",
    page_icon="💼",
    layout="wide",
)


# ============================================================
# CSS
# ============================================================

st.markdown(
    """
    <style>

    html,
    body,
    [data-testid="stAppViewContainer"],
    [data-testid="stApp"] {
    }


    [data-testid="stAppViewContainer"] > .main {
    }


    .block-container {

        padding-top: 0.5rem !important;
        padding-bottom: 0.5rem !important;

    }


    h1 {

        margin-top: 0 !important;
        margin-bottom: 0.2rem !important;
    }


    [data-testid="stHorizontalBlock"] {

        min-height: 0 !important;

        align-items: stretch !important;
    }


    [data-testid="column"] {

        height: 100% !important;

        min-height: 0 !important;

        display: flex !important;
        flex-direction: column !important;
    }


    [data-testid="column"] > div {

        height: 100% !important;

        min-height: 0 !important;

        max-height: 100% !important;
    }


    [data-testid="column"] [data-testid="stVerticalBlock"] {

        min-height: 0 !important;
    }


    [data-testid="stVerticalBlockBorderWrapper"] {

        min-height: 0 !important;

        max-height: 100% !important;
    }


    [data-testid="stVerticalBlock"] {

        gap: 0.35rem !important;
    }


    textarea {

        resize: none !important;
    }


    [data-testid="stMarkdownContainer"] p {

        margin-bottom: 0.25rem;
    }


    button {

        margin-top: 0 !important;
    }


    [data-testid="stCode"] {

        max-width: 100% !important;

    }


    [data-testid="stCode"] pre {

        white-space: pre-wrap !important;

        word-break: break-word !important;

        max-width: 100% !important;
    }


    [data-testid="stCode"] code {

        white-space: pre-wrap !important;

        word-break: break-word !important;
    }

    </style>
    """,
    unsafe_allow_html=True,
)


# ============================================================
# SESSION STATE
# ============================================================

if "messages" not in st.session_state:
    st.session_state.messages = []


if "needs_input" not in st.session_state:
    st.session_state.needs_input = True


if "agent_logs" not in st.session_state:
    st.session_state.agent_logs = []


if "verified_facts" not in st.session_state:
    st.session_state.verified_facts = []


if "critic_results" not in st.session_state:
    st.session_state.critic_results = []


# ============================================================
# MEMORY / EXECUTION STATE
# ============================================================

if "runtime" not in st.session_state:
    st.session_state.runtime = 0


if "auto_runtime" not in st.session_state:
    st.session_state.auto_runtime = 0


if "problem_stack" not in st.session_state:
    st.session_state.problem_stack = []


if "current_problem_index" not in st.session_state:
    st.session_state.current_problem_index = 0


if "critic_id_counter" not in st.session_state:
    st.session_state.critic_id_counter = 0


if "critic_records" not in st.session_state:
    st.session_state.critic_records = []


if "active_critics" not in st.session_state:
    st.session_state.active_critics = []


if "max_problem_depth" not in st.session_state:
    st.session_state.max_problem_depth = 3


# ============================================================
# TITLE
# ============================================================

st.title("💼 Business Advisor")


# ============================================================
# TWO COLUMNS
# ============================================================

left, right = st.columns(
    [2, 1],
    gap="large",
)


# ============================================================
# LEFT COLUMN
# ============================================================

with left:
    st.subheader("💬 Chat")

    # --------------------------------------------------------
    # PROBLEM DEPTH CONTROL
    # --------------------------------------------------------

    st.number_input(
        "Maximum Problem Depth",
        min_value=0,
        max_value=20,
        value=st.session_state.max_problem_depth,
        step=1,
        key="max_problem_depth",
        help=("Maximum recursive depth allowed for child problems."),
    )

    # --------------------------------------------------------
    # CHAT HISTORY
    # --------------------------------------------------------

    chat_box = st.container(
        height=520,
        border=True,
    )

    with chat_box:
        if not st.session_state.messages:
            st.info("Tell me about your business to begin.")

        else:
            for message in st.session_state.messages:
                if message["role"] == "user":
                    with st.chat_message("user"):
                        st.write(message["content"])

                else:
                    with st.chat_message("assistant"):
                        st.write(message["content"])

    # --------------------------------------------------------
    # INPUT
    # --------------------------------------------------------

    if st.session_state.needs_input:
        user_input = st.text_area(
            "Message",
            placeholder="Tell me about your business...",
            height=65,
            label_visibility="collapsed",
        )

        send = st.button(
            "➤ Send",
            type="primary",
            use_container_width=True,
        )

        # ----------------------------------------------------
        # PROCESS
        # ----------------------------------------------------

        if send:
            if not user_input.strip():
                st.warning("Please enter a message.")

            else:
                user_input = user_input.strip()

                # --------------------------------------------
                # USER STARTS A NEW RUNTIME
                # --------------------------------------------

                st.session_state.runtime += 1

                # A human-started flow always starts
                # with auto_runtime = 0.

                st.session_state.auto_runtime = 0

                # --------------------------------------------
                # SAVE USER MESSAGE
                # --------------------------------------------

                st.session_state.messages.append(
                    {
                        "role": "user",
                        "content": user_input,
                    }
                )

                # --------------------------------------------
                # BUILD HISTORY
                # --------------------------------------------

                history = []

                for message in st.session_state.messages:
                    history.append(
                        (
                            message["role"],
                            message["content"],
                        )
                    )

                # --------------------------------------------
                # RUN WORKFLOW
                # --------------------------------------------

                result = run_workflow(
                    history,
                    verified_facts_memory=(st.session_state.verified_facts),
                    runtime=(st.session_state.runtime),
                    auto_runtime=(st.session_state.auto_runtime),
                    problem_stack=(st.session_state.problem_stack),
                    current_problem_index=(st.session_state.current_problem_index),
                    critic_id_counter=(st.session_state.critic_id_counter),
                    active_critics=(st.session_state.active_critics),
                    max_problem_depth=(st.session_state.max_problem_depth),
                )

                # --------------------------------------------
                # SAVE ASSISTANT RESPONSE
                # --------------------------------------------

                st.session_state.messages.append(
                    {
                        "role": "assistant",
                        "content": result["response"],
                    }
                )

                # --------------------------------------------
                # SAVE AGENT LOGS
                # --------------------------------------------

                st.session_state.agent_logs.extend(result["logs"])

                # --------------------------------------------
                # SAVE VERIFIED FACTS
                # --------------------------------------------

                if result["verified_facts"] is not None:
                    st.session_state.verified_facts.append(
                        result["verified_facts"].model_dump()
                    )

                # --------------------------------------------
                # SAVE CRITIC RESULTS
                # --------------------------------------------

                if result["critic_results"]:
                    st.session_state.critic_results.extend(result["critic_results"])

                # --------------------------------------------
                # SAVE CRITIC RECORDS
                # --------------------------------------------

                if result["critic_records"]:
                    st.session_state.critic_records.extend(result["critic_records"])

                # --------------------------------------------
                # SAVE ACTIVE CRITICS
                # --------------------------------------------

                st.session_state.active_critics = result["active_critics"]

                # --------------------------------------------
                # SAVE PROBLEM STACK
                # --------------------------------------------

                st.session_state.problem_stack = result["problem_stack"]

                # --------------------------------------------
                # SAVE CURRENT PROBLEM INDEX
                # --------------------------------------------

                st.session_state.current_problem_index = result["current_problem_index"]

                # --------------------------------------------
                # SAVE CRITIC ID COUNTER
                # --------------------------------------------

                st.session_state.critic_id_counter = result["critic_id_counter"]

                # --------------------------------------------
                # UPDATE INPUT STATE
                # --------------------------------------------

                st.session_state.needs_input = result["needs_input"]

                # --------------------------------------------
                # RERUN
                # --------------------------------------------

                st.rerun()

    else:
        st.success("The advisor has enough information.")


# ============================================================
# RIGHT COLUMN
# ============================================================

with right:
    st.subheader("🔍 Agent Debug")

    st.caption("Actual LLM input → raw LLM output")

    # --------------------------------------------------------
    # DEBUG HISTORY
    # --------------------------------------------------------

    debug_box = st.container(
        height=620,
        border=True,
    )

    with debug_box:
        if not st.session_state.agent_logs:
            st.info("No agent activity yet.")

        else:
            for index, log in enumerate(st.session_state.agent_logs):
                icon = "🟢" if log["status"] == "SUCCESS" else "🔴"

                latest = index == len(st.session_state.agent_logs) - 1

                with st.expander(
                    (
                        f"{icon} "
                        f"runtime={log.get('runtime')} "
                        f"auto={log.get('auto_runtime')} "
                        f"problem={log.get('problem_id')} "
                        f"| {log['agent']}"
                    ),
                    expanded=latest,
                ):
                    # ----------------------------------------
                    # PROMPT
                    # ----------------------------------------

                    st.markdown("### 📥 Prompt sent to LLM")

                    if isinstance(
                        log["prompt"],
                        list,
                    ):
                        for message in log["prompt"]:
                            role = message.get(
                                "role",
                                "unknown",
                            )

                            content = message.get(
                                "content",
                                "",
                            )

                            st.markdown(f"**{role.upper()}**")

                            st.code(
                                content,
                                language="text",
                            )

                    elif isinstance(
                        log["prompt"],
                        dict,
                    ):
                        st.code(
                            json.dumps(
                                log["prompt"],
                                indent=2,
                                ensure_ascii=False,
                            ),
                            language="json",
                        )

                    else:
                        st.code(
                            str(log["prompt"]),
                            language="text",
                        )

                    # ----------------------------------------
                    # RAW OUTPUT
                    # ----------------------------------------

                    st.markdown("### 📤 Raw LLM Response")

                    if isinstance(
                        log["output"],
                        (dict, list),
                    ):
                        st.code(
                            json.dumps(
                                log["output"],
                                indent=2,
                                ensure_ascii=False,
                            ),
                            language="json",
                        )

                    else:
                        st.code(
                            str(log["output"]),
                            language="text",
                        )

                    # ----------------------------------------
                    # STATUS
                    # ----------------------------------------

                    st.write(f"Status: {log['status']}")

    # ========================================================
    # DOWNLOAD FULL SESSION
    # ========================================================

    st.download_button(
        "⬇️ Download Full Session",
        json.dumps(
            {k: v for k, v in st.session_state.items()},
            indent=2,
            ensure_ascii=False,
            default=str,
        ),
        "full_session.json",
        "application/json",
        use_container_width=True,
    )

    # ========================================================
    # VERIFIED FACTS
    # ========================================================

    if st.button(
        "🧠 Show Verified Facts",
        use_container_width=True,
    ):
        with st.expander(
            "Verified Facts — Raw JSON",
            expanded=True,
        ):
            st.code(
                json.dumps(
                    st.session_state.verified_facts,
                    indent=2,
                    ensure_ascii=False,
                ),
                language="json",
            )

    # ========================================================
    # CRITIC RESULTS
    # ========================================================

    if st.button(
        "🔍 Show Critic Results",
        use_container_width=True,
    ):
        with st.expander(
            "Critic Results — Raw JSON",
            expanded=True,
        ):
            st.code(
                json.dumps(
                    st.session_state.critic_results,
                    indent=2,
                    ensure_ascii=False,
                ),
                language="json",
            )

    # ========================================================
    # PROBLEM STACK
    # ========================================================

    if st.button(
        "🧩 Show Problem Stack",
        use_container_width=True,
    ):
        with st.expander(
            "Problem Stack — Raw JSON",
            expanded=True,
        ):
            st.code(
                json.dumps(
                    {
                        "current_problem_index": (
                            st.session_state.current_problem_index
                        ),
                        "stack": (st.session_state.problem_stack),
                    },
                    indent=2,
                    ensure_ascii=False,
                ),
                language="json",
            )

    # ========================================================
    # CRITIC RECORDS
    # ========================================================

    if st.button(
        "🧾 Show Critic Records",
        use_container_width=True,
    ):
        with st.expander(
            "Critic Records — Raw JSON",
            expanded=True,
        ):
            st.code(
                json.dumps(
                    st.session_state.critic_records,
                    indent=2,
                    ensure_ascii=False,
                ),
                language="json",
            )

    # ========================================================
    # ACTIVE CRITICS
    # ========================================================

    if st.button(
        "⚠️ Show Active Critics",
        use_container_width=True,
    ):
        with st.expander(
            "Active Critics — Raw JSON",
            expanded=True,
        ):
            st.code(
                json.dumps(
                    st.session_state.active_critics,
                    indent=2,
                    ensure_ascii=False,
                ),
                language="json",
            )

    # ========================================================
    # EXECUTION STATE
    # ========================================================

    if st.button(
        "📊 Show Execution State",
        use_container_width=True,
    ):
        with st.expander(
            "Execution State — Raw JSON",
            expanded=True,
        ):
            st.code(
                json.dumps(
                    {
                        "runtime": st.session_state.runtime,
                        "auto_runtime": st.session_state.auto_runtime,
                        "current_problem_index": st.session_state.current_problem_index,
                        "max_problem_depth": st.session_state.max_problem_depth,
                        "critic_id_counter": st.session_state.critic_id_counter,
                    },
                    indent=2,
                    ensure_ascii=False,
                ),
                language="json",
            )

    # ========================================================
    # CLEAR EVERYTHING
    # ========================================================

    if st.button(
        "🗑️ Clear All Memory",
        use_container_width=True,
    ):
        st.session_state.messages = [
            {"role": "user", "content": "i want 100 first customers in my business"},
            {
                "role": "assistant",
                "content": "1. What is your product or service, and who is the ideal customer?\n2. What is the price point and the typical sales cycle (e.g., impulse buy vs. long enterprise deal)?\n3. What resources (budget, team, or existing network) do you have available to acquire these customers?",
            },
            {
                "role": "user",
                "content": "1. i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.\n2. my product avg price point is 2000-4000 tk. and i already told you about typical buyers.\n3. right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
            },
            {
                "role": "assistant",
                "content": "1. Why would a customer buy from your page instead of buying directly from the supplier who already has 50k followers?\n2. Besides posting reels on your own page, what is your plan to get these videos in front of new people without spending money on ads?",
            },
            {
                "role": "user",
                "content": "1. in ocean if a big boat come to catch fish that not mean others boat will not get any fishes, instead the ocean is that much big and huge that if lots of big boat start fishing nothing will be effected. same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.\n2. just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",
            },
            {
                "role": "assistant",
                "content": "1. Do you have the authority to set your own prices, or must you sell at the same price as the supplier?\n2. Can you create your own original photos or videos of the products, or are you 100% dependent on the supplier's reels?",
            },
            {
                "role": "user",
                "content": "1. i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.\n2. nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",
            },
            {
                "role": "user",
                "content": "1. i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.\n2. nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",
            },
            {
                "role": "assistant",
                "content": '**Business Summary**\nYou are reselling home decor showpieces to Bangladeshi women via Facebook, utilizing a supplier\'s content and fulfillment (COD). You are operating as a solo founder with zero budget and no existing network, relying entirely on the supplier\'s reels for marketing.\n\n**The Real Problem**\nYou are a "shadow" of your supplier. Because you are using the same videos and the same prices as a page with 50k followers, you have no **competitive advantage** and no **algorithmic advantage**. Facebook\'s algorithm suppresses duplicate content, and customers have no incentive to trust a new, small page over the established original source.\n\n**Reasoning**\n*   **Algorithm:** Changing background music is not enough to bypass Facebook\'s duplicate content detection. The visual frames remain the same, meaning your reach will remain low.\n*   **Trust Gap:** For products priced at 2,000–4,000 TK, trust is the primary barrier. A customer will not choose a 0-follower page over a 50k-follower page if the product and price are identical.\n*   **Value Proposition:** Your current strategy relies on the "rule of 7-12" (being the last person the customer sees), but this only works if the customer actually *sees* your content first.\n\n**Prioritized Actions**\n\n1.  **Pivot from "Seller" to "Home Stylist"**\n    *   **Action:** Stop reposting raw reels. Use a free editor (like CapCut) to add text overlays that provide "Styling Tips" (e.g., *"3 ways to place this on your dining table to look more elegant"* or *"How to organize your shelf for guests"*).\n    *   **Why:** This transforms the content from a "duplicate ad" into "educational value." It differentiates you from the supplier and gives the customer a reason to follow you for your expertise, not just the product.\n\n2.  **Implement a "First 100" Incentive**\n    *   **Action:** Since profit is not your current goal, create a specific "Founder\'s Offer" for the first 100 customers. This could be a small discount (e.g., 100–200 TK off) or a "Bundle Deal" (negotiate a small free gift from the supplier for bulk buys).\n    *   **Why:** You must give the customer a logical reason to buy from a small page instead of the big one. A lower price or a bonus is the only immediate lever you have.\n\n3.  **High-Intent Community Engagement**\n    *   **Action:** Stop generic group sharing. Join "Home Decor" or "Bangladeshi Women\'s Lifestyle" groups. Instead of posting links, find people asking for home improvement advice. Give them a helpful tip first, then suggest your product as the solution.\n    *   **Why:** Direct selling in groups is often flagged as spam. Providing value first builds the "respect" and "organization" image your target audience craves.\n\n**Assumptions, Risks, and Trade-offs**\n*   **Assumption:** You have the basic technical ability to add text overlays to videos.\n*   **Risk:** The supplier may refuse to lower the price or provide free gifts for your "First 100" offer.\n*   **Trade-off:** This approach requires significantly more time per post than simply changing the music, but it is the only way to gain organic reach without a budget.',
            },
        ]

        st.session_state.needs_input = True

        st.session_state.agent_logs = [
            {
                "agent": "Problem Identifier",
                "runtime": 1,
                "auto_runtime": 0,
                "problem_id": 0,
                "prompt": [
                    {
                        "role": "system",
                        "content": '\nYou are a Problem Identifier.\n\nYour ONLY job is to determine whether the latest user input\nintroduces a NEW business problem or is simply part of the\ncurrent conversation.\n\nYou do NOT solve the problem.\n\nYou do NOT give advice.\n\nYou do NOT rewrite the entire conversation.\n\n============================================================\nCLASSIFICATION\n============================================================\n\nReturn exactly one classification:\n\nPROBLEM\n- The user has introduced a distinct business problem that\n  should become a new item in the problem stack.\n\nQ&A\n- The user is answering an existing question.\n- The user is adding context to the current problem.\n- The user is clarifying something already being discussed.\n- The user is providing additional facts, constraints, goals,\n  preferences, or details without introducing a distinct new\n  problem.\n\n============================================================\nIMPORTANT\n============================================================\n\nA user can mention a difficulty without creating a new problem.\n\nExample:\n\n"I have no marketing experience."\n\nThis is normally context for the current problem, not a new\nproblem by itself.\n\nExample:\n\n"My website gets traffic but nobody buys. I need to fix this."\n\nThis is a distinct problem.\n\nOnly classify as PROBLEM when the input represents a problem\nthat should be solved independently from the current problem.\n\nDo not classify something as a new problem merely because it\ncontains a complaint, difficulty, or question.\n\n============================================================\nPROBLEM FIELD\n============================================================\n\nWhen classification is PROBLEM:\n\n- Extract the problem clearly.\n- Preserve the user\'s meaning.\n- Do not solve it.\n- Do not add causes the user did not state.\n- Keep it concise.\n\nWhen classification is Q&A:\n\n- problem must be null.\n\n============================================================\nOUTPUT\n============================================================\n\nReturn only the structured result defined by the output schema.\n',
                    },
                    {
                        "role": "human",
                        "content": "i want 100 first customers in my business",
                    },
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "text",
                            "text": '{\n  "classification": "PROBLEM",\n  "problem": "Acquire the first 100 customers for the business."\n}',
                            "extras": {
                                "signature": "EnAKbgERTTIPLJWzZ3GzmGK4ceaYQJpclXTFct2uy1Eq+21huOoNHpoK2DICgTwIaBaEaE1A+/iKYgPefDLM1qEc0ws1joE01MCwcHSpWW8DjFNRrxTrKAF5JeK18L2Ga31CSjqFUe9XITR8blPQT/37"
                            },
                        }
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Advisor LLM",
                "runtime": 1,
                "auto_runtime": 0,
                "problem_id": 0,
                "prompt": [
                    {
                        "role": "system",
                        "content": "\nROLE\n\nYou are a senior business advisor.\n\n\nPRIMARY RULE\n\nNever solve a business problem until you have enough context.\n\n\nWORKFLOW\n\nStep 1\n\nDetermine whether enough information exists to give high-confidence advice.\n\nIf NOT:\n\n• Identify only the missing information that could materially change the recommendation.\n• Ask the minimum number of high-value questions.\n• Ask no more than 3 questions in one response.\n• Group related questions together.\n• Do not ask questions that won't affect the strategy.\n• Do not give recommendations yet.\n• Do not explain your reasoning at length.\n• Do not repeat information already established.\n\nKeep the response concise.\n\nRepeat Step 1 until enough context is collected.\n\n\nStep 2\n\nOnce enough context exists:\n\n• Summarize your understanding of the business.\n• Identify the real problem (not just the stated problem).\n• Explain your reasoning.\n• Recommend prioritized actions.\n• Explain why each recommendation fits this business.\n• Mention assumptions, risks, and trade-offs.\n\nKeep the final recommendation focused and practical.\nDo not repeat the entire conversation.\nDo not add unnecessary explanation or filler.\n\n\nOUTPUT DISCIPLINE\n\nWhen asking questions:\n\n• Maximum 3 questions.\n• Ask only questions that can materially change the recommendation.\n• Do not include a long introduction.\n• Do not provide advice.\n• Do not provide a long explanation.\n• Prefer direct questions over paragraphs.\n\nWhen giving the final recommendation:\n\n• Be structured and concise.\n• Include only information relevant to the recommendation.\n• Avoid repeating facts already known unless needed for reasoning.\n• Avoid motivational filler.\n• Avoid generic business advice.\n\n\nRULES\n\n• Never invent business facts.\n• Challenge weak assumptions.\n• Consider industry, competition, customers, budget, stage, resources, and constraints before recommending actions.\n• Prefer fewer high-impact questions over many generic questions.\n• Never ask for information that is already available in the conversation.\n• Never repeat the same question in different wording unless the previous answer was genuinely incomplete.\n• Every sentence must serve the decision-making process.\n\n\nConversation history:\n",
                    },
                    {
                        "role": "human",
                        "content": "i want 100 first customers in my business",
                    },
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "thinking",
                            "thinking": "*   User Goal: Get the first 100 customers.\n    *   Current State: No information provided about the business, product, target audience, budget, or current progress.\n    *   Role: Senior Business Advisor.\n    *   Constraint: Never solve a business problem until enough context is gathered.\n\n    *   Do I have enough information? No.\n    *   What is missing?\n        *   What is the product/service? (B2B vs B2C, high ticket vs low ticket).\n        *   Who is the target customer? (Ideal Customer Profile).\n        *   What is the current stage/traction? (MVP, launched, pre-launch).\n        *   What resources are available? (Budget, team, network).\n\n    *   Question 1: What is your product or service, and who is the ideal customer?\n    *   Question 2: What is the price point and the typical sales cycle (e.g., impulse buy vs. long enterprise deal)?\n    *   Question 3: What resources (budget, team, or existing network) do you have available to acquire these customers?",
                        },
                        {
                            "type": "text",
                            "text": "1. What is your product or service, and who is the ideal customer?\n2. What is the price point and the typical sales cycle (e.g., impulse buy vs. long enterprise deal)?\n3. What resources (budget, team, or existing network) do you have available to acquire these customers?",
                        },
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Verified Facts LLM",
                "runtime": 1,
                "auto_runtime": 0,
                "problem_id": 0,
                "prompt": [
                    {
                        "role": "human",
                        "content": '\nYou are a strict Verified Facts Extraction Agent.\n\nYour job is to identify VERIFIED information from ONLY the evidence provided below.\n\nYou receive exactly three pieces of evidence:\n\n1. HUMAN_MESSAGE_1\n2. HUMAN_MESSAGE_2\n3. ADVISOR_REPLY\n\nSOURCE RULES:\n\n- HUMAN_MESSAGE_1 and HUMAN_MESSAGE_2 are the ONLY sources of user-provided facts.\n- ADVISOR_REPLY is the ONLY source of questions asked by the advisor.\n- Never treat anything written by the advisor as a user fact.\n- Never invent a user answer.\n- Never use older conversation history.\n- Never assume the advisor\'s statements are true.\n- Never convert an advisor suggestion into a verified fact.\n- Never create a question that does not actually appear in ADVISOR_REPLY.\n\nThe user may provide information:\n\n- before the advisor asks about it\n- after the advisor asks about it\n\nBoth are valid.\n\n--------------------------------------------------\nHUMAN MESSAGE 1\n--------------------------------------------------\n\n\n\n--------------------------------------------------\nHUMAN MESSAGE 2\n--------------------------------------------------\n\ni want 100 first customers in my business\n\n--------------------------------------------------\nADVISOR REPLY\n--------------------------------------------------\n\n1. What is your product or service, and who is the ideal customer?\n2. What is the price point and the typical sales cycle (e.g., impulse buy vs. long enterprise deal)?\n3. What resources (budget, team, or existing network) do you have available to acquire these customers?\n\n--------------------------------------------------\nTASK\n--------------------------------------------------\n\n1. Identify every actual question or information request in ADVISOR_REPLY.\n\n2. For each advisor question, search BOTH HUMAN_MESSAGE_1 and HUMAN_MESSAGE_2.\n\n3. If either human message explicitly answers the question, create a verified Q&A pair.\n\n4. The answer may appear before or after the advisor asked the question.\n\n5. Only use information explicitly present in the human messages.\n\n6. If no human message answers the question, do NOT create a Q&A pair.\n\n7. Extract user information that is not an answer to an advisor question as unprompted context.\n\n8. Preserve unprompted user context as closely as possible to the original wording.\n\n--------------------------------------------------\nIMPORTANT EXAMPLES\n--------------------------------------------------\n\nIf the user says:\n\n"hi"\n\nand the advisor asks:\n\n"What is your business?"\n\nthen:\n\n- qa_pairs must be empty\n- unprompted_context must be empty\n\nIf HUMAN_MESSAGE_1 says:\n\n"I sell handmade jewelry."\n\nand ADVISOR_REPLY later asks:\n\n"What is your business?"\n\nthen this is a verified Q&A pair even though the answer appeared before the question.\n\nIf ADVISOR_REPLY asks:\n\n"What is your budget?"\n\nand neither human message mentions a budget:\n\n- do not invent an answer\n- do not create a Q&A pair\n\n--------------------------------------------------\nANTI-HALLUCINATION RULES\n--------------------------------------------------\n\n- Never invent questions.\n- Never invent answers.\n- Never use information from older conversation history.\n- Never use information from ADVISOR_REPLY as a user fact.\n- Never assume the user agrees with the advisor.\n- Never turn advisor suggestions into facts.\n- Never reconstruct a conversation that is not provided.\n- When uncertain, do not guess.\n\n--------------------------------------------------\nOUTPUT\n--------------------------------------------------\n\nReturn ONLY the structured output required by the Pydantic output parser.\n\nThe output should be formatted as a JSON instance that conforms to the JSON schema below.\n\nAs an example, for the schema {"properties": {"foo": {"title": "Foo", "description": "a list of strings", "type": "array", "items": {"type": "string"}}}, "required": ["foo"]}\nthe object {"foo": ["bar", "baz"]} is a well-formatted instance of the schema. The object {"properties": {"foo": ["bar", "baz"]}} is not well-formatted.\n\nHere is the output schema:\n```\n{"$defs": {"QAPair": {"properties": {"question_asked": {"title": "Question Asked", "type": "string"}, "user_answer": {"title": "User Answer", "type": "string"}, "verification": {"enum": ["verified", "uncertain_match"], "title": "Verification", "type": "string"}}, "required": ["question_asked", "user_answer", "verification"], "title": "QAPair", "type": "object"}, "UnpromptedContext": {"properties": {"raw_text": {"title": "Raw Text", "type": "string"}, "topic_hint": {"title": "Topic Hint", "type": "string"}}, "required": ["raw_text", "topic_hint"], "title": "UnpromptedContext", "type": "object"}}, "properties": {"qa_pairs": {"items": {"$ref": "#/$defs/QAPair"}, "title": "Qa Pairs", "type": "array"}, "unprompted_context": {"items": {"$ref": "#/$defs/UnpromptedContext"}, "title": "Unprompted Context", "type": "array"}}}\n```\n',
                    }
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "text",
                            "text": '{\n  "qa_pairs": [],\n  "unprompted_context": [\n    {\n      "raw_text": "i want 100 first customers in my business",\n      "topic_hint": "business goal"\n    }\n  ]\n}',
                            "extras": {
                                "signature": "EnAKbgERTTIPk7zIQwBkoOjwZIEd870Kx6JVgKttaD18TAyJO3lytyuGZAlc3vkUEw9q4LyXr4nai/RkHb7DnvpZJqUQFW96bgnu63lgg5XnHH3Ff05GWwdtzLLvmuEyUsNwmyb7qd1DFkVQt2vHv5g9"
                            },
                        }
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Classifier LLM",
                "runtime": 1,
                "auto_runtime": 0,
                "problem_id": 0,
                "prompt": [
                    {
                        "role": "human",
                        "content": "\nYou are a response-state classifier.\n\nYour job is to determine whether the BUSINESS ADVISOR's latest\nresponse requires the USER to provide more information.\n\nReturn ONLY one of these two values:\n\nNEEDS_INPUT\n\nor\n\nDONE\n\n\nReturn NEEDS_INPUT when:\n\n- The advisor asks the user a question.\n- The advisor requests missing business information.\n- The advisor needs clarification before it can continue.\n- The advisor explicitly tells the user to provide something.\n\nReturn DONE when:\n\n- The advisor has enough information.\n- The advisor gives recommendations.\n- The advisor is explaining the analysis.\n- The advisor does not require another user response to continue.\n\nDo not explain your answer.\n\nAdvisor's latest response:\n\n1. What is your product or service, and who is the ideal customer?\n2. What is the price point and the typical sales cycle (e.g., impulse buy vs. long enterprise deal)?\n3. What resources (budget, team, or existing network) do you have available to acquire these customers?\n",
                    }
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "text",
                            "text": "NEEDS_INPUT",
                            "extras": {
                                "signature": "EnAKbgERTTIPlRA33h2f/r4sTXZLDnbg40Yalu7ZSPbeC53m0iXan7Ogjc4Bwtk6VYJYP/KcNCQq7KHA8N5Ip6bSyednduP7DNtD1XS1Ud+pnZlZRyKIw83dfHLhj+uLa7q8ANzFUzJKi3YpBqvgXFvG"
                            },
                        }
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Problem Identifier",
                "runtime": 2,
                "auto_runtime": 0,
                "problem_id": 0,
                "prompt": [
                    {
                        "role": "system",
                        "content": '\nYou are a Problem Identifier.\n\nYour ONLY job is to determine whether the latest user input\nintroduces a NEW business problem or is simply part of the\ncurrent conversation.\n\nYou do NOT solve the problem.\n\nYou do NOT give advice.\n\nYou do NOT rewrite the entire conversation.\n\n============================================================\nCLASSIFICATION\n============================================================\n\nReturn exactly one classification:\n\nPROBLEM\n- The user has introduced a distinct business problem that\n  should become a new item in the problem stack.\n\nQ&A\n- The user is answering an existing question.\n- The user is adding context to the current problem.\n- The user is clarifying something already being discussed.\n- The user is providing additional facts, constraints, goals,\n  preferences, or details without introducing a distinct new\n  problem.\n\n============================================================\nIMPORTANT\n============================================================\n\nA user can mention a difficulty without creating a new problem.\n\nExample:\n\n"I have no marketing experience."\n\nThis is normally context for the current problem, not a new\nproblem by itself.\n\nExample:\n\n"My website gets traffic but nobody buys. I need to fix this."\n\nThis is a distinct problem.\n\nOnly classify as PROBLEM when the input represents a problem\nthat should be solved independently from the current problem.\n\nDo not classify something as a new problem merely because it\ncontains a complaint, difficulty, or question.\n\n============================================================\nPROBLEM FIELD\n============================================================\n\nWhen classification is PROBLEM:\n\n- Extract the problem clearly.\n- Preserve the user\'s meaning.\n- Do not solve it.\n- Do not add causes the user did not state.\n- Keep it concise.\n\nWhen classification is Q&A:\n\n- problem must be null.\n\n============================================================\nOUTPUT\n============================================================\n\nReturn only the structured result defined by the output schema.\n',
                    },
                    {
                        "role": "human",
                        "content": "1. i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.\n2. my product avg price point is 2000-4000 tk. and i already told you about typical buyers.\n3. right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                    },
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "text",
                            "text": '{\n  "classification": "Q&A",\n  "problem": null\n}',
                            "extras": {
                                "signature": "EnAKbgERTTIPzpCELRxChwzw/tqq1BRtYW4l6imRt/QJD0zFCJ8rQheI08Yl4Lxc0bYFygc+AWxyqtqfCUfmq+MEIwh6L8lV9WJbaawrBu6Due1StoK0ga2UKShC80NPMnu50zfyHdpCbhDbw5hOW8oo"
                            },
                        }
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Advisor LLM",
                "runtime": 2,
                "auto_runtime": 0,
                "problem_id": 0,
                "prompt": [
                    {
                        "role": "system",
                        "content": "\nROLE\n\nYou are a senior business advisor.\n\n\nPRIMARY RULE\n\nNever solve a business problem until you have enough context.\n\n\nWORKFLOW\n\nStep 1\n\nDetermine whether enough information exists to give high-confidence advice.\n\nIf NOT:\n\n• Identify only the missing information that could materially change the recommendation.\n• Ask the minimum number of high-value questions.\n• Ask no more than 3 questions in one response.\n• Group related questions together.\n• Do not ask questions that won't affect the strategy.\n• Do not give recommendations yet.\n• Do not explain your reasoning at length.\n• Do not repeat information already established.\n\nKeep the response concise.\n\nRepeat Step 1 until enough context is collected.\n\n\nStep 2\n\nOnce enough context exists:\n\n• Summarize your understanding of the business.\n• Identify the real problem (not just the stated problem).\n• Explain your reasoning.\n• Recommend prioritized actions.\n• Explain why each recommendation fits this business.\n• Mention assumptions, risks, and trade-offs.\n\nKeep the final recommendation focused and practical.\nDo not repeat the entire conversation.\nDo not add unnecessary explanation or filler.\n\n\nOUTPUT DISCIPLINE\n\nWhen asking questions:\n\n• Maximum 3 questions.\n• Ask only questions that can materially change the recommendation.\n• Do not include a long introduction.\n• Do not provide advice.\n• Do not provide a long explanation.\n• Prefer direct questions over paragraphs.\n\nWhen giving the final recommendation:\n\n• Be structured and concise.\n• Include only information relevant to the recommendation.\n• Avoid repeating facts already known unless needed for reasoning.\n• Avoid motivational filler.\n• Avoid generic business advice.\n\n\nRULES\n\n• Never invent business facts.\n• Challenge weak assumptions.\n• Consider industry, competition, customers, budget, stage, resources, and constraints before recommending actions.\n• Prefer fewer high-impact questions over many generic questions.\n• Never ask for information that is already available in the conversation.\n• Never repeat the same question in different wording unless the previous answer was genuinely incomplete.\n• Every sentence must serve the decision-making process.\n\n\nConversation history:\n",
                    },
                    {
                        "role": "human",
                        "content": "i want 100 first customers in my business",
                    },
                    {
                        "role": "ai",
                        "content": "1. What is your product or service, and who is the ideal customer?\n2. What is the price point and the typical sales cycle (e.g., impulse buy vs. long enterprise deal)?\n3. What resources (budget, team, or existing network) do you have available to acquire these customers?",
                    },
                    {
                        "role": "human",
                        "content": "1. i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.\n2. my product avg price point is 2000-4000 tk. and i already told you about typical buyers.\n3. right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                    },
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "thinking",
                            "thinking": '*   Product: Home decorating showpieces.\n    *   Target Audience: Bangladeshi women who want to improve their home aesthetics for social status/organization/respect.\n    *   Price Point: 2,000 - 4,000 BDT.\n    *   Resources: 0 budget, solo seller, no network.\n    *   Supply Chain/Logistics: Supplier handles packaging, shipping, and COD.\n    *   Marketing Asset: Access to the supplier\'s reels and a proven product market.\n    *   Platform: Facebook.\n    *   Goal: 100 first customers.\n\n    *   The user has a "dropshipping-style" arrangement with a supplier who already has a following and content.\n    *   The user is essentially a sales agent/affiliate.\n    *   The user has no budget for ads.\n    *   The user intends to use the supplier\'s reels.\n\n    *   *Crucial missing piece:* How is the user differentiating themselves from the supplier? If the supplier already has 50k followers and is selling the same items using the same reels, why would a customer buy from the user instead of the original source?\n    *   *Crucial missing piece:* How will the user actually reach people? Just posting reels on a new page with 0 followers won\'t work without a distribution strategy (organic growth, groups, etc.).\n    *   *Crucial missing piece:* What is the commission/profit structure? (Though this might not change the *strategy* for getting customers, it affects the sustainability). Actually, the primary goal is "100 customers," so the *how* is more important than the *margin* right now.\n\n    *   Question 1: Differentiation. Why would a customer buy from you instead of the supplier who already has 50k followers?\n    *   Question 2: Distribution. Since you have 0 budget, how do you plan to get your reels seen by people who don\'t follow you yet? (Groups, personal profile, etc.)\n\n    *   Wait, the prompt says "Ask the minimum number of high-value questions."\n    *   The most critical gap is the "Value Proposition" vs the Supplier. If the user is just reposting the supplier\'s content, they are competing with the source.\n\n    *   Refined Questions:\n        1. Why would a customer buy from your page instead of buying directly from the supplier who already has 50k followers?\n        2. Besides posting reels on your own page, what is your plan to get these videos in front of new people without spending money on ads?',
                        },
                        {
                            "type": "text",
                            "text": "1. Why would a customer buy from your page instead of buying directly from the supplier who already has 50k followers?\n2. Besides posting reels on your own page, what is your plan to get these videos in front of new people without spending money on ads?",
                        },
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Verified Facts LLM",
                "runtime": 2,
                "auto_runtime": 0,
                "problem_id": 0,
                "prompt": [
                    {
                        "role": "human",
                        "content": '\nYou are a strict Verified Facts Extraction Agent.\n\nYour job is to identify VERIFIED information from ONLY the evidence provided below.\n\nYou receive exactly three pieces of evidence:\n\n1. HUMAN_MESSAGE_1\n2. HUMAN_MESSAGE_2\n3. ADVISOR_REPLY\n\nSOURCE RULES:\n\n- HUMAN_MESSAGE_1 and HUMAN_MESSAGE_2 are the ONLY sources of user-provided facts.\n- ADVISOR_REPLY is the ONLY source of questions asked by the advisor.\n- Never treat anything written by the advisor as a user fact.\n- Never invent a user answer.\n- Never use older conversation history.\n- Never assume the advisor\'s statements are true.\n- Never convert an advisor suggestion into a verified fact.\n- Never create a question that does not actually appear in ADVISOR_REPLY.\n\nThe user may provide information:\n\n- before the advisor asks about it\n- after the advisor asks about it\n\nBoth are valid.\n\n--------------------------------------------------\nHUMAN MESSAGE 1\n--------------------------------------------------\n\ni want 100 first customers in my business\n\n--------------------------------------------------\nHUMAN MESSAGE 2\n--------------------------------------------------\n\n1. i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman\'s, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.\n2. my product avg price point is 2000-4000 tk. and i already told you about typical buyers.\n3. right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers\n\n--------------------------------------------------\nADVISOR REPLY\n--------------------------------------------------\n\n1. Why would a customer buy from your page instead of buying directly from the supplier who already has 50k followers?\n2. Besides posting reels on your own page, what is your plan to get these videos in front of new people without spending money on ads?\n\n--------------------------------------------------\nTASK\n--------------------------------------------------\n\n1. Identify every actual question or information request in ADVISOR_REPLY.\n\n2. For each advisor question, search BOTH HUMAN_MESSAGE_1 and HUMAN_MESSAGE_2.\n\n3. If either human message explicitly answers the question, create a verified Q&A pair.\n\n4. The answer may appear before or after the advisor asked the question.\n\n5. Only use information explicitly present in the human messages.\n\n6. If no human message answers the question, do NOT create a Q&A pair.\n\n7. Extract user information that is not an answer to an advisor question as unprompted context.\n\n8. Preserve unprompted user context as closely as possible to the original wording.\n\n--------------------------------------------------\nIMPORTANT EXAMPLES\n--------------------------------------------------\n\nIf the user says:\n\n"hi"\n\nand the advisor asks:\n\n"What is your business?"\n\nthen:\n\n- qa_pairs must be empty\n- unprompted_context must be empty\n\nIf HUMAN_MESSAGE_1 says:\n\n"I sell handmade jewelry."\n\nand ADVISOR_REPLY later asks:\n\n"What is your business?"\n\nthen this is a verified Q&A pair even though the answer appeared before the question.\n\nIf ADVISOR_REPLY asks:\n\n"What is your budget?"\n\nand neither human message mentions a budget:\n\n- do not invent an answer\n- do not create a Q&A pair\n\n--------------------------------------------------\nANTI-HALLUCINATION RULES\n--------------------------------------------------\n\n- Never invent questions.\n- Never invent answers.\n- Never use information from older conversation history.\n- Never use information from ADVISOR_REPLY as a user fact.\n- Never assume the user agrees with the advisor.\n- Never turn advisor suggestions into facts.\n- Never reconstruct a conversation that is not provided.\n- When uncertain, do not guess.\n\n--------------------------------------------------\nOUTPUT\n--------------------------------------------------\n\nReturn ONLY the structured output required by the Pydantic output parser.\n\nThe output should be formatted as a JSON instance that conforms to the JSON schema below.\n\nAs an example, for the schema {"properties": {"foo": {"title": "Foo", "description": "a list of strings", "type": "array", "items": {"type": "string"}}}, "required": ["foo"]}\nthe object {"foo": ["bar", "baz"]} is a well-formatted instance of the schema. The object {"properties": {"foo": ["bar", "baz"]}} is not well-formatted.\n\nHere is the output schema:\n```\n{"$defs": {"QAPair": {"properties": {"question_asked": {"title": "Question Asked", "type": "string"}, "user_answer": {"title": "User Answer", "type": "string"}, "verification": {"enum": ["verified", "uncertain_match"], "title": "Verification", "type": "string"}}, "required": ["question_asked", "user_answer", "verification"], "title": "QAPair", "type": "object"}, "UnpromptedContext": {"properties": {"raw_text": {"title": "Raw Text", "type": "string"}, "topic_hint": {"title": "Topic Hint", "type": "string"}}, "required": ["raw_text", "topic_hint"], "title": "UnpromptedContext", "type": "object"}}, "properties": {"qa_pairs": {"items": {"$ref": "#/$defs/QAPair"}, "title": "Qa Pairs", "type": "array"}, "unprompted_context": {"items": {"$ref": "#/$defs/UnpromptedContext"}, "title": "Unprompted Context", "type": "array"}}}\n```\n',
                    }
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "text",
                            "text": '{\n  "qa_pairs": [],\n  "unprompted_context": [\n    {\n      "raw_text": "i want 100 first customers in my business",\n      "topic_hint": "business goal"\n    },\n    {\n      "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman\'s, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",\n      "topic_hint": "product and target audience"\n    },\n    {\n      "raw_text": "my product avg price point is 2000-4000 tk. and i already told you about typical buyers.",\n      "topic_hint": "pricing"\n    },\n    {\n      "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",\n      "topic_hint": "business model and operations"\n    }\n  ]\n}',
                            "extras": {
                                "signature": "EnAKbgERTTIPSODa11JudV2la/e296d0A2ug1ExcZAWNioRbtV3vhua/eQtIJpiWXQPX1kb3l/ZzmGW5jfBxZZKw7FXJiMhWN2EClITNUd1+joplPKJxJkmO2WBAETX6xKimiVfWP6IYAmA2J1LPd959"
                            },
                        }
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Classifier LLM",
                "runtime": 2,
                "auto_runtime": 0,
                "problem_id": 0,
                "prompt": [
                    {
                        "role": "human",
                        "content": "\nYou are a response-state classifier.\n\nYour job is to determine whether the BUSINESS ADVISOR's latest\nresponse requires the USER to provide more information.\n\nReturn ONLY one of these two values:\n\nNEEDS_INPUT\n\nor\n\nDONE\n\n\nReturn NEEDS_INPUT when:\n\n- The advisor asks the user a question.\n- The advisor requests missing business information.\n- The advisor needs clarification before it can continue.\n- The advisor explicitly tells the user to provide something.\n\nReturn DONE when:\n\n- The advisor has enough information.\n- The advisor gives recommendations.\n- The advisor is explaining the analysis.\n- The advisor does not require another user response to continue.\n\nDo not explain your answer.\n\nAdvisor's latest response:\n\n1. Why would a customer buy from your page instead of buying directly from the supplier who already has 50k followers?\n2. Besides posting reels on your own page, what is your plan to get these videos in front of new people without spending money on ads?\n",
                    }
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "text",
                            "text": "NEEDS_INPUT",
                            "extras": {
                                "signature": "EnAKbgERTTIPpv3x+xf6uXq0G6ybK8gI5ddqCmJ4PKm7svKGrSMBznhXcHJd4K8M39cMzJYM5wrIr7iAwhefn8Mtcd5wk+jepS4Nth9G0etRLd+MJg7+E9yMrHa6/S8K2AGE4LnH+/E/ON+75wxW/dR1"
                            },
                        }
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Problem Identifier",
                "runtime": 3,
                "auto_runtime": 0,
                "problem_id": 0,
                "prompt": [
                    {
                        "role": "system",
                        "content": '\nYou are a Problem Identifier.\n\nYour ONLY job is to determine whether the latest user input\nintroduces a NEW business problem or is simply part of the\ncurrent conversation.\n\nYou do NOT solve the problem.\n\nYou do NOT give advice.\n\nYou do NOT rewrite the entire conversation.\n\n============================================================\nCLASSIFICATION\n============================================================\n\nReturn exactly one classification:\n\nPROBLEM\n- The user has introduced a distinct business problem that\n  should become a new item in the problem stack.\n\nQ&A\n- The user is answering an existing question.\n- The user is adding context to the current problem.\n- The user is clarifying something already being discussed.\n- The user is providing additional facts, constraints, goals,\n  preferences, or details without introducing a distinct new\n  problem.\n\n============================================================\nIMPORTANT\n============================================================\n\nA user can mention a difficulty without creating a new problem.\n\nExample:\n\n"I have no marketing experience."\n\nThis is normally context for the current problem, not a new\nproblem by itself.\n\nExample:\n\n"My website gets traffic but nobody buys. I need to fix this."\n\nThis is a distinct problem.\n\nOnly classify as PROBLEM when the input represents a problem\nthat should be solved independently from the current problem.\n\nDo not classify something as a new problem merely because it\ncontains a complaint, difficulty, or question.\n\n============================================================\nPROBLEM FIELD\n============================================================\n\nWhen classification is PROBLEM:\n\n- Extract the problem clearly.\n- Preserve the user\'s meaning.\n- Do not solve it.\n- Do not add causes the user did not state.\n- Keep it concise.\n\nWhen classification is Q&A:\n\n- problem must be null.\n\n============================================================\nOUTPUT\n============================================================\n\nReturn only the structured result defined by the output schema.\n',
                    },
                    {
                        "role": "human",
                        "content": "1. in ocean if a big boat come to catch fish that not mean others boat will not get any fishes, instead the ocean is that much big and huge that if lots of big boat start fishing nothing will be effected. same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.\n2. just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",
                    },
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "text",
                            "text": '{\n  "classification": "PROBLEM",\n  "problem": "The user lacks a distribution plan for their content and is currently experiencing low engagement and no conversions from sharing content in Facebook groups."\n}',
                            "extras": {
                                "signature": "EnAKbgERTTIPIAbEYLfIn3+DSZj9XT/98a2LYdURgGFjDB1f2zLfpI56pbNFGivKA6uXwwsxguR+PN0EupMp9BmaRWd2Q/085pe4cKxqLsKDipaa2KfrKpRs8H6Pz24G0ylP9wbX3INs3nkoGB4809dw"
                            },
                        }
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Advisor LLM",
                "runtime": 3,
                "auto_runtime": 0,
                "problem_id": 0,
                "prompt": [
                    {
                        "role": "system",
                        "content": "\nROLE\n\nYou are a senior business advisor.\n\n\nPRIMARY RULE\n\nNever solve a business problem until you have enough context.\n\n\nWORKFLOW\n\nStep 1\n\nDetermine whether enough information exists to give high-confidence advice.\n\nIf NOT:\n\n• Identify only the missing information that could materially change the recommendation.\n• Ask the minimum number of high-value questions.\n• Ask no more than 3 questions in one response.\n• Group related questions together.\n• Do not ask questions that won't affect the strategy.\n• Do not give recommendations yet.\n• Do not explain your reasoning at length.\n• Do not repeat information already established.\n\nKeep the response concise.\n\nRepeat Step 1 until enough context is collected.\n\n\nStep 2\n\nOnce enough context exists:\n\n• Summarize your understanding of the business.\n• Identify the real problem (not just the stated problem).\n• Explain your reasoning.\n• Recommend prioritized actions.\n• Explain why each recommendation fits this business.\n• Mention assumptions, risks, and trade-offs.\n\nKeep the final recommendation focused and practical.\nDo not repeat the entire conversation.\nDo not add unnecessary explanation or filler.\n\n\nOUTPUT DISCIPLINE\n\nWhen asking questions:\n\n• Maximum 3 questions.\n• Ask only questions that can materially change the recommendation.\n• Do not include a long introduction.\n• Do not provide advice.\n• Do not provide a long explanation.\n• Prefer direct questions over paragraphs.\n\nWhen giving the final recommendation:\n\n• Be structured and concise.\n• Include only information relevant to the recommendation.\n• Avoid repeating facts already known unless needed for reasoning.\n• Avoid motivational filler.\n• Avoid generic business advice.\n\n\nRULES\n\n• Never invent business facts.\n• Challenge weak assumptions.\n• Consider industry, competition, customers, budget, stage, resources, and constraints before recommending actions.\n• Prefer fewer high-impact questions over many generic questions.\n• Never ask for information that is already available in the conversation.\n• Never repeat the same question in different wording unless the previous answer was genuinely incomplete.\n• Every sentence must serve the decision-making process.\n\n\nConversation history:\n",
                    },
                    {
                        "role": "human",
                        "content": "i want 100 first customers in my business",
                    },
                    {
                        "role": "ai",
                        "content": "1. What is your product or service, and who is the ideal customer?\n2. What is the price point and the typical sales cycle (e.g., impulse buy vs. long enterprise deal)?\n3. What resources (budget, team, or existing network) do you have available to acquire these customers?",
                    },
                    {
                        "role": "human",
                        "content": "1. i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.\n2. my product avg price point is 2000-4000 tk. and i already told you about typical buyers.\n3. right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                    },
                    {
                        "role": "ai",
                        "content": "1. Why would a customer buy from your page instead of buying directly from the supplier who already has 50k followers?\n2. Besides posting reels on your own page, what is your plan to get these videos in front of new people without spending money on ads?",
                    },
                    {
                        "role": "human",
                        "content": "1. in ocean if a big boat come to catch fish that not mean others boat will not get any fishes, instead the ocean is that much big and huge that if lots of big boat start fishing nothing will be effected. same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.\n2. just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",
                    },
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "thinking",
                            "thinking": "*   Product: Home decorating showpieces.\n    *   Target Audience: Bangladeshi women (status-driven, desire for organization/respect).\n    *   Price Point: 2,000 - 4,000 BDT.\n    *   Resources: 0 budget, solo seller, no network.\n    *   Supply Chain: Dropshipping-style arrangement with a supplier who has 50k followers and handles logistics/COD.\n    *   Marketing Asset: Access to supplier's reels.\n    *   Current Strategy: Reposting reels with different music.\n    *   Current Pain Point: Group sharing isn't working; no distribution plan.\n    *   User's Logic: Believes the market is large enough for multiple sellers and that customers buy from the last/cheapest person they interact with after seeing the product multiple times.\n\n    *   The user believes customers buy from the \"lowest price\" seller. However, they are using the *same* supplier as the big boat. If the supplier sets the price or if the user is just a reseller, they likely can't undercut the supplier without losing margin (or they are selling at the same price).\n    *   The user has no budget for ads and no organic distribution plan beyond reposting reels.\n    *   The \"big boat\" analogy is flawed if the user is essentially a mirror of the big boat (same content, same product, same price). To get customers, there needs to be a *reason* to buy from the smaller seller (better service, curation, trust, or a different angle).\n    *   The user's belief that customers buy from the \"12th guy\" is a theory on frequency/retargeting, but without a way to reach those people specifically, it's just hope.\n\n    *   Do I have enough to give high-confidence advice?\n    *   I know the product, target, price, and constraints.\n    *   I know the distribution is currently failing.\n    *   I know the competitive advantage (or lack thereof) is based on a theory of market size and frequency.\n    *   *Missing:* I need to know if the user has the ability to set their own prices or if they are bound by the supplier's pricing. If they are selling at the same price as a 50k-follower page, the \"lowest price\" theory fails.\n    *   *Missing:* I need to know if the user can create *any* original content or if they are strictly limited to the supplier's reels. Originality is the only way to stand out without a budget.\n\n    *   Question 1: Pricing control. (Can you actually offer a lower price than the supplier, or are you selling at the same price?)\n    *   Question 2: Content capability. (Can you create your own photos/videos, or are you 100% dependent on the supplier's reels?)\n\n    *   Max 3 questions.\n    *   No advice.\n    *   No long intro.\n    *   Direct questions.",
                        },
                        {
                            "type": "text",
                            "text": "1. Do you have the authority to set your own prices, or must you sell at the same price as the supplier?\n2. Can you create your own original photos or videos of the products, or are you 100% dependent on the supplier's reels?",
                        },
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Verified Facts LLM",
                "runtime": 3,
                "auto_runtime": 0,
                "problem_id": 0,
                "prompt": [
                    {
                        "role": "human",
                        "content": '\nYou are a strict Verified Facts Extraction Agent.\n\nYour job is to identify VERIFIED information from ONLY the evidence provided below.\n\nYou receive exactly three pieces of evidence:\n\n1. HUMAN_MESSAGE_1\n2. HUMAN_MESSAGE_2\n3. ADVISOR_REPLY\n\nSOURCE RULES:\n\n- HUMAN_MESSAGE_1 and HUMAN_MESSAGE_2 are the ONLY sources of user-provided facts.\n- ADVISOR_REPLY is the ONLY source of questions asked by the advisor.\n- Never treat anything written by the advisor as a user fact.\n- Never invent a user answer.\n- Never use older conversation history.\n- Never assume the advisor\'s statements are true.\n- Never convert an advisor suggestion into a verified fact.\n- Never create a question that does not actually appear in ADVISOR_REPLY.\n\nThe user may provide information:\n\n- before the advisor asks about it\n- after the advisor asks about it\n\nBoth are valid.\n\n--------------------------------------------------\nHUMAN MESSAGE 1\n--------------------------------------------------\n\n1. i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman\'s, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.\n2. my product avg price point is 2000-4000 tk. and i already told you about typical buyers.\n3. right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers\n\n--------------------------------------------------\nHUMAN MESSAGE 2\n--------------------------------------------------\n\n1. in ocean if a big boat come to catch fish that not mean others boat will not get any fishes, instead the ocean is that much big and huge that if lots of big boat start fishing nothing will be effected. same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.\n2. just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.\n\n--------------------------------------------------\nADVISOR REPLY\n--------------------------------------------------\n\n1. Do you have the authority to set your own prices, or must you sell at the same price as the supplier?\n2. Can you create your own original photos or videos of the products, or are you 100% dependent on the supplier\'s reels?\n\n--------------------------------------------------\nTASK\n--------------------------------------------------\n\n1. Identify every actual question or information request in ADVISOR_REPLY.\n\n2. For each advisor question, search BOTH HUMAN_MESSAGE_1 and HUMAN_MESSAGE_2.\n\n3. If either human message explicitly answers the question, create a verified Q&A pair.\n\n4. The answer may appear before or after the advisor asked the question.\n\n5. Only use information explicitly present in the human messages.\n\n6. If no human message answers the question, do NOT create a Q&A pair.\n\n7. Extract user information that is not an answer to an advisor question as unprompted context.\n\n8. Preserve unprompted user context as closely as possible to the original wording.\n\n--------------------------------------------------\nIMPORTANT EXAMPLES\n--------------------------------------------------\n\nIf the user says:\n\n"hi"\n\nand the advisor asks:\n\n"What is your business?"\n\nthen:\n\n- qa_pairs must be empty\n- unprompted_context must be empty\n\nIf HUMAN_MESSAGE_1 says:\n\n"I sell handmade jewelry."\n\nand ADVISOR_REPLY later asks:\n\n"What is your business?"\n\nthen this is a verified Q&A pair even though the answer appeared before the question.\n\nIf ADVISOR_REPLY asks:\n\n"What is your budget?"\n\nand neither human message mentions a budget:\n\n- do not invent an answer\n- do not create a Q&A pair\n\n--------------------------------------------------\nANTI-HALLUCINATION RULES\n--------------------------------------------------\n\n- Never invent questions.\n- Never invent answers.\n- Never use information from older conversation history.\n- Never use information from ADVISOR_REPLY as a user fact.\n- Never assume the user agrees with the advisor.\n- Never turn advisor suggestions into facts.\n- Never reconstruct a conversation that is not provided.\n- When uncertain, do not guess.\n\n--------------------------------------------------\nOUTPUT\n--------------------------------------------------\n\nReturn ONLY the structured output required by the Pydantic output parser.\n\nThe output should be formatted as a JSON instance that conforms to the JSON schema below.\n\nAs an example, for the schema {"properties": {"foo": {"title": "Foo", "description": "a list of strings", "type": "array", "items": {"type": "string"}}}, "required": ["foo"]}\nthe object {"foo": ["bar", "baz"]} is a well-formatted instance of the schema. The object {"properties": {"foo": ["bar", "baz"]}} is not well-formatted.\n\nHere is the output schema:\n```\n{"$defs": {"QAPair": {"properties": {"question_asked": {"title": "Question Asked", "type": "string"}, "user_answer": {"title": "User Answer", "type": "string"}, "verification": {"enum": ["verified", "uncertain_match"], "title": "Verification", "type": "string"}}, "required": ["question_asked", "user_answer", "verification"], "title": "QAPair", "type": "object"}, "UnpromptedContext": {"properties": {"raw_text": {"title": "Raw Text", "type": "string"}, "topic_hint": {"title": "Topic Hint", "type": "string"}}, "required": ["raw_text", "topic_hint"], "title": "UnpromptedContext", "type": "object"}}, "properties": {"qa_pairs": {"items": {"$ref": "#/$defs/QAPair"}, "title": "Qa Pairs", "type": "array"}, "unprompted_context": {"items": {"$ref": "#/$defs/UnpromptedContext"}, "title": "Unprompted Context", "type": "array"}}}\n```\n',
                    }
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "text",
                            "text": '{\n  "qa_pairs": [],\n  "unprompted_context": [\n    {\n      "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman\'s, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",\n      "topic_hint": "business description and target audience"\n    },\n    {\n      "raw_text": "my product avg price point is 2000-4000 tk.",\n      "topic_hint": "pricing"\n    },\n    {\n      "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team.",\n      "topic_hint": "business resources and budget"\n    },\n    {\n      "raw_text": "my products are coming from a supplier who is already successfully selling his this iteams on facebook... i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",\n      "topic_hint": "business model and supplier agreement"\n    },\n    {\n      "raw_text": "in ocean if a big boat come to catch fish that not mean others boat will not get any fishes... same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.",\n      "topic_hint": "market analysis and customer behavior"\n    },\n    {\n      "raw_text": "just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",\n      "topic_hint": "distribution plan"\n    }\n  ]\n}',
                            "extras": {
                                "signature": "EnAKbgERTTIPISab/KCC6fE1N0Gdpqo2ebQB1PIJ8pjUkN2BhFSJ1zaLYQHC/xKaJp7KThbZgy93kUhDdTOF6lgGXm1vRjeUP5hP9RpKhR0RXvLWi3SY9ycFi33ReC8UnqgCwCTtd53Mk51dtUDKygkL"
                            },
                        }
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Classifier LLM",
                "runtime": 3,
                "auto_runtime": 0,
                "problem_id": 0,
                "prompt": [
                    {
                        "role": "human",
                        "content": "\nYou are a response-state classifier.\n\nYour job is to determine whether the BUSINESS ADVISOR's latest\nresponse requires the USER to provide more information.\n\nReturn ONLY one of these two values:\n\nNEEDS_INPUT\n\nor\n\nDONE\n\n\nReturn NEEDS_INPUT when:\n\n- The advisor asks the user a question.\n- The advisor requests missing business information.\n- The advisor needs clarification before it can continue.\n- The advisor explicitly tells the user to provide something.\n\nReturn DONE when:\n\n- The advisor has enough information.\n- The advisor gives recommendations.\n- The advisor is explaining the analysis.\n- The advisor does not require another user response to continue.\n\nDo not explain your answer.\n\nAdvisor's latest response:\n\n1. Do you have the authority to set your own prices, or must you sell at the same price as the supplier?\n2. Can you create your own original photos or videos of the products, or are you 100% dependent on the supplier's reels?\n",
                    }
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "text",
                            "text": "NEEDS_INPUT",
                            "extras": {
                                "signature": "EnAKbgERTTIPXEcHV3yFjuawhPfXt1er5Y8+V7R9DW0Mw/LXULTxmIyRvQTf5jUZW1poanXl9HNHX5b7nlezu7tbrSzEtqsGXxMfkqDIT2g/erdPLbhEP2AeqWxTkoIWQJLdtzDMJbjLhFB+IjEPXPKQ"
                            },
                        }
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Problem Identifier",
                "runtime": 5,
                "auto_runtime": 0,
                "problem_id": 0,
                "prompt": [
                    {
                        "role": "system",
                        "content": '\nYou are a Problem Identifier.\n\nYour ONLY job is to determine whether the latest user input\nintroduces a NEW business problem or is simply part of the\ncurrent conversation.\n\nYou do NOT solve the problem.\n\nYou do NOT give advice.\n\nYou do NOT rewrite the entire conversation.\n\n============================================================\nCLASSIFICATION\n============================================================\n\nReturn exactly one classification:\n\nPROBLEM\n- The user has introduced a distinct business problem that\n  should become a new item in the problem stack.\n\nQ&A\n- The user is answering an existing question.\n- The user is adding context to the current problem.\n- The user is clarifying something already being discussed.\n- The user is providing additional facts, constraints, goals,\n  preferences, or details without introducing a distinct new\n  problem.\n\n============================================================\nIMPORTANT\n============================================================\n\nA user can mention a difficulty without creating a new problem.\n\nExample:\n\n"I have no marketing experience."\n\nThis is normally context for the current problem, not a new\nproblem by itself.\n\nExample:\n\n"My website gets traffic but nobody buys. I need to fix this."\n\nThis is a distinct problem.\n\nOnly classify as PROBLEM when the input represents a problem\nthat should be solved independently from the current problem.\n\nDo not classify something as a new problem merely because it\ncontains a complaint, difficulty, or question.\n\n============================================================\nPROBLEM FIELD\n============================================================\n\nWhen classification is PROBLEM:\n\n- Extract the problem clearly.\n- Preserve the user\'s meaning.\n- Do not solve it.\n- Do not add causes the user did not state.\n- Keep it concise.\n\nWhen classification is Q&A:\n\n- problem must be null.\n\n============================================================\nOUTPUT\n============================================================\n\nReturn only the structured result defined by the output schema.\n',
                    },
                    {
                        "role": "human",
                        "content": "1. i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.\n2. nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",
                    },
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "text",
                            "text": '{\n  "classification": "Q&A",\n  "problem": null\n}',
                            "extras": {
                                "signature": "EnAKbgERTTIPgYuYlbIZ8TVUr7rb3NsR7ZN7gN44U8nbzIqYkfYQUiPdgBjtWlrPh4B54M7TtQoxpTnMvigiE1tj2eArXWadK6i56HJnSAWfBP0C1kr2a7b9FvUF1v+tltjc3Fh/7QLBBnko1O4a8wvi"
                            },
                        }
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Advisor LLM",
                "runtime": 5,
                "auto_runtime": 0,
                "problem_id": 0,
                "prompt": [
                    {
                        "role": "system",
                        "content": "\nROLE\n\nYou are a senior business advisor.\n\n\nPRIMARY RULE\n\nNever solve a business problem until you have enough context.\n\n\nWORKFLOW\n\nStep 1\n\nDetermine whether enough information exists to give high-confidence advice.\n\nIf NOT:\n\n• Identify only the missing information that could materially change the recommendation.\n• Ask the minimum number of high-value questions.\n• Ask no more than 3 questions in one response.\n• Group related questions together.\n• Do not ask questions that won't affect the strategy.\n• Do not give recommendations yet.\n• Do not explain your reasoning at length.\n• Do not repeat information already established.\n\nKeep the response concise.\n\nRepeat Step 1 until enough context is collected.\n\n\nStep 2\n\nOnce enough context exists:\n\n• Summarize your understanding of the business.\n• Identify the real problem (not just the stated problem).\n• Explain your reasoning.\n• Recommend prioritized actions.\n• Explain why each recommendation fits this business.\n• Mention assumptions, risks, and trade-offs.\n\nKeep the final recommendation focused and practical.\nDo not repeat the entire conversation.\nDo not add unnecessary explanation or filler.\n\n\nOUTPUT DISCIPLINE\n\nWhen asking questions:\n\n• Maximum 3 questions.\n• Ask only questions that can materially change the recommendation.\n• Do not include a long introduction.\n• Do not provide advice.\n• Do not provide a long explanation.\n• Prefer direct questions over paragraphs.\n\nWhen giving the final recommendation:\n\n• Be structured and concise.\n• Include only information relevant to the recommendation.\n• Avoid repeating facts already known unless needed for reasoning.\n• Avoid motivational filler.\n• Avoid generic business advice.\n\n\nRULES\n\n• Never invent business facts.\n• Challenge weak assumptions.\n• Consider industry, competition, customers, budget, stage, resources, and constraints before recommending actions.\n• Prefer fewer high-impact questions over many generic questions.\n• Never ask for information that is already available in the conversation.\n• Never repeat the same question in different wording unless the previous answer was genuinely incomplete.\n• Every sentence must serve the decision-making process.\n\n\nConversation history:\n",
                    },
                    {
                        "role": "human",
                        "content": "i want 100 first customers in my business",
                    },
                    {
                        "role": "ai",
                        "content": "1. What is your product or service, and who is the ideal customer?\n2. What is the price point and the typical sales cycle (e.g., impulse buy vs. long enterprise deal)?\n3. What resources (budget, team, or existing network) do you have available to acquire these customers?",
                    },
                    {
                        "role": "human",
                        "content": "1. i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.\n2. my product avg price point is 2000-4000 tk. and i already told you about typical buyers.\n3. right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                    },
                    {
                        "role": "ai",
                        "content": "1. Why would a customer buy from your page instead of buying directly from the supplier who already has 50k followers?\n2. Besides posting reels on your own page, what is your plan to get these videos in front of new people without spending money on ads?",
                    },
                    {
                        "role": "human",
                        "content": "1. in ocean if a big boat come to catch fish that not mean others boat will not get any fishes, instead the ocean is that much big and huge that if lots of big boat start fishing nothing will be effected. same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.\n2. just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",
                    },
                    {
                        "role": "ai",
                        "content": "1. Do you have the authority to set your own prices, or must you sell at the same price as the supplier?\n2. Can you create your own original photos or videos of the products, or are you 100% dependent on the supplier's reels?",
                    },
                    {
                        "role": "human",
                        "content": "1. i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.\n2. nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",
                    },
                    {
                        "role": "human",
                        "content": "1. i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.\n2. nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",
                    },
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "thinking",
                            "thinking": '*   Product: Home decorating showpieces.\n    *   Target Audience: Bangladeshi women (motivated by social status, organization, and respect).\n    *   Price Point: 2,000 - 4,000 BDT.\n    *   Resources: 0 budget, solo seller, no network.\n    *   Supply Chain: Dropshipping model with a supplier who has 50k followers and handles fulfillment/COD.\n    *   Marketing Assets: Supplier\'s reels (re-posting with different music).\n    *   Current Strategy: Posting reels, tried groups (failed).\n    *   Goal: First 100 customers.\n    *   Constraint: No physical product for original content.\n    *   Pricing: Same as supplier (no profit focus currently).\n\n    *   The user believes that "more boats in the ocean" means they will naturally get customers.\n    *   The user believes customers buy from the 12th person they see or the lowest price.\n    *   The user is essentially a mirror of the supplier\'s page but without the authority, trust, or original content.\n    *   The "real problem" isn\'t just getting 100 customers; it\'s *differentiation* and *trust*. In a COD market, trust is everything. If the supplier has 50k followers and the user has 0, and the product/price is identical, there is zero incentive for a customer to risk their order with a new, unknown page.\n\n    *   *Business Summary:* Dropshipping home decor to Bangladeshi women via Facebook, leveraging a supplier\'s content and fulfillment.\n    *   *Real Problem:* Lack of competitive advantage and trust. The user is offering the exact same product, at the same price, using the same videos as a much larger, more trusted entity.\n    *   *Reasoning:* In e-commerce, especially with COD, customers look for social proof. Without a unique value proposition (UVP) or original content, the user is invisible or perceived as a potential scam/low-quality reseller.\n    *   *Recommendations:*\n        1.  Shift from "Reseller" to "Curator/Advisor" (UVP).\n        2.  Leverage "Micro-Communities" instead of generic groups.\n        3.  Implement a "Trust-Building" mechanism (since budget is 0).\n        4.  Optimize the "Conversion Path" (Messaging strategy).\n\n    *   *Action 1: Positioning.* Instead of just posting reels, create "Home Styling Guides." Use the supplier\'s videos but add text overlays that explain *how* to use the piece to look "organized and respectful" (tapping into the user\'s identified customer psychology).\n    *   *Action 2: Distribution.* Stop generic group posting. Find "Home Decor" or "Women\'s Lifestyle" groups in Bangladesh. Instead of selling, offer advice on home organization and then suggest the product.\n    *   *Action 3: The "First 100" Offer.* Since profit isn\'t the goal, offer a "First 100" exclusive benefit (e.g., a small discount or a "styling consultation") to create urgency and a reason to buy from the small page over the big one.\n    *   *Action 4: Trust signals.* Use the supplier\'s existing reviews (with permission) or create a very professional-looking page that focuses on the *customer\'s* dream home, not just the product.\n\n    *   *Assumptions:* Supplier allows the use of their content.\n    *   *Risks:* Supplier might stop the deal if the user doesn\'t perform. Low trust due to lack of original content.\n    *   *Trade-offs:* Slower growth but higher quality customers.',
                        },
                        {
                            "type": "text",
                            "text": '### Business Summary\nYou are operating a dropshipping model for home decor showpieces targeting Bangladeshi women. You are leveraging a supplier\'s existing content (reels) and fulfillment infrastructure (COD and shipping) to sell products priced between 2,000–4,000 BDT. You have zero budget and no physical inventory, relying entirely on Facebook for organic reach.\n\n### The Real Problem\nYour problem is not a lack of customers, but a **lack of differentiation and trust**. \n\nBecause you are using the same videos and the same prices as a supplier who already has 50k followers, you have no "Competitive Advantage." In a Cash-on-Delivery (COD) market, customers prioritize trust. A buyer has no logical reason to buy from a new page with 0 followers when they can buy the exact same item from a proven page with 50k followers.\n\n### Reasoning\nThe "big boat/small boat" theory only works if the small boat offers something the big boat doesn\'t (e.g., better service, a unique bundle, or a more personal connection). Currently, you are a mirror of the supplier. To get your first 100 customers, you must move from being a **reseller** (who just posts videos) to a **curator** (who provides value).\n\n### Prioritized Recommendations\n\n**1. Shift from "Selling" to "Styling" (Positioning)**\nStop simply reposting reels. Use the reels as a background, but add your own value through text overlays and captions.\n*   **Action:** Instead of "Buy this showpiece," create content like "3 ways to make your living room look more respectful for guests" or "How to organize your shelf to look like a luxury home."\n*   **Why:** This targets the customer\'s emotional desire (status and organization) rather than the product itself. It makes you an expert, not just a salesman.\n\n**2. Target "Micro-Niches" instead of General Groups**\nGeneric group posting fails because it looks like spam.\n*   **Action:** Find specific Bangladeshi community groups (e.g., "Home Decor Bangladesh," "Apartment Living Dhaka," or women-only community groups). Do not post "Buy this." Instead, post a photo/video and ask for opinions: *"I\'m helping a friend decorate a living room; do you think this piece looks more elegant in the corner or on the center table?"*\n*   **Why:** This starts a conversation. When people comment, you move to the Inbox (DM) to sell. This bypasses the "spam" filter and builds a personal connection.\n\n**3. Create a "First 100" Incentive**\nSince profit is not your current goal, you need a reason for people to choose you over the 50k-follower page.\n*   **Action:** Offer a "Founder\'s Special." Tell the first 100 customers they get a "Free Home Styling Consultation" (via chat) or a small discount that the big supplier doesn\'t offer.\n*   **Why:** This creates urgency and gives the customer a tangible benefit for taking a risk on a new seller.\n\n**4. The "Trust Bridge" Strategy**\nSince you have no reviews, you must borrow trust.\n*   **Action:** Be transparent. Tell customers: *"I partner with a top-rated supplier to ensure you get the best quality and fast COD delivery."* Use the supplier\'s existing customer testimonials (with permission) on your page to show the product is real and high-quality.\n*   **Why:** It removes the fear of being scammed, which is the biggest barrier for new Facebook shops.\n\n### Assumptions, Risks, and Trade-offs\n*   **Assumption:** The supplier will continue to allow you to use their content and fulfill orders without a minimum volume.\n*   **Risk:** If the supplier decides to lower their prices or stop the partnership, your business disappears instantly because you own no assets (no inventory, no original content).\n*   **Trade-off:** This "curation" approach takes more time per customer than mass-posting reels, but it is the only way to build a brand with zero budget.',
                        },
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Verified Facts LLM",
                "runtime": 5,
                "auto_runtime": 0,
                "problem_id": 0,
                "prompt": [
                    {
                        "role": "human",
                        "content": '\nYou are a strict Verified Facts Extraction Agent.\n\nYour job is to identify VERIFIED information from ONLY the evidence provided below.\n\nYou receive exactly three pieces of evidence:\n\n1. HUMAN_MESSAGE_1\n2. HUMAN_MESSAGE_2\n3. ADVISOR_REPLY\n\nSOURCE RULES:\n\n- HUMAN_MESSAGE_1 and HUMAN_MESSAGE_2 are the ONLY sources of user-provided facts.\n- ADVISOR_REPLY is the ONLY source of questions asked by the advisor.\n- Never treat anything written by the advisor as a user fact.\n- Never invent a user answer.\n- Never use older conversation history.\n- Never assume the advisor\'s statements are true.\n- Never convert an advisor suggestion into a verified fact.\n- Never create a question that does not actually appear in ADVISOR_REPLY.\n\nThe user may provide information:\n\n- before the advisor asks about it\n- after the advisor asks about it\n\nBoth are valid.\n\n--------------------------------------------------\nHUMAN MESSAGE 1\n--------------------------------------------------\n\n1. i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.\n2. nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels\n\n--------------------------------------------------\nHUMAN MESSAGE 2\n--------------------------------------------------\n\n1. i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.\n2. nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels\n\n--------------------------------------------------\nADVISOR REPLY\n--------------------------------------------------\n\n### Business Summary\nYou are operating a dropshipping model for home decor showpieces targeting Bangladeshi women. You are leveraging a supplier\'s existing content (reels) and fulfillment infrastructure (COD and shipping) to sell products priced between 2,000–4,000 BDT. You have zero budget and no physical inventory, relying entirely on Facebook for organic reach.\n\n### The Real Problem\nYour problem is not a lack of customers, but a **lack of differentiation and trust**. \n\nBecause you are using the same videos and the same prices as a supplier who already has 50k followers, you have no "Competitive Advantage." In a Cash-on-Delivery (COD) market, customers prioritize trust. A buyer has no logical reason to buy from a new page with 0 followers when they can buy the exact same item from a proven page with 50k followers.\n\n### Reasoning\nThe "big boat/small boat" theory only works if the small boat offers something the big boat doesn\'t (e.g., better service, a unique bundle, or a more personal connection). Currently, you are a mirror of the supplier. To get your first 100 customers, you must move from being a **reseller** (who just posts videos) to a **curator** (who provides value).\n\n### Prioritized Recommendations\n\n**1. Shift from "Selling" to "Styling" (Positioning)**\nStop simply reposting reels. Use the reels as a background, but add your own value through text overlays and captions.\n*   **Action:** Instead of "Buy this showpiece," create content like "3 ways to make your living room look more respectful for guests" or "How to organize your shelf to look like a luxury home."\n*   **Why:** This targets the customer\'s emotional desire (status and organization) rather than the product itself. It makes you an expert, not just a salesman.\n\n**2. Target "Micro-Niches" instead of General Groups**\nGeneric group posting fails because it looks like spam.\n*   **Action:** Find specific Bangladeshi community groups (e.g., "Home Decor Bangladesh," "Apartment Living Dhaka," or women-only community groups). Do not post "Buy this." Instead, post a photo/video and ask for opinions: *"I\'m helping a friend decorate a living room; do you think this piece looks more elegant in the corner or on the center table?"*\n*   **Why:** This starts a conversation. When people comment, you move to the Inbox (DM) to sell. This bypasses the "spam" filter and builds a personal connection.\n\n**3. Create a "First 100" Incentive**\nSince profit is not your current goal, you need a reason for people to choose you over the 50k-follower page.\n*   **Action:** Offer a "Founder\'s Special." Tell the first 100 customers they get a "Free Home Styling Consultation" (via chat) or a small discount that the big supplier doesn\'t offer.\n*   **Why:** This creates urgency and gives the customer a tangible benefit for taking a risk on a new seller.\n\n**4. The "Trust Bridge" Strategy**\nSince you have no reviews, you must borrow trust.\n*   **Action:** Be transparent. Tell customers: *"I partner with a top-rated supplier to ensure you get the best quality and fast COD delivery."* Use the supplier\'s existing customer testimonials (with permission) on your page to show the product is real and high-quality.\n*   **Why:** It removes the fear of being scammed, which is the biggest barrier for new Facebook shops.\n\n### Assumptions, Risks, and Trade-offs\n*   **Assumption:** The supplier will continue to allow you to use their content and fulfill orders without a minimum volume.\n*   **Risk:** If the supplier decides to lower their prices or stop the partnership, your business disappears instantly because you own no assets (no inventory, no original content).\n*   **Trade-off:** This "curation" approach takes more time per customer than mass-posting reels, but it is the only way to build a brand with zero budget.\n\n--------------------------------------------------\nTASK\n--------------------------------------------------\n\n1. Identify every actual question or information request in ADVISOR_REPLY.\n\n2. For each advisor question, search BOTH HUMAN_MESSAGE_1 and HUMAN_MESSAGE_2.\n\n3. If either human message explicitly answers the question, create a verified Q&A pair.\n\n4. The answer may appear before or after the advisor asked the question.\n\n5. Only use information explicitly present in the human messages.\n\n6. If no human message answers the question, do NOT create a Q&A pair.\n\n7. Extract user information that is not an answer to an advisor question as unprompted context.\n\n8. Preserve unprompted user context as closely as possible to the original wording.\n\n--------------------------------------------------\nIMPORTANT EXAMPLES\n--------------------------------------------------\n\nIf the user says:\n\n"hi"\n\nand the advisor asks:\n\n"What is your business?"\n\nthen:\n\n- qa_pairs must be empty\n- unprompted_context must be empty\n\nIf HUMAN_MESSAGE_1 says:\n\n"I sell handmade jewelry."\n\nand ADVISOR_REPLY later asks:\n\n"What is your business?"\n\nthen this is a verified Q&A pair even though the answer appeared before the question.\n\nIf ADVISOR_REPLY asks:\n\n"What is your budget?"\n\nand neither human message mentions a budget:\n\n- do not invent an answer\n- do not create a Q&A pair\n\n--------------------------------------------------\nANTI-HALLUCINATION RULES\n--------------------------------------------------\n\n- Never invent questions.\n- Never invent answers.\n- Never use information from older conversation history.\n- Never use information from ADVISOR_REPLY as a user fact.\n- Never assume the user agrees with the advisor.\n- Never turn advisor suggestions into facts.\n- Never reconstruct a conversation that is not provided.\n- When uncertain, do not guess.\n\n--------------------------------------------------\nOUTPUT\n--------------------------------------------------\n\nReturn ONLY the structured output required by the Pydantic output parser.\n\nThe output should be formatted as a JSON instance that conforms to the JSON schema below.\n\nAs an example, for the schema {"properties": {"foo": {"title": "Foo", "description": "a list of strings", "type": "array", "items": {"type": "string"}}}, "required": ["foo"]}\nthe object {"foo": ["bar", "baz"]} is a well-formatted instance of the schema. The object {"properties": {"foo": ["bar", "baz"]}} is not well-formatted.\n\nHere is the output schema:\n```\n{"$defs": {"QAPair": {"properties": {"question_asked": {"title": "Question Asked", "type": "string"}, "user_answer": {"title": "User Answer", "type": "string"}, "verification": {"enum": ["verified", "uncertain_match"], "title": "Verification", "type": "string"}}, "required": ["question_asked", "user_answer", "verification"], "title": "QAPair", "type": "object"}, "UnpromptedContext": {"properties": {"raw_text": {"title": "Raw Text", "type": "string"}, "topic_hint": {"title": "Topic Hint", "type": "string"}}, "required": ["raw_text", "topic_hint"], "title": "UnpromptedContext", "type": "object"}}, "properties": {"qa_pairs": {"items": {"$ref": "#/$defs/QAPair"}, "title": "Qa Pairs", "type": "array"}, "unprompted_context": {"items": {"$ref": "#/$defs/UnpromptedContext"}, "title": "Unprompted Context", "type": "array"}}}\n```\n',
                    }
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "text",
                            "text": '{\n  "qa_pairs": [],\n  "unprompted_context": [\n    {\n      "raw_text": "i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.",\n      "topic_hint": "pricing strategy and business goals"\n    },\n    {\n      "raw_text": "nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",\n      "topic_hint": "content creation and inventory status"\n    }\n  ]\n}',
                            "extras": {
                                "signature": "EnAKbgERTTIPOErcUnjZ4NT0iK3/6ehZIJy41NlBs+B/VI9QNz9x3mHNWNpDxJgmvjvj2qlDEW3iLhRmLVEjGPYZRQUwRdpyGCTLt9MOzLV+JewMZMz7ORuqdUfq3qUJqGpNn2/+RdhT2q1RbWB8L7Mj"
                            },
                        }
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Classifier LLM",
                "runtime": 5,
                "auto_runtime": 0,
                "problem_id": 0,
                "prompt": [
                    {
                        "role": "human",
                        "content": '\nYou are a response-state classifier.\n\nYour job is to determine whether the BUSINESS ADVISOR\'s latest\nresponse requires the USER to provide more information.\n\nReturn ONLY one of these two values:\n\nNEEDS_INPUT\n\nor\n\nDONE\n\n\nReturn NEEDS_INPUT when:\n\n- The advisor asks the user a question.\n- The advisor requests missing business information.\n- The advisor needs clarification before it can continue.\n- The advisor explicitly tells the user to provide something.\n\nReturn DONE when:\n\n- The advisor has enough information.\n- The advisor gives recommendations.\n- The advisor is explaining the analysis.\n- The advisor does not require another user response to continue.\n\nDo not explain your answer.\n\nAdvisor\'s latest response:\n\n### Business Summary\nYou are operating a dropshipping model for home decor showpieces targeting Bangladeshi women. You are leveraging a supplier\'s existing content (reels) and fulfillment infrastructure (COD and shipping) to sell products priced between 2,000–4,000 BDT. You have zero budget and no physical inventory, relying entirely on Facebook for organic reach.\n\n### The Real Problem\nYour problem is not a lack of customers, but a **lack of differentiation and trust**. \n\nBecause you are using the same videos and the same prices as a supplier who already has 50k followers, you have no "Competitive Advantage." In a Cash-on-Delivery (COD) market, customers prioritize trust. A buyer has no logical reason to buy from a new page with 0 followers when they can buy the exact same item from a proven page with 50k followers.\n\n### Reasoning\nThe "big boat/small boat" theory only works if the small boat offers something the big boat doesn\'t (e.g., better service, a unique bundle, or a more personal connection). Currently, you are a mirror of the supplier. To get your first 100 customers, you must move from being a **reseller** (who just posts videos) to a **curator** (who provides value).\n\n### Prioritized Recommendations\n\n**1. Shift from "Selling" to "Styling" (Positioning)**\nStop simply reposting reels. Use the reels as a background, but add your own value through text overlays and captions.\n*   **Action:** Instead of "Buy this showpiece," create content like "3 ways to make your living room look more respectful for guests" or "How to organize your shelf to look like a luxury home."\n*   **Why:** This targets the customer\'s emotional desire (status and organization) rather than the product itself. It makes you an expert, not just a salesman.\n\n**2. Target "Micro-Niches" instead of General Groups**\nGeneric group posting fails because it looks like spam.\n*   **Action:** Find specific Bangladeshi community groups (e.g., "Home Decor Bangladesh," "Apartment Living Dhaka," or women-only community groups). Do not post "Buy this." Instead, post a photo/video and ask for opinions: *"I\'m helping a friend decorate a living room; do you think this piece looks more elegant in the corner or on the center table?"*\n*   **Why:** This starts a conversation. When people comment, you move to the Inbox (DM) to sell. This bypasses the "spam" filter and builds a personal connection.\n\n**3. Create a "First 100" Incentive**\nSince profit is not your current goal, you need a reason for people to choose you over the 50k-follower page.\n*   **Action:** Offer a "Founder\'s Special." Tell the first 100 customers they get a "Free Home Styling Consultation" (via chat) or a small discount that the big supplier doesn\'t offer.\n*   **Why:** This creates urgency and gives the customer a tangible benefit for taking a risk on a new seller.\n\n**4. The "Trust Bridge" Strategy**\nSince you have no reviews, you must borrow trust.\n*   **Action:** Be transparent. Tell customers: *"I partner with a top-rated supplier to ensure you get the best quality and fast COD delivery."* Use the supplier\'s existing customer testimonials (with permission) on your page to show the product is real and high-quality.\n*   **Why:** It removes the fear of being scammed, which is the biggest barrier for new Facebook shops.\n\n### Assumptions, Risks, and Trade-offs\n*   **Assumption:** The supplier will continue to allow you to use their content and fulfill orders without a minimum volume.\n*   **Risk:** If the supplier decides to lower their prices or stop the partnership, your business disappears instantly because you own no assets (no inventory, no original content).\n*   **Trade-off:** This "curation" approach takes more time per customer than mass-posting reels, but it is the only way to build a brand with zero budget.\n',
                    }
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "text",
                            "text": "DONE",
                            "extras": {
                                "signature": "EnAKbgERTTIP6YUQICbR0TfkFkPwZqqfGY/baMOZv4mZt/sDQLqgIhnIZsuEXr/A+TtBEfp+UUEM8+ltFq16irtClHB9DhW1COTK1vFC0nrjH4sbKNRIlbJ3XdeXPcM/7xIWOPkF/pwwGuEm7sxL4az9"
                            },
                        }
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Systematic Advice Converter LLM",
                "runtime": 5,
                "auto_runtime": 0,
                "problem_id": 0,
                "prompt": [
                    {
                        "role": "system",
                        "content": "\nConvert the advisor reply into the BusinessStrategyBrief schema.\n\nExtract only what is stated or clearly implied in the advisor reply.\nNever invent facts.\n",
                    },
                    {
                        "role": "human",
                        "content": '### Business Summary\nYou are operating a dropshipping model for home decor showpieces targeting Bangladeshi women. You are leveraging a supplier\'s existing content (reels) and fulfillment infrastructure (COD and shipping) to sell products priced between 2,000–4,000 BDT. You have zero budget and no physical inventory, relying entirely on Facebook for organic reach.\n\n### The Real Problem\nYour problem is not a lack of customers, but a **lack of differentiation and trust**. \n\nBecause you are using the same videos and the same prices as a supplier who already has 50k followers, you have no "Competitive Advantage." In a Cash-on-Delivery (COD) market, customers prioritize trust. A buyer has no logical reason to buy from a new page with 0 followers when they can buy the exact same item from a proven page with 50k followers.\n\n### Reasoning\nThe "big boat/small boat" theory only works if the small boat offers something the big boat doesn\'t (e.g., better service, a unique bundle, or a more personal connection). Currently, you are a mirror of the supplier. To get your first 100 customers, you must move from being a **reseller** (who just posts videos) to a **curator** (who provides value).\n\n### Prioritized Recommendations\n\n**1. Shift from "Selling" to "Styling" (Positioning)**\nStop simply reposting reels. Use the reels as a background, but add your own value through text overlays and captions.\n*   **Action:** Instead of "Buy this showpiece," create content like "3 ways to make your living room look more respectful for guests" or "How to organize your shelf to look like a luxury home."\n*   **Why:** This targets the customer\'s emotional desire (status and organization) rather than the product itself. It makes you an expert, not just a salesman.\n\n**2. Target "Micro-Niches" instead of General Groups**\nGeneric group posting fails because it looks like spam.\n*   **Action:** Find specific Bangladeshi community groups (e.g., "Home Decor Bangladesh," "Apartment Living Dhaka," or women-only community groups). Do not post "Buy this." Instead, post a photo/video and ask for opinions: *"I\'m helping a friend decorate a living room; do you think this piece looks more elegant in the corner or on the center table?"*\n*   **Why:** This starts a conversation. When people comment, you move to the Inbox (DM) to sell. This bypasses the "spam" filter and builds a personal connection.\n\n**3. Create a "First 100" Incentive**\nSince profit is not your current goal, you need a reason for people to choose you over the 50k-follower page.\n*   **Action:** Offer a "Founder\'s Special." Tell the first 100 customers they get a "Free Home Styling Consultation" (via chat) or a small discount that the big supplier doesn\'t offer.\n*   **Why:** This creates urgency and gives the customer a tangible benefit for taking a risk on a new seller.\n\n**4. The "Trust Bridge" Strategy**\nSince you have no reviews, you must borrow trust.\n*   **Action:** Be transparent. Tell customers: *"I partner with a top-rated supplier to ensure you get the best quality and fast COD delivery."* Use the supplier\'s existing customer testimonials (with permission) on your page to show the product is real and high-quality.\n*   **Why:** It removes the fear of being scammed, which is the biggest barrier for new Facebook shops.\n\n### Assumptions, Risks, and Trade-offs\n*   **Assumption:** The supplier will continue to allow you to use their content and fulfill orders without a minimum volume.\n*   **Risk:** If the supplier decides to lower their prices or stop the partnership, your business disappears instantly because you own no assets (no inventory, no original content).\n*   **Trade-off:** This "curation" approach takes more time per customer than mass-posting reels, but it is the only way to build a brand with zero budget.',
                    },
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "text",
                            "text": '{\n  "title": "From Reseller to Curator: Building Trust in Dropshipping",\n  "business_summary": {\n    "business_model": "Dropshipping",\n    "product_category": "Home decor showpieces",\n    "price_range_bdt": {\n      "min": 2000,\n      "max": 4000\n    },\n    "target_customer": "Bangladeshi women",\n    "market": "Bangladesh",\n    "fulfillment": "Supplier handles inventory, shipping, and COD",\n    "constraints": [\n      "Zero budget",\n      "No physical inventory",\n      "Relying entirely on Facebook organic reach"\n    ]\n  },\n  "real_problem": {\n    "surface_problem": "Lack of customers",\n    "actual_problem": "Lack of differentiation and trust compared to established competitors",\n    "supporting_context": [\n      "Using identical content and pricing as a supplier with 50k followers",\n      "Customers prioritize trust in a COD market",\n      "No logical reason for buyers to choose a new page over a proven one"\n    ]\n  },\n  "strategy_reasoning": {\n    "core_constraint": "Zero budget and lack of competitive advantage",\n    "approach": "Transition from a reseller to a curator by providing value-added content and personal connection",\n    "channels": [\n      "Facebook organic reach",\n      "Facebook community groups",\n      "Direct Messaging (DM)"\n    ]\n  },\n  "prioritized_action_plan": [\n    {\n      "priority": 1,\n      "title": "Shift from Selling to Styling",\n      "action": "Reposition content to focus on home styling advice rather than direct product sales",\n      "execution": [\n        "Use supplier reels as background content",\n        "Add original text overlays and captions",\n        "Create content focused on status and organization"\n      ]\n    },\n    {\n      "priority": 2,\n      "title": "Target Micro-Niches",\n      "action": "Engage in specific community groups to start conversations instead of posting spam",\n      "execution": [\n        "Identify specific Bangladeshi home decor and women-only groups",\n        "Post content asking for opinions to spark engagement",\n        "Move interested users to DM for sales"\n      ]\n    },\n    {\n      "priority": 3,\n      "title": "Create a First 100 Incentive",\n      "action": "Offer unique value to early customers to overcome the lack of social proof",\n      "execution": [\n        "Offer a free home styling consultation via chat",\n        "Provide a small discount not offered by the main supplier"\n      ]\n    },\n    {\n      "priority": 4,\n      "title": "The Trust Bridge Strategy",\n      "action": "Leverage transparency and existing social proof to build credibility",\n      "execution": [\n        "Disclose the partnership with the top-rated supplier",\n        "Use supplier testimonials with permission to demonstrate product quality"\n      ]\n    }\n  ],\n  "assumptions_risks_tradeoffs": {\n    "assumptions": [\n      "The supplier will continue to allow the use of their content and fulfillment services without minimum volume requirements"\n    ],\n    "risks": [\n      {\n        "risk": "Supplier changes pricing or terminates partnership",\n        "impact": "Business model fails as there are no owned assets or inventory",\n        "mitigation": null\n      }\n    ],\n    "tradeoffs": [\n      "The curation approach requires significantly more time per customer compared to mass-posting reels"\n    ]\n  }\n}',
                            "extras": {
                                "signature": "EnAKbgERTTIPZK2FHCeLao8yh7iScKiV7LyhgVRM1aBtKQDIxw639IHvYov7m4eikN1nY7f/cbyJlYN7fgMwLZyrhfW5wgZKRNadnqz2spkuEyFODXqWfklFi9H4446eg3zovbHbVqdmfk2hb1c5ssHM"
                            },
                        }
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Reality-Check Critic #1",
                "runtime": 5,
                "auto_runtime": 0,
                "problem_id": 0,
                "prompt": {
                    "verified_context": [
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i want 100 first customers in my business",
                                    "topic_hint": "business goal",
                                }
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i want 100 first customers in my business",
                                    "topic_hint": "business goal",
                                },
                                {
                                    "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",
                                    "topic_hint": "product and target audience",
                                },
                                {
                                    "raw_text": "my product avg price point is 2000-4000 tk. and i already told you about typical buyers.",
                                    "topic_hint": "pricing",
                                },
                                {
                                    "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                                    "topic_hint": "business model and operations",
                                },
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",
                                    "topic_hint": "business description and target audience",
                                },
                                {
                                    "raw_text": "my product avg price point is 2000-4000 tk.",
                                    "topic_hint": "pricing",
                                },
                                {
                                    "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team.",
                                    "topic_hint": "business resources and budget",
                                },
                                {
                                    "raw_text": "my products are coming from a supplier who is already successfully selling his this iteams on facebook... i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                                    "topic_hint": "business model and supplier agreement",
                                },
                                {
                                    "raw_text": "in ocean if a big boat come to catch fish that not mean others boat will not get any fishes... same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.",
                                    "topic_hint": "market analysis and customer behavior",
                                },
                                {
                                    "raw_text": "just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",
                                    "topic_hint": "distribution plan",
                                },
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.",
                                    "topic_hint": "pricing strategy and business goals",
                                },
                                {
                                    "raw_text": "nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",
                                    "topic_hint": "content creation and inventory status",
                                },
                            ],
                        },
                    ],
                    "advisor_strategy": {
                        "title": "From Reseller to Curator: Building Trust in Dropshipping",
                        "business_summary": {
                            "business_model": "Dropshipping",
                            "product_category": "Home decor showpieces",
                            "price_range_bdt": {"min": 2000, "max": 4000},
                            "target_customer": "Bangladeshi women",
                            "market": "Bangladesh",
                            "fulfillment": "Supplier handles inventory, shipping, and COD",
                            "constraints": [
                                "Zero budget",
                                "No physical inventory",
                                "Relying entirely on Facebook organic reach",
                            ],
                        },
                        "real_problem": {
                            "surface_problem": "Lack of customers",
                            "actual_problem": "Lack of differentiation and trust compared to established competitors",
                            "supporting_context": [
                                "Using identical content and pricing as a supplier with 50k followers",
                                "Customers prioritize trust in a COD market",
                                "No logical reason for buyers to choose a new page over a proven one",
                            ],
                        },
                        "strategy_reasoning": {
                            "core_constraint": "Zero budget and lack of competitive advantage",
                            "approach": "Transition from a reseller to a curator by providing value-added content and personal connection",
                            "channels": [
                                "Facebook organic reach",
                                "Facebook community groups",
                                "Direct Messaging (DM)",
                            ],
                        },
                        "assumptions_risks_tradeoffs": {
                            "assumptions": [
                                "The supplier will continue to allow the use of their content and fulfillment services without minimum volume requirements"
                            ],
                            "risks": [
                                {
                                    "risk": "Supplier changes pricing or terminates partnership",
                                    "impact": "Business model fails as there are no owned assets or inventory",
                                    "mitigation": 0,
                                }
                            ],
                            "tradeoffs": [
                                "The curation approach requires significantly more time per customer compared to mass-posting reels"
                            ],
                        },
                        "prioritized_action_plan": [
                            {
                                "priority": 1,
                                "title": "Shift from Selling to Styling",
                                "action": "Reposition content to focus on home styling advice rather than direct product sales",
                                "execution": [
                                    "Use supplier reels as background content",
                                    "Add original text overlays and captions",
                                    "Create content focused on status and organization",
                                ],
                            }
                        ],
                    },
                    "target_action": {
                        "priority": 1,
                        "title": "Shift from Selling to Styling",
                        "action": "Reposition content to focus on home styling advice rather than direct product sales",
                        "execution": [
                            "Use supplier reels as background content",
                            "Add original text overlays and captions",
                            "Create content focused on status and organization",
                        ],
                    },
                },
                "output": {
                    "action_title": "Shift from Selling to Styling",
                    "claim": "Reposition content to focus on home styling advice rather than direct product sales to differentiate from competitors and build trust.",
                    "mechanism": "By providing value-added content (styling advice) instead of just product listings, the business creates a reason for customers to follow and trust the page, differentiating it from the supplier and other low-price competitors.",
                    "load_bearing_assumptions": [
                        {
                            "assumption": "Target customers (Bangladeshi women) value styling advice enough to engage with a new, unknown page.",
                            "classification": "ASSUMPTION",
                            "evidence": "This requires testing whether the target audience seeks styling advice from a non-expert/new page or if they prioritize the established reputation of the supplier.",
                        },
                        {
                            "assumption": "Adding text overlays and captions to supplier reels is sufficient to differentiate the page from the supplier's own page and other competitors.",
                            "classification": "ASSUMPTION",
                            "evidence": "This assumes that the audience perceives the value-add of the text/captions as greater than the risk of buying from a new, unproven seller.",
                        },
                        {
                            "assumption": "The supplier's reels are visually compatible with a 'styling advice' narrative rather than just a 'product showcase' narrative.",
                            "classification": "ASSUMPTION",
                            "evidence": "This depends on the specific content of the supplier's reels, which are currently used for direct sales.",
                        },
                    ],
                    "structural_flags": [],
                    "settled_as_fact_violation": 0,
                    "verdict": "CONDITIONAL",
                    "verdict_reason": "The strategy relies on the assumption that styling advice will successfully differentiate the business and build enough trust to overcome the lack of a track record, which is unverified. Success depends on whether the target audience values this curation enough to choose a new, unproven seller over established competitors.",
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Reality-Check Critic #2",
                "runtime": 5,
                "auto_runtime": 0,
                "problem_id": 0,
                "prompt": {
                    "verified_context": [
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i want 100 first customers in my business",
                                    "topic_hint": "business goal",
                                }
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i want 100 first customers in my business",
                                    "topic_hint": "business goal",
                                },
                                {
                                    "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",
                                    "topic_hint": "product and target audience",
                                },
                                {
                                    "raw_text": "my product avg price point is 2000-4000 tk. and i already told you about typical buyers.",
                                    "topic_hint": "pricing",
                                },
                                {
                                    "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                                    "topic_hint": "business model and operations",
                                },
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",
                                    "topic_hint": "business description and target audience",
                                },
                                {
                                    "raw_text": "my product avg price point is 2000-4000 tk.",
                                    "topic_hint": "pricing",
                                },
                                {
                                    "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team.",
                                    "topic_hint": "business resources and budget",
                                },
                                {
                                    "raw_text": "my products are coming from a supplier who is already successfully selling his this iteams on facebook... i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                                    "topic_hint": "business model and supplier agreement",
                                },
                                {
                                    "raw_text": "in ocean if a big boat come to catch fish that not mean others boat will not get any fishes... same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.",
                                    "topic_hint": "market analysis and customer behavior",
                                },
                                {
                                    "raw_text": "just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",
                                    "topic_hint": "distribution plan",
                                },
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.",
                                    "topic_hint": "pricing strategy and business goals",
                                },
                                {
                                    "raw_text": "nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",
                                    "topic_hint": "content creation and inventory status",
                                },
                            ],
                        },
                    ],
                    "advisor_strategy": {
                        "title": "From Reseller to Curator: Building Trust in Dropshipping",
                        "business_summary": {
                            "business_model": "Dropshipping",
                            "product_category": "Home decor showpieces",
                            "price_range_bdt": {"min": 2000, "max": 4000},
                            "target_customer": "Bangladeshi women",
                            "market": "Bangladesh",
                            "fulfillment": "Supplier handles inventory, shipping, and COD",
                            "constraints": [
                                "Zero budget",
                                "No physical inventory",
                                "Relying entirely on Facebook organic reach",
                            ],
                        },
                        "real_problem": {
                            "surface_problem": "Lack of customers",
                            "actual_problem": "Lack of differentiation and trust compared to established competitors",
                            "supporting_context": [
                                "Using identical content and pricing as a supplier with 50k followers",
                                "Customers prioritize trust in a COD market",
                                "No logical reason for buyers to choose a new page over a proven one",
                            ],
                        },
                        "strategy_reasoning": {
                            "core_constraint": "Zero budget and lack of competitive advantage",
                            "approach": "Transition from a reseller to a curator by providing value-added content and personal connection",
                            "channels": [
                                "Facebook organic reach",
                                "Facebook community groups",
                                "Direct Messaging (DM)",
                            ],
                        },
                        "assumptions_risks_tradeoffs": {
                            "assumptions": [
                                "The supplier will continue to allow the use of their content and fulfillment services without minimum volume requirements"
                            ],
                            "risks": [
                                {
                                    "risk": "Supplier changes pricing or terminates partnership",
                                    "impact": "Business model fails as there are no owned assets or inventory",
                                    "mitigation": 0,
                                }
                            ],
                            "tradeoffs": [
                                "The curation approach requires significantly more time per customer compared to mass-posting reels"
                            ],
                        },
                        "prioritized_action_plan": [
                            {
                                "priority": 2,
                                "title": "Target Micro-Niches",
                                "action": "Engage in specific community groups to start conversations instead of posting spam",
                                "execution": [
                                    "Identify specific Bangladeshi home decor and women-only groups",
                                    "Post content asking for opinions to spark engagement",
                                    "Move interested users to DM for sales",
                                ],
                            }
                        ],
                    },
                    "target_action": {
                        "priority": 2,
                        "title": "Target Micro-Niches",
                        "action": "Engage in specific community groups to start conversations instead of posting spam",
                        "execution": [
                            "Identify specific Bangladeshi home decor and women-only groups",
                            "Post content asking for opinions to spark engagement",
                            "Move interested users to DM for sales",
                        ],
                    },
                },
                "output": {
                    "action_title": "Target Micro-Niches",
                    "claim": "Engaging in specific community groups to start conversations will help acquire the first 100 customers.",
                    "mechanism": "By moving from spamming groups to initiating genuine conversations in niche communities, the seller builds trust and engagement, which eventually leads to sales conversions.",
                    "load_bearing_assumptions": [
                        {
                            "assumption": "Bangladeshi home decor and women-only Facebook groups allow promotional engagement or opinion-seeking posts from new business pages.",
                            "classification": "ASSUMPTION",
                            "evidence": "Need to verify group rules and community tolerance for new business accounts seeking engagement.",
                        },
                        {
                            "assumption": "The target audience (Bangladeshi women) is willing to engage with a new, unknown page in these groups.",
                            "classification": "ASSUMPTION",
                            "evidence": "Need to verify if the target demographic is receptive to engagement-bait or opinion-seeking posts from non-established sellers.",
                        },
                        {
                            "assumption": "The user has the capacity to manage these conversations and convert them to sales without a budget.",
                            "classification": "ASSUMPTION",
                            "evidence": "The user is a solo seller with no team and no budget, relying on organic reach.",
                        },
                    ],
                    "structural_flags": [
                        {
                            "flaw_type": "relevance_mismatch",
                            "explanation": "The user explicitly stated in the context: 'i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.' The suggestion ignores this direct experience.",
                        }
                    ],
                    "settled_as_fact_violation": 0,
                    "verdict": "FAIL",
                    "verdict_reason": "The suggestion directly contradicts the user's stated experience that group sharing has already been attempted and failed to generate engagement. Furthermore, it fails to address the core problem of lack of differentiation, as simply asking for opinions in groups does not provide a compelling reason for customers to choose a new, unknown seller over established competitors.",
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Reality-Check Critic #3",
                "runtime": 5,
                "auto_runtime": 0,
                "problem_id": 0,
                "prompt": {
                    "verified_context": [
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i want 100 first customers in my business",
                                    "topic_hint": "business goal",
                                }
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i want 100 first customers in my business",
                                    "topic_hint": "business goal",
                                },
                                {
                                    "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",
                                    "topic_hint": "product and target audience",
                                },
                                {
                                    "raw_text": "my product avg price point is 2000-4000 tk. and i already told you about typical buyers.",
                                    "topic_hint": "pricing",
                                },
                                {
                                    "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                                    "topic_hint": "business model and operations",
                                },
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",
                                    "topic_hint": "business description and target audience",
                                },
                                {
                                    "raw_text": "my product avg price point is 2000-4000 tk.",
                                    "topic_hint": "pricing",
                                },
                                {
                                    "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team.",
                                    "topic_hint": "business resources and budget",
                                },
                                {
                                    "raw_text": "my products are coming from a supplier who is already successfully selling his this iteams on facebook... i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                                    "topic_hint": "business model and supplier agreement",
                                },
                                {
                                    "raw_text": "in ocean if a big boat come to catch fish that not mean others boat will not get any fishes... same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.",
                                    "topic_hint": "market analysis and customer behavior",
                                },
                                {
                                    "raw_text": "just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",
                                    "topic_hint": "distribution plan",
                                },
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.",
                                    "topic_hint": "pricing strategy and business goals",
                                },
                                {
                                    "raw_text": "nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",
                                    "topic_hint": "content creation and inventory status",
                                },
                            ],
                        },
                    ],
                    "advisor_strategy": {
                        "title": "From Reseller to Curator: Building Trust in Dropshipping",
                        "business_summary": {
                            "business_model": "Dropshipping",
                            "product_category": "Home decor showpieces",
                            "price_range_bdt": {"min": 2000, "max": 4000},
                            "target_customer": "Bangladeshi women",
                            "market": "Bangladesh",
                            "fulfillment": "Supplier handles inventory, shipping, and COD",
                            "constraints": [
                                "Zero budget",
                                "No physical inventory",
                                "Relying entirely on Facebook organic reach",
                            ],
                        },
                        "real_problem": {
                            "surface_problem": "Lack of customers",
                            "actual_problem": "Lack of differentiation and trust compared to established competitors",
                            "supporting_context": [
                                "Using identical content and pricing as a supplier with 50k followers",
                                "Customers prioritize trust in a COD market",
                                "No logical reason for buyers to choose a new page over a proven one",
                            ],
                        },
                        "strategy_reasoning": {
                            "core_constraint": "Zero budget and lack of competitive advantage",
                            "approach": "Transition from a reseller to a curator by providing value-added content and personal connection",
                            "channels": [
                                "Facebook organic reach",
                                "Facebook community groups",
                                "Direct Messaging (DM)",
                            ],
                        },
                        "assumptions_risks_tradeoffs": {
                            "assumptions": [
                                "The supplier will continue to allow the use of their content and fulfillment services without minimum volume requirements"
                            ],
                            "risks": [
                                {
                                    "risk": "Supplier changes pricing or terminates partnership",
                                    "impact": "Business model fails as there are no owned assets or inventory",
                                    "mitigation": 0,
                                }
                            ],
                            "tradeoffs": [
                                "The curation approach requires significantly more time per customer compared to mass-posting reels"
                            ],
                        },
                        "prioritized_action_plan": [
                            {
                                "priority": 3,
                                "title": "Create a First 100 Incentive",
                                "action": "Offer unique value to early customers to overcome the lack of social proof",
                                "execution": [
                                    "Offer a free home styling consultation via chat",
                                    "Provide a small discount not offered by the main supplier",
                                ],
                            }
                        ],
                    },
                    "target_action": {
                        "priority": 3,
                        "title": "Create a First 100 Incentive",
                        "action": "Offer unique value to early customers to overcome the lack of social proof",
                        "execution": [
                            "Offer a free home styling consultation via chat",
                            "Provide a small discount not offered by the main supplier",
                        ],
                    },
                },
                "output": {
                    "action_title": "Create a First 100 Incentive",
                    "claim": "Offering a free home styling consultation and a small discount will help overcome the lack of social proof and attract the first 100 customers.",
                    "mechanism": "By providing unique value (consultation) and a price advantage (discount), the seller differentiates themselves from the supplier and other competitors, thereby building trust and incentivizing purchases despite having no social proof.",
                    "load_bearing_assumptions": [
                        {
                            "assumption": "The supplier will allow the seller to set a price lower than the supplier's own price.",
                            "classification": "ASSUMPTION",
                            "evidence": "The context states the seller has authority to set their own price, but it is unclear if the supplier's fulfillment/COD agreement allows for a price lower than the supplier's own retail price, which could create channel conflict.",
                        },
                        {
                            "assumption": "The target audience (Bangladeshi women) values a home styling consultation enough to choose a new, unproven seller over an established one.",
                            "classification": "ASSUMPTION",
                            "evidence": "This is a behavioral assumption about the target market's decision-making process that is not confirmed in the context.",
                        },
                        {
                            "assumption": "The seller has the expertise to provide a credible home styling consultation.",
                            "classification": "ASSUMPTION",
                            "evidence": "The context does not mention the seller's background or ability to provide professional home styling advice.",
                        },
                    ],
                    "structural_flags": [],
                    "settled_as_fact_violation": 0,
                    "verdict": "CONDITIONAL",
                    "verdict_reason": "The mechanism relies on the seller's ability to offer a lower price and provide value-added services (consultation), but it is unverified whether the supplier's agreement permits price undercutting and whether the seller possesses the necessary expertise to make the consultation a compelling differentiator.",
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Reality-Check Critic #4",
                "runtime": 5,
                "auto_runtime": 0,
                "problem_id": 0,
                "prompt": {
                    "verified_context": [
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i want 100 first customers in my business",
                                    "topic_hint": "business goal",
                                }
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i want 100 first customers in my business",
                                    "topic_hint": "business goal",
                                },
                                {
                                    "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",
                                    "topic_hint": "product and target audience",
                                },
                                {
                                    "raw_text": "my product avg price point is 2000-4000 tk. and i already told you about typical buyers.",
                                    "topic_hint": "pricing",
                                },
                                {
                                    "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                                    "topic_hint": "business model and operations",
                                },
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",
                                    "topic_hint": "business description and target audience",
                                },
                                {
                                    "raw_text": "my product avg price point is 2000-4000 tk.",
                                    "topic_hint": "pricing",
                                },
                                {
                                    "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team.",
                                    "topic_hint": "business resources and budget",
                                },
                                {
                                    "raw_text": "my products are coming from a supplier who is already successfully selling his this iteams on facebook... i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                                    "topic_hint": "business model and supplier agreement",
                                },
                                {
                                    "raw_text": "in ocean if a big boat come to catch fish that not mean others boat will not get any fishes... same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.",
                                    "topic_hint": "market analysis and customer behavior",
                                },
                                {
                                    "raw_text": "just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",
                                    "topic_hint": "distribution plan",
                                },
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.",
                                    "topic_hint": "pricing strategy and business goals",
                                },
                                {
                                    "raw_text": "nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",
                                    "topic_hint": "content creation and inventory status",
                                },
                            ],
                        },
                    ],
                    "advisor_strategy": {
                        "title": "From Reseller to Curator: Building Trust in Dropshipping",
                        "business_summary": {
                            "business_model": "Dropshipping",
                            "product_category": "Home decor showpieces",
                            "price_range_bdt": {"min": 2000, "max": 4000},
                            "target_customer": "Bangladeshi women",
                            "market": "Bangladesh",
                            "fulfillment": "Supplier handles inventory, shipping, and COD",
                            "constraints": [
                                "Zero budget",
                                "No physical inventory",
                                "Relying entirely on Facebook organic reach",
                            ],
                        },
                        "real_problem": {
                            "surface_problem": "Lack of customers",
                            "actual_problem": "Lack of differentiation and trust compared to established competitors",
                            "supporting_context": [
                                "Using identical content and pricing as a supplier with 50k followers",
                                "Customers prioritize trust in a COD market",
                                "No logical reason for buyers to choose a new page over a proven one",
                            ],
                        },
                        "strategy_reasoning": {
                            "core_constraint": "Zero budget and lack of competitive advantage",
                            "approach": "Transition from a reseller to a curator by providing value-added content and personal connection",
                            "channels": [
                                "Facebook organic reach",
                                "Facebook community groups",
                                "Direct Messaging (DM)",
                            ],
                        },
                        "assumptions_risks_tradeoffs": {
                            "assumptions": [
                                "The supplier will continue to allow the use of their content and fulfillment services without minimum volume requirements"
                            ],
                            "risks": [
                                {
                                    "risk": "Supplier changes pricing or terminates partnership",
                                    "impact": "Business model fails as there are no owned assets or inventory",
                                    "mitigation": 0,
                                }
                            ],
                            "tradeoffs": [
                                "The curation approach requires significantly more time per customer compared to mass-posting reels"
                            ],
                        },
                        "prioritized_action_plan": [
                            {
                                "priority": 4,
                                "title": "The Trust Bridge Strategy",
                                "action": "Leverage transparency and existing social proof to build credibility",
                                "execution": [
                                    "Disclose the partnership with the top-rated supplier",
                                    "Use supplier testimonials with permission to demonstrate product quality",
                                ],
                            }
                        ],
                    },
                    "target_action": {
                        "priority": 4,
                        "title": "The Trust Bridge Strategy",
                        "action": "Leverage transparency and existing social proof to build credibility",
                        "execution": [
                            "Disclose the partnership with the top-rated supplier",
                            "Use supplier testimonials with permission to demonstrate product quality",
                        ],
                    },
                },
                "output": {
                    "action_title": "The Trust Bridge Strategy",
                    "claim": "Disclosing a partnership with a supplier and using their testimonials will build credibility and trust for a new, unknown Facebook page.",
                    "mechanism": "By associating the new, unknown page with an established, trusted supplier, the reseller hopes to transfer the supplier's credibility to their own page, thereby overcoming the 'new seller' trust barrier.",
                    "load_bearing_assumptions": [
                        {
                            "assumption": "Customers will perceive a partnership with a supplier as a trust signal rather than a reason to bypass the reseller and go directly to the supplier.",
                            "classification": "ASSUMPTION",
                            "evidence": "This requires testing whether the target audience values the reseller's curation or views them as an unnecessary middleman.",
                        },
                        {
                            "assumption": "The supplier will grant permission to use their testimonials and explicitly endorse the reseller's page.",
                            "classification": "ASSUMPTION",
                            "evidence": "The current agreement only covers the use of reels; testimonial usage is not confirmed.",
                        },
                        {
                            "assumption": "The target audience (Bangladeshi women) prioritizes 'trust' in a way that is satisfied by a reseller's disclosure of their supplier.",
                            "classification": "ASSUMPTION",
                            "evidence": "The context states customers compare prices across multiple sellers; it is unclear if they value the reseller's transparency over the lowest price.",
                        },
                    ],
                    "structural_flags": [],
                    "settled_as_fact_violation": 0,
                    "verdict": "CONDITIONAL",
                    "verdict_reason": "The strategy assumes that disclosing the supplier will build trust rather than encouraging customers to bypass the reseller to find the original, lower-priced source. This is a significant risk given the context that customers actively compare prices and seek the lowest-priced seller.",
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Problem Explainer",
                "runtime": 5,
                "auto_runtime": 0,
                "problem_id": 0,
                "prompt": [
                    {
                        "role": "system",
                        "content": "\nYou are a Problem Explainer.\n\nYour job is to examine a conditional critic result and determine\nwhether it represents a DISTINCT NEW PROBLEM that should be sent\nback to the advisor as a child problem.\n\nYou do NOT solve the problem.\n\nYou do NOT improve the advisor's strategy.\n\nYou do NOT invent facts.\n\n============================================================\nINPUTS\n============================================================\n\nYou receive:\n\n1. CURRENT_PROBLEM\n   The problem currently being solved.\n\n2. CONDITIONAL_CRITIC\n   The critic's analysis of one action from the advisor's strategy.\n\n3. VERIFIED_FACTS\n   Facts already verified about the business.\n\n============================================================\nNEW PROBLEM TEST\n============================================================\n\nCreate NEW_PROBLEM only when the critic reveals a distinct issue\nthat requires its own reasoning and solution.\n\nA conditional critic does NOT automatically create a new problem.\n\nDo NOT create a new problem when the critic is only saying:\n\n- more evidence is needed\n- an assumption should be checked\n- a minor caveat exists\n- an execution detail is uncertain\n- the action may work under certain conditions\n\nCreate NEW_PROBLEM when the critic reveals something like:\n\n- the strategy depends on a real unresolved business constraint\n- the recommendation requires solving another substantive issue first\n- a missing capability/resource must be established before the\n  original strategy can work\n- the critic exposes a distinct obstacle that deserves its own\n  advisor-level solution\n\n============================================================\nPROBLEM FORMULATION\n============================================================\n\nWhen NEW_PROBLEM:\n\n- State the problem clearly.\n- Make it actionable for the advisor.\n- Preserve the critic's meaning.\n- Use verified facts as context.\n- Do not invent causes, facts, or solutions.\n- Do not include the solution in the problem statement.\n\nThe new problem will later be pushed on top of the current\nproblem stack and sent to the advisor.\n\n============================================================\nPARENT RELATIONSHIP\n============================================================\n\nThe new problem must be a CHILD of CURRENT_PROBLEM.\n\nIt should address the issue raised by the critic, not replace\nthe parent problem.\n\n============================================================\nOUTPUT\n============================================================\n\nReturn only the structured result defined by the output schema.\n",
                    },
                    {
                        "role": "human",
                        "content": '\nCURRENT_PROBLEM:\n\n{\n  "problem_id": 0,\n  "parent_problem_id": 0,\n  "depth": 0,\n  "problem": "Acquire the first 100 customers for the business.",\n  "runtime": 1,\n  "auto_runtime": 0,\n  "agent": "Advisor",\n  "status": "WAITING_FOR_CHILD",\n  "solution": null\n}\n\n\nCONDITIONAL_CRITIC:\n\n{\n  "action_title": "Shift from Selling to Styling",\n  "claim": "Reposition content to focus on home styling advice rather than direct product sales to differentiate from competitors and build trust.",\n  "mechanism": "By providing value-added content (styling advice) instead of just product listings, the business creates a reason for customers to follow and trust the page, differentiating it from the supplier and other low-price competitors.",\n  "load_bearing_assumptions": [\n    {\n      "assumption": "Target customers (Bangladeshi women) value styling advice enough to engage with a new, unknown page.",\n      "classification": "ASSUMPTION",\n      "evidence": "This requires testing whether the target audience seeks styling advice from a non-expert/new page or if they prioritize the established reputation of the supplier."\n    },\n    {\n      "assumption": "Adding text overlays and captions to supplier reels is sufficient to differentiate the page from the supplier\'s own page and other competitors.",\n      "classification": "ASSUMPTION",\n      "evidence": "This assumes that the audience perceives the value-add of the text/captions as greater than the risk of buying from a new, unproven seller."\n    },\n    {\n      "assumption": "The supplier\'s reels are visually compatible with a \'styling advice\' narrative rather than just a \'product showcase\' narrative.",\n      "classification": "ASSUMPTION",\n      "evidence": "This depends on the specific content of the supplier\'s reels, which are currently used for direct sales."\n    }\n  ],\n  "structural_flags": [],\n  "settled_as_fact_violation": 0,\n  "verdict": "CONDITIONAL",\n  "verdict_reason": "The strategy relies on the assumption that styling advice will successfully differentiate the business and build enough trust to overcome the lack of a track record, which is unverified. Success depends on whether the target audience values this curation enough to choose a new, unproven seller over established competitors."\n}\n\n\nVERIFIED_FACTS:\n\n[\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i want 100 first customers in my business",\n        "topic_hint": "business goal"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i want 100 first customers in my business",\n        "topic_hint": "business goal"\n      },\n      {\n        "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman\'s, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",\n        "topic_hint": "product and target audience"\n      },\n      {\n        "raw_text": "my product avg price point is 2000-4000 tk. and i already told you about typical buyers.",\n        "topic_hint": "pricing"\n      },\n      {\n        "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",\n        "topic_hint": "business model and operations"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman\'s, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",\n        "topic_hint": "business description and target audience"\n      },\n      {\n        "raw_text": "my product avg price point is 2000-4000 tk.",\n        "topic_hint": "pricing"\n      },\n      {\n        "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team.",\n        "topic_hint": "business resources and budget"\n      },\n      {\n        "raw_text": "my products are coming from a supplier who is already successfully selling his this iteams on facebook... i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",\n        "topic_hint": "business model and supplier agreement"\n      },\n      {\n        "raw_text": "in ocean if a big boat come to catch fish that not mean others boat will not get any fishes... same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.",\n        "topic_hint": "market analysis and customer behavior"\n      },\n      {\n        "raw_text": "just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",\n        "topic_hint": "distribution plan"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.",\n        "topic_hint": "pricing strategy and business goals"\n      },\n      {\n        "raw_text": "nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",\n        "topic_hint": "content creation and inventory status"\n      }\n    ]\n  }\n]\n',
                    },
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "text",
                            "text": '{\n  "classification": "NO_NEW_PROBLEM",\n  "problem": 0,\n  "reason": "The critic identifies valid assumptions regarding the effectiveness of the \'styling advice\' strategy, but these are execution-level uncertainties rather than distinct, separate problems. The advisor can address these by refining the content strategy or testing the messaging within the current scope of acquiring the first 100 customers."\n}',
                            "extras": {
                                "signature": "EnAKbgERTTIPFUmmb3BYksZNyjLvRZQBOovLdxtCY+QIE+lgH8mxPWA3/PaenRCuAHUCU1UHoojBhWNz0g1T+thEkJAd5DNF+VVaMxDlxd9iPNsca9g1AsWI12RJqsSaQx5t9E5znWoPjS/sjNfv/eRt"
                            },
                        }
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Problem Explainer",
                "runtime": 5,
                "auto_runtime": 0,
                "problem_id": 0,
                "prompt": [
                    {
                        "role": "system",
                        "content": "\nYou are a Problem Explainer.\n\nYour job is to examine a conditional critic result and determine\nwhether it represents a DISTINCT NEW PROBLEM that should be sent\nback to the advisor as a child problem.\n\nYou do NOT solve the problem.\n\nYou do NOT improve the advisor's strategy.\n\nYou do NOT invent facts.\n\n============================================================\nINPUTS\n============================================================\n\nYou receive:\n\n1. CURRENT_PROBLEM\n   The problem currently being solved.\n\n2. CONDITIONAL_CRITIC\n   The critic's analysis of one action from the advisor's strategy.\n\n3. VERIFIED_FACTS\n   Facts already verified about the business.\n\n============================================================\nNEW PROBLEM TEST\n============================================================\n\nCreate NEW_PROBLEM only when the critic reveals a distinct issue\nthat requires its own reasoning and solution.\n\nA conditional critic does NOT automatically create a new problem.\n\nDo NOT create a new problem when the critic is only saying:\n\n- more evidence is needed\n- an assumption should be checked\n- a minor caveat exists\n- an execution detail is uncertain\n- the action may work under certain conditions\n\nCreate NEW_PROBLEM when the critic reveals something like:\n\n- the strategy depends on a real unresolved business constraint\n- the recommendation requires solving another substantive issue first\n- a missing capability/resource must be established before the\n  original strategy can work\n- the critic exposes a distinct obstacle that deserves its own\n  advisor-level solution\n\n============================================================\nPROBLEM FORMULATION\n============================================================\n\nWhen NEW_PROBLEM:\n\n- State the problem clearly.\n- Make it actionable for the advisor.\n- Preserve the critic's meaning.\n- Use verified facts as context.\n- Do not invent causes, facts, or solutions.\n- Do not include the solution in the problem statement.\n\nThe new problem will later be pushed on top of the current\nproblem stack and sent to the advisor.\n\n============================================================\nPARENT RELATIONSHIP\n============================================================\n\nThe new problem must be a CHILD of CURRENT_PROBLEM.\n\nIt should address the issue raised by the critic, not replace\nthe parent problem.\n\n============================================================\nOUTPUT\n============================================================\n\nReturn only the structured result defined by the output schema.\n",
                    },
                    {
                        "role": "human",
                        "content": '\nCURRENT_PROBLEM:\n\n{\n  "problem_id": 0,\n  "parent_problem_id": 0,\n  "depth": 0,\n  "problem": "Acquire the first 100 customers for the business.",\n  "runtime": 1,\n  "auto_runtime": 0,\n  "agent": "Advisor",\n  "status": "WAITING_FOR_CHILD",\n  "solution": null\n}\n\n\nCONDITIONAL_CRITIC:\n\n{\n  "action_title": "Create a First 100 Incentive",\n  "claim": "Offering a free home styling consultation and a small discount will help overcome the lack of social proof and attract the first 100 customers.",\n  "mechanism": "By providing unique value (consultation) and a price advantage (discount), the seller differentiates themselves from the supplier and other competitors, thereby building trust and incentivizing purchases despite having no social proof.",\n  "load_bearing_assumptions": [\n    {\n      "assumption": "The supplier will allow the seller to set a price lower than the supplier\'s own price.",\n      "classification": "ASSUMPTION",\n      "evidence": "The context states the seller has authority to set their own price, but it is unclear if the supplier\'s fulfillment/COD agreement allows for a price lower than the supplier\'s own retail price, which could create channel conflict."\n    },\n    {\n      "assumption": "The target audience (Bangladeshi women) values a home styling consultation enough to choose a new, unproven seller over an established one.",\n      "classification": "ASSUMPTION",\n      "evidence": "This is a behavioral assumption about the target market\'s decision-making process that is not confirmed in the context."\n    },\n    {\n      "assumption": "The seller has the expertise to provide a credible home styling consultation.",\n      "classification": "ASSUMPTION",\n      "evidence": "The context does not mention the seller\'s background or ability to provide professional home styling advice."\n    }\n  ],\n  "structural_flags": [],\n  "settled_as_fact_violation": 0,\n  "verdict": "CONDITIONAL",\n  "verdict_reason": "The mechanism relies on the seller\'s ability to offer a lower price and provide value-added services (consultation), but it is unverified whether the supplier\'s agreement permits price undercutting and whether the seller possesses the necessary expertise to make the consultation a compelling differentiator."\n}\n\n\nVERIFIED_FACTS:\n\n[\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i want 100 first customers in my business",\n        "topic_hint": "business goal"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i want 100 first customers in my business",\n        "topic_hint": "business goal"\n      },\n      {\n        "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman\'s, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",\n        "topic_hint": "product and target audience"\n      },\n      {\n        "raw_text": "my product avg price point is 2000-4000 tk. and i already told you about typical buyers.",\n        "topic_hint": "pricing"\n      },\n      {\n        "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",\n        "topic_hint": "business model and operations"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman\'s, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",\n        "topic_hint": "business description and target audience"\n      },\n      {\n        "raw_text": "my product avg price point is 2000-4000 tk.",\n        "topic_hint": "pricing"\n      },\n      {\n        "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team.",\n        "topic_hint": "business resources and budget"\n      },\n      {\n        "raw_text": "my products are coming from a supplier who is already successfully selling his this iteams on facebook... i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",\n        "topic_hint": "business model and supplier agreement"\n      },\n      {\n        "raw_text": "in ocean if a big boat come to catch fish that not mean others boat will not get any fishes... same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.",\n        "topic_hint": "market analysis and customer behavior"\n      },\n      {\n        "raw_text": "just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",\n        "topic_hint": "distribution plan"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.",\n        "topic_hint": "pricing strategy and business goals"\n      },\n      {\n        "raw_text": "nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",\n        "topic_hint": "content creation and inventory status"\n      }\n    ]\n  }\n]\n',
                    },
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "text",
                            "text": '{\n  "classification": "NEW_PROBLEM",\n  "problem": "Determine the feasibility of offering value-added services and price adjustments given the current supplier agreement and seller capabilities.",\n  "reason": "The proposed strategy relies on two critical, unverified factors: the seller\'s ability to offer a lower price without violating the supplier\'s pricing structure or channel conflict, and the seller\'s ability to provide professional home styling consultations. These are substantive operational constraints that must be clarified before the advisor can rely on them as a core acquisition strategy."\n}',
                            "extras": {
                                "signature": "EnAKbgERTTIPUeKMhQmAlYoqZ7BtwP/z0XCpk3lxujoVWF1U8P3f3uLBCtXxb8P4fldOYNsuildnl/Ggi3FNa+c3IsJqqnkS+Ug+JlePJSUUgZ3jyBhhG/IV8l6qJlf5kgAgUHTMQGtVKBJQm6SJC5An"
                            },
                        }
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Advisor LLM",
                "runtime": 5,
                "auto_runtime": 1,
                "problem_id": 3,
                "prompt": [
                    {
                        "role": "system",
                        "content": "\nROLE\n\nYou are a senior business advisor.\n\n\nPRIMARY RULE\n\nNever solve a business problem until you have enough context.\n\n\nWORKFLOW\n\nStep 1\n\nDetermine whether enough information exists to give high-confidence advice.\n\nIf NOT:\n\n• Identify only the missing information that could materially change the recommendation.\n• Ask the minimum number of high-value questions.\n• Ask no more than 3 questions in one response.\n• Group related questions together.\n• Do not ask questions that won't affect the strategy.\n• Do not give recommendations yet.\n• Do not explain your reasoning at length.\n• Do not repeat information already established.\n\nKeep the response concise.\n\nRepeat Step 1 until enough context is collected.\n\n\nStep 2\n\nOnce enough context exists:\n\n• Summarize your understanding of the business.\n• Identify the real problem (not just the stated problem).\n• Explain your reasoning.\n• Recommend prioritized actions.\n• Explain why each recommendation fits this business.\n• Mention assumptions, risks, and trade-offs.\n\nKeep the final recommendation focused and practical.\nDo not repeat the entire conversation.\nDo not add unnecessary explanation or filler.\n\n\nOUTPUT DISCIPLINE\n\nWhen asking questions:\n\n• Maximum 3 questions.\n• Ask only questions that can materially change the recommendation.\n• Do not include a long introduction.\n• Do not provide advice.\n• Do not provide a long explanation.\n• Prefer direct questions over paragraphs.\n\nWhen giving the final recommendation:\n\n• Be structured and concise.\n• Include only information relevant to the recommendation.\n• Avoid repeating facts already known unless needed for reasoning.\n• Avoid motivational filler.\n• Avoid generic business advice.\n\n\nRULES\n\n• Never invent business facts.\n• Challenge weak assumptions.\n• Consider industry, competition, customers, budget, stage, resources, and constraints before recommending actions.\n• Prefer fewer high-impact questions over many generic questions.\n• Never ask for information that is already available in the conversation.\n• Never repeat the same question in different wording unless the previous answer was genuinely incomplete.\n• Every sentence must serve the decision-making process.\n\n\nConversation history:\n",
                    },
                    {
                        "role": "human",
                        "content": "i want 100 first customers in my business",
                    },
                    {
                        "role": "ai",
                        "content": "1. What is your product or service, and who is the ideal customer?\n2. What is the price point and the typical sales cycle (e.g., impulse buy vs. long enterprise deal)?\n3. What resources (budget, team, or existing network) do you have available to acquire these customers?",
                    },
                    {
                        "role": "human",
                        "content": "1. i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.\n2. my product avg price point is 2000-4000 tk. and i already told you about typical buyers.\n3. right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                    },
                    {
                        "role": "ai",
                        "content": "1. Why would a customer buy from your page instead of buying directly from the supplier who already has 50k followers?\n2. Besides posting reels on your own page, what is your plan to get these videos in front of new people without spending money on ads?",
                    },
                    {
                        "role": "human",
                        "content": "1. in ocean if a big boat come to catch fish that not mean others boat will not get any fishes, instead the ocean is that much big and huge that if lots of big boat start fishing nothing will be effected. same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.\n2. just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",
                    },
                    {
                        "role": "ai",
                        "content": "1. Do you have the authority to set your own prices, or must you sell at the same price as the supplier?\n2. Can you create your own original photos or videos of the products, or are you 100% dependent on the supplier's reels?",
                    },
                    {
                        "role": "human",
                        "content": "1. i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.\n2. nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",
                    },
                    {
                        "role": "human",
                        "content": "1. i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.\n2. nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",
                    },
                    {
                        "role": "human",
                        "content": 'AUTOMATIC PROBLEM-SOLVING REQUEST\n\nNEW PROBLEM:\nDetermine the feasibility of offering value-added services and price adjustments given the current supplier agreement and seller capabilities.\n\nSOURCE CRITIC:\n{\n  "action_title": "Shift from Selling to Styling",\n  "claim": "Reposition content to focus on home styling advice rather than direct product sales to differentiate from competitors and build trust.",\n  "mechanism": "By providing value-added content (styling advice) instead of just product listings, the business creates a reason for customers to follow and trust the page, differentiating it from the supplier and other low-price competitors.",\n  "load_bearing_assumptions": [\n    {\n      "assumption": "Target customers (Bangladeshi women) value styling advice enough to engage with a new, unknown page.",\n      "classification": "ASSUMPTION",\n      "evidence": "This requires testing whether the target audience seeks styling advice from a non-expert/new page or if they prioritize the established reputation of the supplier."\n    },\n    {\n      "assumption": "Adding text overlays and captions to supplier reels is sufficient to differentiate the page from the supplier\'s own page and other competitors.",\n      "classification": "ASSUMPTION",\n      "evidence": "This assumes that the audience perceives the value-add of the text/captions as greater than the risk of buying from a new, unproven seller."\n    },\n    {\n      "assumption": "The supplier\'s reels are visually compatible with a \'styling advice\' narrative rather than just a \'product showcase\' narrative.",\n      "classification": "ASSUMPTION",\n      "evidence": "This depends on the specific content of the supplier\'s reels, which are currently used for direct sales."\n    }\n  ],\n  "structural_flags": [],\n  "settled_as_fact_violation": 0,\n  "verdict": "CONDITIONAL",\n  "verdict_reason": "The strategy relies on the assumption that styling advice will successfully differentiate the business and build enough trust to overcome the lack of a track record, which is unverified. Success depends on whether the target audience values this curation enough to choose a new, unproven seller over established competitors."\n}\n\nFULL VERIFIED FACTS:\n[\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i want 100 first customers in my business",\n        "topic_hint": "business goal"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i want 100 first customers in my business",\n        "topic_hint": "business goal"\n      },\n      {\n        "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman\'s, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",\n        "topic_hint": "product and target audience"\n      },\n      {\n        "raw_text": "my product avg price point is 2000-4000 tk. and i already told you about typical buyers.",\n        "topic_hint": "pricing"\n      },\n      {\n        "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",\n        "topic_hint": "business model and operations"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman\'s, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",\n        "topic_hint": "business description and target audience"\n      },\n      {\n        "raw_text": "my product avg price point is 2000-4000 tk.",\n        "topic_hint": "pricing"\n      },\n      {\n        "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team.",\n        "topic_hint": "business resources and budget"\n      },\n      {\n        "raw_text": "my products are coming from a supplier who is already successfully selling his this iteams on facebook... i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",\n        "topic_hint": "business model and supplier agreement"\n      },\n      {\n        "raw_text": "in ocean if a big boat come to catch fish that not mean others boat will not get any fishes... same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.",\n        "topic_hint": "market analysis and customer behavior"\n      },\n      {\n        "raw_text": "just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",\n        "topic_hint": "distribution plan"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.",\n        "topic_hint": "pricing strategy and business goals"\n      },\n      {\n        "raw_text": "nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",\n        "topic_hint": "content creation and inventory status"\n      }\n    ]\n  }\n]',
                    },
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "thinking",
                            "thinking": '*   Goal: Get the first 100 customers.\n    *   Product: Home decorating showpieces.\n    *   Target Audience: Bangladeshi women (motivated by social status, organization, and respect).\n    *   Price Point: 2,000 - 4,000 TK.\n    *   Resources: 0 budget, solo seller, no network.\n    *   Business Model: Dropshipping-style arrangement with a supplier. Supplier handles packaging/shipping/COD.\n    *   Content: 100% dependent on supplier\'s reels (re-uploading with different music).\n    *   Market Insight: Customers see products multiple times and compare prices before buying from the cheapest seller.\n    *   Current Struggle: Group sharing isn\'t working; no distribution plan.\n    *   Constraint: No physical products to take own photos/videos.\n\n    *   The user is essentially a "mirror" of the supplier.\n    *   The supplier has 50k followers and the original content.\n    *   The user has 0 followers, 0 budget, and is using the same content.\n    *   The user believes that "more boats in the ocean" will get fish, but in digital marketing, the algorithm favors original content and established trust.\n    *   The user\'s current strategy (re-uploading reels with different music) is unlikely to trigger the Facebook algorithm for organic reach because it\'s duplicate content.\n    *   The user\'s competitive advantage is currently *zero* (same product, same content, same or higher price).\n\n    *   *The stated problem:* "I want 100 customers."\n    *   *The real problem:* The user has no "Unique Value Proposition" (UVP) and no organic distribution mechanism. They are competing on price/visibility against the source of their own products.\n\n    *   *Distribution:* Since budget is 0, they need organic reach. Facebook Reels are the best bet, but duplicate content is penalized. They need to *transform* the content.\n    *   *Differentiation:* Since they can\'t change the product or the price (they want to stay low), they must change the *angle*. Instead of "Buy this product," it should be "Here is how to make your home look respectful/organized."\n    *   *Trust:* A new page with no reviews is a risk for COD. They need to build a "persona" of a curator/stylist rather than just a reseller.\n\n    *   *Step 1: Content Transformation (The "Curator" Angle).*\n        *   Don\'t just change music. Add text overlays.\n        *   Create "Lists" or "Themes" (e.g., "3 pieces to make your living room look elegant").\n        *   Use the supplier\'s reels as "B-roll" but add a narrative.\n\n    *   *Step 2: Distribution (The "Community" Angle).*\n        *   Groups didn\'t work because they were likely "spammy" (just posting a link/product).\n        *   Strategy: Provide value first. Answer questions about home decor in groups, then suggest the product.\n\n    *   *Step 3: Conversion (The "Trust" Angle).*\n        *   Since they are solo, they should lean into the "personal shopper" or "home stylist" vibe.\n        *   Focus on the emotional trigger: "Respect" and "Organization."\n\n    *   *Summary:* Home decor reseller for Bangladeshi women, 0 budget, using supplier reels, goal is 100 customers.\n    *   *Real Problem:* Lack of differentiation and organic reach. You are a mirror of your supplier; customers have no reason to choose you over the original source.\n    *   *Reasoning:* Facebook\'s algorithm suppresses duplicate content. Without a unique angle or budget, you are invisible.\n    *   *Recommendations:*\n        1.  Shift from "Seller" to "Stylist" (Content strategy).\n        2.  The "Value-First" Group Strategy (Distribution).\n        3.  The "Low-Risk" Entry (Conversion).\n\n    *   *Check:* Did I give generic advice? No, tailored to Bangladeshi women\'s motivations (respect/organization).\n    *   *Check:* Did I invent facts? No.\n    *   *Check:* Is it concise? Yes.',
                        },
                        {
                            "type": "text",
                            "text": '### Business Summary\nYou are a solo reseller of home decor showpieces targeting Bangladeshi women who value social status, organization, and respect. You operate on a zero-budget, dropshipping-style model where the supplier handles logistics and COD. You are currently 100% dependent on the supplier\'s content (reels) and have no established network or distribution plan.\n\n### The Real Problem\n**You have no "Unique Value Proposition" (UVP).** \nYou are currently a mirror of your supplier. Because you use the same videos and sell the same products, the Facebook algorithm will treat your content as duplicate (reducing reach), and customers have no logical reason to buy from an unproven new page when they can buy from the original source with 50k followers.\n\n### Reasoning\nIn a price-sensitive market where customers compare 5+ sellers, "being another boat in the ocean" only works if you have a different "bait." Since you cannot change the product, the price, or the original footage, you must change the **context** of how the product is presented.\n\n### Prioritized Recommendations\n\n#### 1. Shift from "Seller" to "Home Stylist" (Content Strategy)\nStop simply re-uploading reels with different music. The algorithm and the customer will ignore them. Instead, transform the supplier\'s footage into "Advice Content."\n*   **The Action:** Use a free tool (like CapCut) to add text overlays to the reels. Instead of "Buy this showpiece," use titles like: *"3 ways to make your drawing room look more respectful for guests"* or *"How to organize your shelf to look like a luxury home."*\n*   **Why this fits:** Your target audience wants the *result* (respect and organization), not just the *object*. By providing "styling tips," you become a consultant, not just a reseller.\n\n#### 2. The "Value-First" Group Strategy (Distribution)\nGeneric posting in groups fails because it looks like spam. You must pivot to "Problem-Solving."\n*   **The Action:** Join home decor and women\'s community groups. Do not post products. Instead, find people asking for home improvement advice. Give them a genuine tip first, then say: *"I actually found a piece that fits this exact look perfectly, I can send you the details if you\'re interested."*\n*   **Why this fits:** This builds individual trust. Since you have no page reputation, you must build "person-to-person" trust to overcome the risk of buying from a new seller.\n\n#### 3. Leverage the "Personal Shopper" Angle (Conversion)\nSince you are a solo seller, use your "smallness" as an advantage.\n*   **The Action:** In your messages, don\'t act like a big company. Act as a curator. Tell customers: *"I spend my time picking the best pieces from the supplier so you don\'t have to browse through hundreds of items."*\n*   **Why this fits:** This justifies why they should buy from you instead of the supplier—you are providing a curation service (saving them time).\n\n### Assumptions, Risks, and Trade-offs\n*   **Assumption:** I assume the supplier\'s reels are high-quality enough to be edited into "tips" videos.\n*   **Risk:** Since you don\'t hold the inventory, you are at the mercy of the supplier\'s stock levels. If a product goes viral on your page but is sold out at the supplier, you will lose trust.\n*   **Trade-off:** This "Stylist" approach takes more time per post than simply changing the music, but it is the only way to get organic reach without a budget.',
                        },
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Verified Facts LLM",
                "runtime": 5,
                "auto_runtime": 1,
                "problem_id": 3,
                "prompt": [
                    {
                        "role": "human",
                        "content": '\nYou are a strict Verified Facts Extraction Agent.\n\nYour job is to identify VERIFIED information from ONLY the evidence provided below.\n\nYou receive exactly three pieces of evidence:\n\n1. HUMAN_MESSAGE_1\n2. HUMAN_MESSAGE_2\n3. ADVISOR_REPLY\n\nSOURCE RULES:\n\n- HUMAN_MESSAGE_1 and HUMAN_MESSAGE_2 are the ONLY sources of user-provided facts.\n- ADVISOR_REPLY is the ONLY source of questions asked by the advisor.\n- Never treat anything written by the advisor as a user fact.\n- Never invent a user answer.\n- Never use older conversation history.\n- Never assume the advisor\'s statements are true.\n- Never convert an advisor suggestion into a verified fact.\n- Never create a question that does not actually appear in ADVISOR_REPLY.\n\nThe user may provide information:\n\n- before the advisor asks about it\n- after the advisor asks about it\n\nBoth are valid.\n\n--------------------------------------------------\nHUMAN MESSAGE 1\n--------------------------------------------------\n\n1. i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.\n2. nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels\n\n--------------------------------------------------\nHUMAN MESSAGE 2\n--------------------------------------------------\n\nAUTOMATIC PROBLEM-SOLVING REQUEST\n\nNEW PROBLEM:\nDetermine the feasibility of offering value-added services and price adjustments given the current supplier agreement and seller capabilities.\n\nSOURCE CRITIC:\n{\n  "action_title": "Shift from Selling to Styling",\n  "claim": "Reposition content to focus on home styling advice rather than direct product sales to differentiate from competitors and build trust.",\n  "mechanism": "By providing value-added content (styling advice) instead of just product listings, the business creates a reason for customers to follow and trust the page, differentiating it from the supplier and other low-price competitors.",\n  "load_bearing_assumptions": [\n    {\n      "assumption": "Target customers (Bangladeshi women) value styling advice enough to engage with a new, unknown page.",\n      "classification": "ASSUMPTION",\n      "evidence": "This requires testing whether the target audience seeks styling advice from a non-expert/new page or if they prioritize the established reputation of the supplier."\n    },\n    {\n      "assumption": "Adding text overlays and captions to supplier reels is sufficient to differentiate the page from the supplier\'s own page and other competitors.",\n      "classification": "ASSUMPTION",\n      "evidence": "This assumes that the audience perceives the value-add of the text/captions as greater than the risk of buying from a new, unproven seller."\n    },\n    {\n      "assumption": "The supplier\'s reels are visually compatible with a \'styling advice\' narrative rather than just a \'product showcase\' narrative.",\n      "classification": "ASSUMPTION",\n      "evidence": "This depends on the specific content of the supplier\'s reels, which are currently used for direct sales."\n    }\n  ],\n  "structural_flags": [],\n  "settled_as_fact_violation": 0,\n  "verdict": "CONDITIONAL",\n  "verdict_reason": "The strategy relies on the assumption that styling advice will successfully differentiate the business and build enough trust to overcome the lack of a track record, which is unverified. Success depends on whether the target audience values this curation enough to choose a new, unproven seller over established competitors."\n}\n\nFULL VERIFIED FACTS:\n[\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i want 100 first customers in my business",\n        "topic_hint": "business goal"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i want 100 first customers in my business",\n        "topic_hint": "business goal"\n      },\n      {\n        "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman\'s, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",\n        "topic_hint": "product and target audience"\n      },\n      {\n        "raw_text": "my product avg price point is 2000-4000 tk. and i already told you about typical buyers.",\n        "topic_hint": "pricing"\n      },\n      {\n        "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",\n        "topic_hint": "business model and operations"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman\'s, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",\n        "topic_hint": "business description and target audience"\n      },\n      {\n        "raw_text": "my product avg price point is 2000-4000 tk.",\n        "topic_hint": "pricing"\n      },\n      {\n        "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team.",\n        "topic_hint": "business resources and budget"\n      },\n      {\n        "raw_text": "my products are coming from a supplier who is already successfully selling his this iteams on facebook... i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",\n        "topic_hint": "business model and supplier agreement"\n      },\n      {\n        "raw_text": "in ocean if a big boat come to catch fish that not mean others boat will not get any fishes... same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.",\n        "topic_hint": "market analysis and customer behavior"\n      },\n      {\n        "raw_text": "just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",\n        "topic_hint": "distribution plan"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.",\n        "topic_hint": "pricing strategy and business goals"\n      },\n      {\n        "raw_text": "nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",\n        "topic_hint": "content creation and inventory status"\n      }\n    ]\n  }\n]\n\n--------------------------------------------------\nADVISOR REPLY\n--------------------------------------------------\n\n### Business Summary\nYou are a solo reseller of home decor showpieces targeting Bangladeshi women who value social status, organization, and respect. You operate on a zero-budget, dropshipping-style model where the supplier handles logistics and COD. You are currently 100% dependent on the supplier\'s content (reels) and have no established network or distribution plan.\n\n### The Real Problem\n**You have no "Unique Value Proposition" (UVP).** \nYou are currently a mirror of your supplier. Because you use the same videos and sell the same products, the Facebook algorithm will treat your content as duplicate (reducing reach), and customers have no logical reason to buy from an unproven new page when they can buy from the original source with 50k followers.\n\n### Reasoning\nIn a price-sensitive market where customers compare 5+ sellers, "being another boat in the ocean" only works if you have a different "bait." Since you cannot change the product, the price, or the original footage, you must change the **context** of how the product is presented.\n\n### Prioritized Recommendations\n\n#### 1. Shift from "Seller" to "Home Stylist" (Content Strategy)\nStop simply re-uploading reels with different music. The algorithm and the customer will ignore them. Instead, transform the supplier\'s footage into "Advice Content."\n*   **The Action:** Use a free tool (like CapCut) to add text overlays to the reels. Instead of "Buy this showpiece," use titles like: *"3 ways to make your drawing room look more respectful for guests"* or *"How to organize your shelf to look like a luxury home."*\n*   **Why this fits:** Your target audience wants the *result* (respect and organization), not just the *object*. By providing "styling tips," you become a consultant, not just a reseller.\n\n#### 2. The "Value-First" Group Strategy (Distribution)\nGeneric posting in groups fails because it looks like spam. You must pivot to "Problem-Solving."\n*   **The Action:** Join home decor and women\'s community groups. Do not post products. Instead, find people asking for home improvement advice. Give them a genuine tip first, then say: *"I actually found a piece that fits this exact look perfectly, I can send you the details if you\'re interested."*\n*   **Why this fits:** This builds individual trust. Since you have no page reputation, you must build "person-to-person" trust to overcome the risk of buying from a new seller.\n\n#### 3. Leverage the "Personal Shopper" Angle (Conversion)\nSince you are a solo seller, use your "smallness" as an advantage.\n*   **The Action:** In your messages, don\'t act like a big company. Act as a curator. Tell customers: *"I spend my time picking the best pieces from the supplier so you don\'t have to browse through hundreds of items."*\n*   **Why this fits:** This justifies why they should buy from you instead of the supplier—you are providing a curation service (saving them time).\n\n### Assumptions, Risks, and Trade-offs\n*   **Assumption:** I assume the supplier\'s reels are high-quality enough to be edited into "tips" videos.\n*   **Risk:** Since you don\'t hold the inventory, you are at the mercy of the supplier\'s stock levels. If a product goes viral on your page but is sold out at the supplier, you will lose trust.\n*   **Trade-off:** This "Stylist" approach takes more time per post than simply changing the music, but it is the only way to get organic reach without a budget.\n\n--------------------------------------------------\nTASK\n--------------------------------------------------\n\n1. Identify every actual question or information request in ADVISOR_REPLY.\n\n2. For each advisor question, search BOTH HUMAN_MESSAGE_1 and HUMAN_MESSAGE_2.\n\n3. If either human message explicitly answers the question, create a verified Q&A pair.\n\n4. The answer may appear before or after the advisor asked the question.\n\n5. Only use information explicitly present in the human messages.\n\n6. If no human message answers the question, do NOT create a Q&A pair.\n\n7. Extract user information that is not an answer to an advisor question as unprompted context.\n\n8. Preserve unprompted user context as closely as possible to the original wording.\n\n--------------------------------------------------\nIMPORTANT EXAMPLES\n--------------------------------------------------\n\nIf the user says:\n\n"hi"\n\nand the advisor asks:\n\n"What is your business?"\n\nthen:\n\n- qa_pairs must be empty\n- unprompted_context must be empty\n\nIf HUMAN_MESSAGE_1 says:\n\n"I sell handmade jewelry."\n\nand ADVISOR_REPLY later asks:\n\n"What is your business?"\n\nthen this is a verified Q&A pair even though the answer appeared before the question.\n\nIf ADVISOR_REPLY asks:\n\n"What is your budget?"\n\nand neither human message mentions a budget:\n\n- do not invent an answer\n- do not create a Q&A pair\n\n--------------------------------------------------\nANTI-HALLUCINATION RULES\n--------------------------------------------------\n\n- Never invent questions.\n- Never invent answers.\n- Never use information from older conversation history.\n- Never use information from ADVISOR_REPLY as a user fact.\n- Never assume the user agrees with the advisor.\n- Never turn advisor suggestions into facts.\n- Never reconstruct a conversation that is not provided.\n- When uncertain, do not guess.\n\n--------------------------------------------------\nOUTPUT\n--------------------------------------------------\n\nReturn ONLY the structured output required by the Pydantic output parser.\n\nThe output should be formatted as a JSON instance that conforms to the JSON schema below.\n\nAs an example, for the schema {"properties": {"foo": {"title": "Foo", "description": "a list of strings", "type": "array", "items": {"type": "string"}}}, "required": ["foo"]}\nthe object {"foo": ["bar", "baz"]} is a well-formatted instance of the schema. The object {"properties": {"foo": ["bar", "baz"]}} is not well-formatted.\n\nHere is the output schema:\n```\n{"$defs": {"QAPair": {"properties": {"question_asked": {"title": "Question Asked", "type": "string"}, "user_answer": {"title": "User Answer", "type": "string"}, "verification": {"enum": ["verified", "uncertain_match"], "title": "Verification", "type": "string"}}, "required": ["question_asked", "user_answer", "verification"], "title": "QAPair", "type": "object"}, "UnpromptedContext": {"properties": {"raw_text": {"title": "Raw Text", "type": "string"}, "topic_hint": {"title": "Topic Hint", "type": "string"}}, "required": ["raw_text", "topic_hint"], "title": "UnpromptedContext", "type": "object"}}, "properties": {"qa_pairs": {"items": {"$ref": "#/$defs/QAPair"}, "title": "Qa Pairs", "type": "array"}, "unprompted_context": {"items": {"$ref": "#/$defs/UnpromptedContext"}, "title": "Unprompted Context", "type": "array"}}}\n```\n',
                    }
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "text",
                            "text": '{\n  "qa_pairs": [],\n  "unprompted_context": [\n    {\n      "raw_text": "i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.",\n      "topic_hint": "pricing strategy and business goals"\n    },\n    {\n      "raw_text": "nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",\n      "topic_hint": "content creation and inventory status"\n    }\n  ]\n}',
                            "extras": {
                                "signature": "EnAKbgERTTIPWwAsbfb4hokh3zo3lRDJL0ILvFIhRigr/ONBDLtBkypBRbAEYqZ/ZshldPr7eUijk7+kIcc/YS1iLjjd5ia4FsREfE0QrTvY3x8xmF2DDBVcveP86ez+1DFNSLcvDSWQTT4KUnZA/Ypq"
                            },
                        }
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Classifier LLM",
                "runtime": 5,
                "auto_runtime": 1,
                "problem_id": 3,
                "prompt": [
                    {
                        "role": "human",
                        "content": '\nYou are a response-state classifier.\n\nYour job is to determine whether the BUSINESS ADVISOR\'s latest\nresponse requires the USER to provide more information.\n\nReturn ONLY one of these two values:\n\nNEEDS_INPUT\n\nor\n\nDONE\n\n\nReturn NEEDS_INPUT when:\n\n- The advisor asks the user a question.\n- The advisor requests missing business information.\n- The advisor needs clarification before it can continue.\n- The advisor explicitly tells the user to provide something.\n\nReturn DONE when:\n\n- The advisor has enough information.\n- The advisor gives recommendations.\n- The advisor is explaining the analysis.\n- The advisor does not require another user response to continue.\n\nDo not explain your answer.\n\nAdvisor\'s latest response:\n\n### Business Summary\nYou are a solo reseller of home decor showpieces targeting Bangladeshi women who value social status, organization, and respect. You operate on a zero-budget, dropshipping-style model where the supplier handles logistics and COD. You are currently 100% dependent on the supplier\'s content (reels) and have no established network or distribution plan.\n\n### The Real Problem\n**You have no "Unique Value Proposition" (UVP).** \nYou are currently a mirror of your supplier. Because you use the same videos and sell the same products, the Facebook algorithm will treat your content as duplicate (reducing reach), and customers have no logical reason to buy from an unproven new page when they can buy from the original source with 50k followers.\n\n### Reasoning\nIn a price-sensitive market where customers compare 5+ sellers, "being another boat in the ocean" only works if you have a different "bait." Since you cannot change the product, the price, or the original footage, you must change the **context** of how the product is presented.\n\n### Prioritized Recommendations\n\n#### 1. Shift from "Seller" to "Home Stylist" (Content Strategy)\nStop simply re-uploading reels with different music. The algorithm and the customer will ignore them. Instead, transform the supplier\'s footage into "Advice Content."\n*   **The Action:** Use a free tool (like CapCut) to add text overlays to the reels. Instead of "Buy this showpiece," use titles like: *"3 ways to make your drawing room look more respectful for guests"* or *"How to organize your shelf to look like a luxury home."*\n*   **Why this fits:** Your target audience wants the *result* (respect and organization), not just the *object*. By providing "styling tips," you become a consultant, not just a reseller.\n\n#### 2. The "Value-First" Group Strategy (Distribution)\nGeneric posting in groups fails because it looks like spam. You must pivot to "Problem-Solving."\n*   **The Action:** Join home decor and women\'s community groups. Do not post products. Instead, find people asking for home improvement advice. Give them a genuine tip first, then say: *"I actually found a piece that fits this exact look perfectly, I can send you the details if you\'re interested."*\n*   **Why this fits:** This builds individual trust. Since you have no page reputation, you must build "person-to-person" trust to overcome the risk of buying from a new seller.\n\n#### 3. Leverage the "Personal Shopper" Angle (Conversion)\nSince you are a solo seller, use your "smallness" as an advantage.\n*   **The Action:** In your messages, don\'t act like a big company. Act as a curator. Tell customers: *"I spend my time picking the best pieces from the supplier so you don\'t have to browse through hundreds of items."*\n*   **Why this fits:** This justifies why they should buy from you instead of the supplier—you are providing a curation service (saving them time).\n\n### Assumptions, Risks, and Trade-offs\n*   **Assumption:** I assume the supplier\'s reels are high-quality enough to be edited into "tips" videos.\n*   **Risk:** Since you don\'t hold the inventory, you are at the mercy of the supplier\'s stock levels. If a product goes viral on your page but is sold out at the supplier, you will lose trust.\n*   **Trade-off:** This "Stylist" approach takes more time per post than simply changing the music, but it is the only way to get organic reach without a budget.\n',
                    }
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "text",
                            "text": "DONE",
                            "extras": {
                                "signature": "EnAKbgERTTIPH0DH2VMqMiG4N86XVL2IheD99jgUjf/12zcAEhWWMu4RXRPPp6ic6PUTpa1YBJy3zk/FDqXx05zkouLejL+8aTxnRULM5H4kbPDUV/KId3OuiPT8xGC4e/mwA5zv/IUmA1iXN644EAEz"
                            },
                        }
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Systematic Advice Converter LLM",
                "runtime": 5,
                "auto_runtime": 1,
                "problem_id": 3,
                "prompt": [
                    {
                        "role": "system",
                        "content": "\nConvert the advisor reply into the BusinessStrategyBrief schema.\n\nExtract only what is stated or clearly implied in the advisor reply.\nNever invent facts.\n",
                    },
                    {
                        "role": "human",
                        "content": '### Business Summary\nYou are a solo reseller of home decor showpieces targeting Bangladeshi women who value social status, organization, and respect. You operate on a zero-budget, dropshipping-style model where the supplier handles logistics and COD. You are currently 100% dependent on the supplier\'s content (reels) and have no established network or distribution plan.\n\n### The Real Problem\n**You have no "Unique Value Proposition" (UVP).** \nYou are currently a mirror of your supplier. Because you use the same videos and sell the same products, the Facebook algorithm will treat your content as duplicate (reducing reach), and customers have no logical reason to buy from an unproven new page when they can buy from the original source with 50k followers.\n\n### Reasoning\nIn a price-sensitive market where customers compare 5+ sellers, "being another boat in the ocean" only works if you have a different "bait." Since you cannot change the product, the price, or the original footage, you must change the **context** of how the product is presented.\n\n### Prioritized Recommendations\n\n#### 1. Shift from "Seller" to "Home Stylist" (Content Strategy)\nStop simply re-uploading reels with different music. The algorithm and the customer will ignore them. Instead, transform the supplier\'s footage into "Advice Content."\n*   **The Action:** Use a free tool (like CapCut) to add text overlays to the reels. Instead of "Buy this showpiece," use titles like: *"3 ways to make your drawing room look more respectful for guests"* or *"How to organize your shelf to look like a luxury home."*\n*   **Why this fits:** Your target audience wants the *result* (respect and organization), not just the *object*. By providing "styling tips," you become a consultant, not just a reseller.\n\n#### 2. The "Value-First" Group Strategy (Distribution)\nGeneric posting in groups fails because it looks like spam. You must pivot to "Problem-Solving."\n*   **The Action:** Join home decor and women\'s community groups. Do not post products. Instead, find people asking for home improvement advice. Give them a genuine tip first, then say: *"I actually found a piece that fits this exact look perfectly, I can send you the details if you\'re interested."*\n*   **Why this fits:** This builds individual trust. Since you have no page reputation, you must build "person-to-person" trust to overcome the risk of buying from a new seller.\n\n#### 3. Leverage the "Personal Shopper" Angle (Conversion)\nSince you are a solo seller, use your "smallness" as an advantage.\n*   **The Action:** In your messages, don\'t act like a big company. Act as a curator. Tell customers: *"I spend my time picking the best pieces from the supplier so you don\'t have to browse through hundreds of items."*\n*   **Why this fits:** This justifies why they should buy from you instead of the supplier—you are providing a curation service (saving them time).\n\n### Assumptions, Risks, and Trade-offs\n*   **Assumption:** I assume the supplier\'s reels are high-quality enough to be edited into "tips" videos.\n*   **Risk:** Since you don\'t hold the inventory, you are at the mercy of the supplier\'s stock levels. If a product goes viral on your page but is sold out at the supplier, you will lose trust.\n*   **Trade-off:** This "Stylist" approach takes more time per post than simply changing the music, but it is the only way to get organic reach without a budget.',
                    },
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "text",
                            "text": '{\n  "title": "Transitioning from Generic Reseller to Home Stylist Consultant",\n  "business_summary": {\n    "business_model": "Zero-budget, dropshipping-style reseller",\n    "product_category": "Home decor showpieces",\n    "price_range_bdt": 0,\n    "target_customer": "Bangladeshi women who value social status, organization, and respect",\n    "market": "Bangladesh",\n    "fulfillment": "Supplier handles logistics and COD",\n    "constraints": [\n      "100% dependent on supplier\'s content",\n      "No established network or distribution plan",\n      "Zero budget",\n      "No unique value proposition"\n    ]\n  },\n  "real_problem": {\n    "surface_problem": "You have no \'Unique Value Proposition\' (UVP).",\n    "actual_problem": "The business is a mirror of the supplier, leading to duplicate content issues with the algorithm and a lack of customer trust compared to the original source.",\n    "supporting_context": [\n      "Facebook algorithm treats duplicate content as spam, reducing reach.",\n      "Customers have no logical reason to buy from an unproven new page when the original source has 50k followers.",\n      "The market is price-sensitive with customers comparing multiple sellers."\n    ]\n  },\n  "strategy_reasoning": {\n    "core_constraint": "Inability to change the product, price, or original footage.",\n    "approach": "Change the context of how the product is presented to provide value beyond the object itself.",\n    "channels": [\n      "Facebook Reels",\n      "Home decor and women\'s community groups"\n    ]\n  },\n  "prioritized_action_plan": [\n    {\n      "priority": 1,\n      "title": "Shift from Seller to Home Stylist",\n      "action": "Transform supplier footage into advice-based content using text overlays.",\n      "execution": [\n        "Use CapCut to add educational text overlays to existing reels.",\n        "Focus titles on results like \'3 ways to make your drawing room look more respectful for guests\' or \'How to organize your shelf to look like a luxury home\'."\n      ]\n    },\n    {\n      "priority": 2,\n      "title": "Value-First Group Strategy",\n      "action": "Build trust through problem-solving in community groups rather than spamming products.",\n      "execution": [\n        "Join home decor and women\'s community groups.",\n        "Provide genuine home improvement advice to members.",\n        "Offer product details only after establishing a helpful connection."\n      ]\n    },\n    {\n      "priority": 3,\n      "title": "Leverage the Personal Shopper Angle",\n      "action": "Position the business as a curator to justify buying from a smaller seller.",\n      "execution": [\n        "Communicate as a curator who saves customers time by picking the best pieces from the supplier."\n      ]\n    }\n  ],\n  "assumptions_risks_tradeoffs": {\n    "assumptions": [\n      "The supplier\'s reels are high-quality enough to be edited into \'tips\' videos."\n    ],\n    "risks": [\n      {\n        "risk": "Supplier stock levels",\n        "impact": "If a product goes viral but is sold out at the supplier, you will lose customer trust.",\n        "mitigation": null\n      }\n    ],\n    "tradeoffs": [\n      "The \'Stylist\' approach requires more time per post than simply changing music, but it is necessary for organic reach without a budget."\n    ]\n  }\n}',
                            "extras": {
                                "signature": "EnAKbgERTTIPTWpsCAmyN44mma22WlTnPdKTqOJnr+yEIHBAVSMjqwyV1VNbNGePcoP+BXUPLpnrOY/ofCGj3x0T86z+89LAJbz4rDQ0wVL9WG6jHkS/a5CPt/hL0BvMXe3B+cVWt1UdSFnrolDN/3Y2"
                            },
                        }
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Reality-Check Critic #5",
                "runtime": 5,
                "auto_runtime": 1,
                "problem_id": 3,
                "prompt": {
                    "verified_context": [
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i want 100 first customers in my business",
                                    "topic_hint": "business goal",
                                }
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i want 100 first customers in my business",
                                    "topic_hint": "business goal",
                                },
                                {
                                    "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",
                                    "topic_hint": "product and target audience",
                                },
                                {
                                    "raw_text": "my product avg price point is 2000-4000 tk. and i already told you about typical buyers.",
                                    "topic_hint": "pricing",
                                },
                                {
                                    "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                                    "topic_hint": "business model and operations",
                                },
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",
                                    "topic_hint": "business description and target audience",
                                },
                                {
                                    "raw_text": "my product avg price point is 2000-4000 tk.",
                                    "topic_hint": "pricing",
                                },
                                {
                                    "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team.",
                                    "topic_hint": "business resources and budget",
                                },
                                {
                                    "raw_text": "my products are coming from a supplier who is already successfully selling his this iteams on facebook... i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                                    "topic_hint": "business model and supplier agreement",
                                },
                                {
                                    "raw_text": "in ocean if a big boat come to catch fish that not mean others boat will not get any fishes... same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.",
                                    "topic_hint": "market analysis and customer behavior",
                                },
                                {
                                    "raw_text": "just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",
                                    "topic_hint": "distribution plan",
                                },
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.",
                                    "topic_hint": "pricing strategy and business goals",
                                },
                                {
                                    "raw_text": "nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",
                                    "topic_hint": "content creation and inventory status",
                                },
                            ],
                        },
                    ],
                    "advisor_strategy": {
                        "title": "Transitioning from Generic Reseller to Home Stylist Consultant",
                        "business_summary": {
                            "business_model": "Zero-budget, dropshipping-style reseller",
                            "product_category": "Home decor showpieces",
                            "price_range_bdt": 0,
                            "target_customer": "Bangladeshi women who value social status, organization, and respect",
                            "market": "Bangladesh",
                            "fulfillment": "Supplier handles logistics and COD",
                            "constraints": [
                                "100% dependent on supplier's content",
                                "No established network or distribution plan",
                                "Zero budget",
                                "No unique value proposition",
                            ],
                        },
                        "real_problem": {
                            "surface_problem": "You have no 'Unique Value Proposition' (UVP).",
                            "actual_problem": "The business is a mirror of the supplier, leading to duplicate content issues with the algorithm and a lack of customer trust compared to the original source.",
                            "supporting_context": [
                                "Facebook algorithm treats duplicate content as spam, reducing reach.",
                                "Customers have no logical reason to buy from an unproven new page when the original source has 50k followers.",
                                "The market is price-sensitive with customers comparing multiple sellers.",
                            ],
                        },
                        "strategy_reasoning": {
                            "core_constraint": "Inability to change the product, price, or original footage.",
                            "approach": "Change the context of how the product is presented to provide value beyond the object itself.",
                            "channels": [
                                "Facebook Reels",
                                "Home decor and women's community groups",
                            ],
                        },
                        "assumptions_risks_tradeoffs": {
                            "assumptions": [
                                "The supplier's reels are high-quality enough to be edited into 'tips' videos."
                            ],
                            "risks": [
                                {
                                    "risk": "Supplier stock levels",
                                    "impact": "If a product goes viral but is sold out at the supplier, you will lose customer trust.",
                                    "mitigation": 0,
                                }
                            ],
                            "tradeoffs": [
                                "The 'Stylist' approach requires more time per post than simply changing music, but it is necessary for organic reach without a budget."
                            ],
                        },
                        "prioritized_action_plan": [
                            {
                                "priority": 1,
                                "title": "Shift from Seller to Home Stylist",
                                "action": "Transform supplier footage into advice-based content using text overlays.",
                                "execution": [
                                    "Use CapCut to add educational text overlays to existing reels.",
                                    "Focus titles on results like '3 ways to make your drawing room look more respectful for guests' or 'How to organize your shelf to look like a luxury home'.",
                                ],
                            }
                        ],
                    },
                    "target_action": {
                        "priority": 1,
                        "title": "Shift from Seller to Home Stylist",
                        "action": "Transform supplier footage into advice-based content using text overlays.",
                        "execution": [
                            "Use CapCut to add educational text overlays to existing reels.",
                            "Focus titles on results like '3 ways to make your drawing room look more respectful for guests' or 'How to organize your shelf to look like a luxury home'.",
                        ],
                    },
                },
                "output": {
                    "action_title": "Shift from Seller to Home Stylist",
                    "claim": "Transforming supplier footage into advice-based content using text overlays will differentiate the business and increase organic reach/trust.",
                    "mechanism": "By adding educational value (styling tips) to the supplier's product footage, the seller creates a unique value proposition that distinguishes them from the supplier and other resellers, thereby overcoming the 'duplicate content' penalty and building trust with potential customers.",
                    "load_bearing_assumptions": [
                        {
                            "assumption": "The Facebook algorithm will prioritize or increase reach for edited/repurposed content over the original supplier's raw footage.",
                            "classification": "ASSUMPTION",
                            "evidence": "This assumes that adding text overlays is sufficient to bypass or improve upon the algorithm's detection of duplicate content, which is not established in the context.",
                        },
                        {
                            "assumption": "Target customers (Bangladeshi women) will perceive the seller as a 'stylist' rather than a reseller based solely on text overlays on supplier videos.",
                            "classification": "ASSUMPTION",
                            "evidence": "This assumes that the customer's perception of authority and trust can be built through superficial content changes without original product access or unique branding.",
                        },
                        {
                            "assumption": "The supplier's existing reels contain enough visual variety to support multiple 'educational' or 'styling' narratives.",
                            "classification": "ASSUMPTION",
                            "evidence": "The business is 100% dependent on supplier reels; if the footage is purely product-focused, it may not support the 'stylist' narrative effectively.",
                        },
                    ],
                    "structural_flags": [],
                    "settled_as_fact_violation": 0,
                    "verdict": "CONDITIONAL",
                    "verdict_reason": "The mechanism relies on the unverified assumption that adding text overlays will successfully differentiate the content in the eyes of the algorithm and the customer. While it addresses the lack of a unique value proposition, it remains uncertain if this level of content modification is sufficient to overcome the inherent trust advantage of the supplier's 50k-follower page.",
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Reality-Check Critic #6",
                "runtime": 5,
                "auto_runtime": 1,
                "problem_id": 3,
                "prompt": {
                    "verified_context": [
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i want 100 first customers in my business",
                                    "topic_hint": "business goal",
                                }
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i want 100 first customers in my business",
                                    "topic_hint": "business goal",
                                },
                                {
                                    "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",
                                    "topic_hint": "product and target audience",
                                },
                                {
                                    "raw_text": "my product avg price point is 2000-4000 tk. and i already told you about typical buyers.",
                                    "topic_hint": "pricing",
                                },
                                {
                                    "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                                    "topic_hint": "business model and operations",
                                },
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",
                                    "topic_hint": "business description and target audience",
                                },
                                {
                                    "raw_text": "my product avg price point is 2000-4000 tk.",
                                    "topic_hint": "pricing",
                                },
                                {
                                    "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team.",
                                    "topic_hint": "business resources and budget",
                                },
                                {
                                    "raw_text": "my products are coming from a supplier who is already successfully selling his this iteams on facebook... i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                                    "topic_hint": "business model and supplier agreement",
                                },
                                {
                                    "raw_text": "in ocean if a big boat come to catch fish that not mean others boat will not get any fishes... same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.",
                                    "topic_hint": "market analysis and customer behavior",
                                },
                                {
                                    "raw_text": "just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",
                                    "topic_hint": "distribution plan",
                                },
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.",
                                    "topic_hint": "pricing strategy and business goals",
                                },
                                {
                                    "raw_text": "nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",
                                    "topic_hint": "content creation and inventory status",
                                },
                            ],
                        },
                    ],
                    "advisor_strategy": {
                        "title": "Transitioning from Generic Reseller to Home Stylist Consultant",
                        "business_summary": {
                            "business_model": "Zero-budget, dropshipping-style reseller",
                            "product_category": "Home decor showpieces",
                            "price_range_bdt": 0,
                            "target_customer": "Bangladeshi women who value social status, organization, and respect",
                            "market": "Bangladesh",
                            "fulfillment": "Supplier handles logistics and COD",
                            "constraints": [
                                "100% dependent on supplier's content",
                                "No established network or distribution plan",
                                "Zero budget",
                                "No unique value proposition",
                            ],
                        },
                        "real_problem": {
                            "surface_problem": "You have no 'Unique Value Proposition' (UVP).",
                            "actual_problem": "The business is a mirror of the supplier, leading to duplicate content issues with the algorithm and a lack of customer trust compared to the original source.",
                            "supporting_context": [
                                "Facebook algorithm treats duplicate content as spam, reducing reach.",
                                "Customers have no logical reason to buy from an unproven new page when the original source has 50k followers.",
                                "The market is price-sensitive with customers comparing multiple sellers.",
                            ],
                        },
                        "strategy_reasoning": {
                            "core_constraint": "Inability to change the product, price, or original footage.",
                            "approach": "Change the context of how the product is presented to provide value beyond the object itself.",
                            "channels": [
                                "Facebook Reels",
                                "Home decor and women's community groups",
                            ],
                        },
                        "assumptions_risks_tradeoffs": {
                            "assumptions": [
                                "The supplier's reels are high-quality enough to be edited into 'tips' videos."
                            ],
                            "risks": [
                                {
                                    "risk": "Supplier stock levels",
                                    "impact": "If a product goes viral but is sold out at the supplier, you will lose customer trust.",
                                    "mitigation": 0,
                                }
                            ],
                            "tradeoffs": [
                                "The 'Stylist' approach requires more time per post than simply changing music, but it is necessary for organic reach without a budget."
                            ],
                        },
                        "prioritized_action_plan": [
                            {
                                "priority": 2,
                                "title": "Value-First Group Strategy",
                                "action": "Build trust through problem-solving in community groups rather than spamming products.",
                                "execution": [
                                    "Join home decor and women's community groups.",
                                    "Provide genuine home improvement advice to members.",
                                    "Offer product details only after establishing a helpful connection.",
                                ],
                            }
                        ],
                    },
                    "target_action": {
                        "priority": 2,
                        "title": "Value-First Group Strategy",
                        "action": "Build trust through problem-solving in community groups rather than spamming products.",
                        "execution": [
                            "Join home decor and women's community groups.",
                            "Provide genuine home improvement advice to members.",
                            "Offer product details only after establishing a helpful connection.",
                        ],
                    },
                },
                "output": {
                    "action_title": "Value-First Group Strategy",
                    "claim": "Build trust through problem-solving in community groups rather than spamming products to acquire the first 100 customers.",
                    "mechanism": "By establishing authority and trust through helpful advice in community groups, the user can overcome the lack of brand recognition and compete with the supplier's established page.",
                    "load_bearing_assumptions": [
                        {
                            "assumption": "Bangladeshi women's community groups on Facebook allow members to provide advice without immediate product promotion.",
                            "classification": "ASSUMPTION",
                            "evidence": "This depends on the specific rules and moderation policies of individual Facebook groups, which are not provided in the context.",
                        },
                        {
                            "assumption": "Providing home improvement advice will lead to trust that converts into sales for the specific showpieces being sold.",
                            "classification": "ASSUMPTION",
                            "evidence": "There is no evidence that the target audience values advice from a new, unknown seller enough to purchase from them over established competitors.",
                        },
                        {
                            "assumption": "The user has the expertise to provide 'genuine home improvement advice' that is perceived as valuable by the target audience.",
                            "classification": "ASSUMPTION",
                            "evidence": "The context states the user is a solo seller with no team and is 100% dependent on supplier content, suggesting limited independent expertise.",
                        },
                    ],
                    "structural_flags": [],
                    "settled_as_fact_violation": 0,
                    "verdict": "CONDITIONAL",
                    "verdict_reason": "The strategy relies on the unverified assumption that the user can provide valuable advice and that this will successfully convert community members into customers, despite the user's lack of unique content or established brand presence.",
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Reality-Check Critic #7",
                "runtime": 5,
                "auto_runtime": 1,
                "problem_id": 3,
                "prompt": {
                    "verified_context": [
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i want 100 first customers in my business",
                                    "topic_hint": "business goal",
                                }
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i want 100 first customers in my business",
                                    "topic_hint": "business goal",
                                },
                                {
                                    "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",
                                    "topic_hint": "product and target audience",
                                },
                                {
                                    "raw_text": "my product avg price point is 2000-4000 tk. and i already told you about typical buyers.",
                                    "topic_hint": "pricing",
                                },
                                {
                                    "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                                    "topic_hint": "business model and operations",
                                },
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",
                                    "topic_hint": "business description and target audience",
                                },
                                {
                                    "raw_text": "my product avg price point is 2000-4000 tk.",
                                    "topic_hint": "pricing",
                                },
                                {
                                    "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team.",
                                    "topic_hint": "business resources and budget",
                                },
                                {
                                    "raw_text": "my products are coming from a supplier who is already successfully selling his this iteams on facebook... i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                                    "topic_hint": "business model and supplier agreement",
                                },
                                {
                                    "raw_text": "in ocean if a big boat come to catch fish that not mean others boat will not get any fishes... same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.",
                                    "topic_hint": "market analysis and customer behavior",
                                },
                                {
                                    "raw_text": "just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",
                                    "topic_hint": "distribution plan",
                                },
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.",
                                    "topic_hint": "pricing strategy and business goals",
                                },
                                {
                                    "raw_text": "nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",
                                    "topic_hint": "content creation and inventory status",
                                },
                            ],
                        },
                    ],
                    "advisor_strategy": {
                        "title": "Transitioning from Generic Reseller to Home Stylist Consultant",
                        "business_summary": {
                            "business_model": "Zero-budget, dropshipping-style reseller",
                            "product_category": "Home decor showpieces",
                            "price_range_bdt": 0,
                            "target_customer": "Bangladeshi women who value social status, organization, and respect",
                            "market": "Bangladesh",
                            "fulfillment": "Supplier handles logistics and COD",
                            "constraints": [
                                "100% dependent on supplier's content",
                                "No established network or distribution plan",
                                "Zero budget",
                                "No unique value proposition",
                            ],
                        },
                        "real_problem": {
                            "surface_problem": "You have no 'Unique Value Proposition' (UVP).",
                            "actual_problem": "The business is a mirror of the supplier, leading to duplicate content issues with the algorithm and a lack of customer trust compared to the original source.",
                            "supporting_context": [
                                "Facebook algorithm treats duplicate content as spam, reducing reach.",
                                "Customers have no logical reason to buy from an unproven new page when the original source has 50k followers.",
                                "The market is price-sensitive with customers comparing multiple sellers.",
                            ],
                        },
                        "strategy_reasoning": {
                            "core_constraint": "Inability to change the product, price, or original footage.",
                            "approach": "Change the context of how the product is presented to provide value beyond the object itself.",
                            "channels": [
                                "Facebook Reels",
                                "Home decor and women's community groups",
                            ],
                        },
                        "assumptions_risks_tradeoffs": {
                            "assumptions": [
                                "The supplier's reels are high-quality enough to be edited into 'tips' videos."
                            ],
                            "risks": [
                                {
                                    "risk": "Supplier stock levels",
                                    "impact": "If a product goes viral but is sold out at the supplier, you will lose customer trust.",
                                    "mitigation": 0,
                                }
                            ],
                            "tradeoffs": [
                                "The 'Stylist' approach requires more time per post than simply changing music, but it is necessary for organic reach without a budget."
                            ],
                        },
                        "prioritized_action_plan": [
                            {
                                "priority": 3,
                                "title": "Leverage the Personal Shopper Angle",
                                "action": "Position the business as a curator to justify buying from a smaller seller.",
                                "execution": [
                                    "Communicate as a curator who saves customers time by picking the best pieces from the supplier."
                                ],
                            }
                        ],
                    },
                    "target_action": {
                        "priority": 3,
                        "title": "Leverage the Personal Shopper Angle",
                        "action": "Position the business as a curator to justify buying from a smaller seller.",
                        "execution": [
                            "Communicate as a curator who saves customers time by picking the best pieces from the supplier."
                        ],
                    },
                },
                "output": {
                    "action_title": "Leverage the Personal Shopper Angle",
                    "claim": "Positioning the business as a curator who saves customers time will justify buying from a smaller seller.",
                    "mechanism": "By framing the business as a 'curator' who saves time, the seller creates a unique value proposition that differentiates them from the supplier, thereby overcoming the lack of trust and the disadvantage of being a new, smaller page.",
                    "load_bearing_assumptions": [
                        {
                            "assumption": "Customers will perceive a 'curator' as more valuable than the original supplier with 50k followers.",
                            "classification": "ASSUMPTION",
                            "evidence": "This requires evidence that the target audience values curation over the social proof and established trust of the original supplier.",
                        },
                        {
                            "assumption": "The target audience is willing to pay the same price (or more) to a new, unproven seller for the convenience of 'curation'.",
                            "classification": "ASSUMPTION",
                            "evidence": "The context states customers compare prices across multiple sellers and buy from the lowest price; this assumption requires evidence that curation overrides price sensitivity.",
                        },
                        {
                            "assumption": "The Facebook algorithm will distinguish the 'curator' content from the supplier's original content despite using the same source reels.",
                            "classification": "ASSUMPTION",
                            "evidence": "The context notes the business is 100% dependent on supplier reels; this assumes the 'curator' framing is sufficient to avoid being flagged as duplicate/spam content.",
                        },
                    ],
                    "structural_flags": [],
                    "settled_as_fact_violation": 0,
                    "verdict": "CONDITIONAL",
                    "verdict_reason": "The mechanism relies on the assumption that customers will value 'curation' enough to ignore the original supplier's superior social proof and the price-sensitive nature of the market. Without evidence that this specific audience prioritizes curation over established trust and lowest price, the strategy remains unproven.",
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Problem Explainer",
                "runtime": 5,
                "auto_runtime": 1,
                "problem_id": 3,
                "prompt": [
                    {
                        "role": "system",
                        "content": "\nYou are a Problem Explainer.\n\nYour job is to examine a conditional critic result and determine\nwhether it represents a DISTINCT NEW PROBLEM that should be sent\nback to the advisor as a child problem.\n\nYou do NOT solve the problem.\n\nYou do NOT improve the advisor's strategy.\n\nYou do NOT invent facts.\n\n============================================================\nINPUTS\n============================================================\n\nYou receive:\n\n1. CURRENT_PROBLEM\n   The problem currently being solved.\n\n2. CONDITIONAL_CRITIC\n   The critic's analysis of one action from the advisor's strategy.\n\n3. VERIFIED_FACTS\n   Facts already verified about the business.\n\n============================================================\nNEW PROBLEM TEST\n============================================================\n\nCreate NEW_PROBLEM only when the critic reveals a distinct issue\nthat requires its own reasoning and solution.\n\nA conditional critic does NOT automatically create a new problem.\n\nDo NOT create a new problem when the critic is only saying:\n\n- more evidence is needed\n- an assumption should be checked\n- a minor caveat exists\n- an execution detail is uncertain\n- the action may work under certain conditions\n\nCreate NEW_PROBLEM when the critic reveals something like:\n\n- the strategy depends on a real unresolved business constraint\n- the recommendation requires solving another substantive issue first\n- a missing capability/resource must be established before the\n  original strategy can work\n- the critic exposes a distinct obstacle that deserves its own\n  advisor-level solution\n\n============================================================\nPROBLEM FORMULATION\n============================================================\n\nWhen NEW_PROBLEM:\n\n- State the problem clearly.\n- Make it actionable for the advisor.\n- Preserve the critic's meaning.\n- Use verified facts as context.\n- Do not invent causes, facts, or solutions.\n- Do not include the solution in the problem statement.\n\nThe new problem will later be pushed on top of the current\nproblem stack and sent to the advisor.\n\n============================================================\nPARENT RELATIONSHIP\n============================================================\n\nThe new problem must be a CHILD of CURRENT_PROBLEM.\n\nIt should address the issue raised by the critic, not replace\nthe parent problem.\n\n============================================================\nOUTPUT\n============================================================\n\nReturn only the structured result defined by the output schema.\n",
                    },
                    {
                        "role": "human",
                        "content": '\nCURRENT_PROBLEM:\n\n{\n  "problem_id": 3,\n  "parent_problem_id": 0,\n  "depth": 1,\n  "problem": "Determine the feasibility of offering value-added services and price adjustments given the current supplier agreement and seller capabilities.",\n  "runtime": 5,\n  "auto_runtime": 1,\n  "agent": "Advisor",\n  "status": "ACTIVE",\n  "solution": 0,\n  "source_critic_id": 3\n}\n\n\nCONDITIONAL_CRITIC:\n\n{\n  "action_title": "Shift from Seller to Home Stylist",\n  "claim": "Transforming supplier footage into advice-based content using text overlays will differentiate the business and increase organic reach/trust.",\n  "mechanism": "By adding educational value (styling tips) to the supplier\'s product footage, the seller creates a unique value proposition that distinguishes them from the supplier and other resellers, thereby overcoming the \'duplicate content\' penalty and building trust with potential customers.",\n  "load_bearing_assumptions": [\n    {\n      "assumption": "The Facebook algorithm will prioritize or increase reach for edited/repurposed content over the original supplier\'s raw footage.",\n      "classification": "ASSUMPTION",\n      "evidence": "This assumes that adding text overlays is sufficient to bypass or improve upon the algorithm\'s detection of duplicate content, which is not established in the context."\n    },\n    {\n      "assumption": "Target customers (Bangladeshi women) will perceive the seller as a \'stylist\' rather than a reseller based solely on text overlays on supplier videos.",\n      "classification": "ASSUMPTION",\n      "evidence": "This assumes that the customer\'s perception of authority and trust can be built through superficial content changes without original product access or unique branding."\n    },\n    {\n      "assumption": "The supplier\'s existing reels contain enough visual variety to support multiple \'educational\' or \'styling\' narratives.",\n      "classification": "ASSUMPTION",\n      "evidence": "The business is 100% dependent on supplier reels; if the footage is purely product-focused, it may not support the \'stylist\' narrative effectively."\n    }\n  ],\n  "structural_flags": [],\n  "settled_as_fact_violation": 0,\n  "verdict": "CONDITIONAL",\n  "verdict_reason": "The mechanism relies on the unverified assumption that adding text overlays will successfully differentiate the content in the eyes of the algorithm and the customer. While it addresses the lack of a unique value proposition, it remains uncertain if this level of content modification is sufficient to overcome the inherent trust advantage of the supplier\'s 50k-follower page."\n}\n\n\nVERIFIED_FACTS:\n\n[\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i want 100 first customers in my business",\n        "topic_hint": "business goal"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i want 100 first customers in my business",\n        "topic_hint": "business goal"\n      },\n      {\n        "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman\'s, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",\n        "topic_hint": "product and target audience"\n      },\n      {\n        "raw_text": "my product avg price point is 2000-4000 tk. and i already told you about typical buyers.",\n        "topic_hint": "pricing"\n      },\n      {\n        "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",\n        "topic_hint": "business model and operations"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman\'s, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",\n        "topic_hint": "business description and target audience"\n      },\n      {\n        "raw_text": "my product avg price point is 2000-4000 tk.",\n        "topic_hint": "pricing"\n      },\n      {\n        "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team.",\n        "topic_hint": "business resources and budget"\n      },\n      {\n        "raw_text": "my products are coming from a supplier who is already successfully selling his this iteams on facebook... i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",\n        "topic_hint": "business model and supplier agreement"\n      },\n      {\n        "raw_text": "in ocean if a big boat come to catch fish that not mean others boat will not get any fishes... same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.",\n        "topic_hint": "market analysis and customer behavior"\n      },\n      {\n        "raw_text": "just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",\n        "topic_hint": "distribution plan"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.",\n        "topic_hint": "pricing strategy and business goals"\n      },\n      {\n        "raw_text": "nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",\n        "topic_hint": "content creation and inventory status"\n      }\n    ]\n  }\n]\n',
                    },
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "text",
                            "text": '{\n  "classification": "NO_NEW_PROBLEM",\n  "reason": "The critic identifies valid concerns regarding the effectiveness of a specific marketing tactic (repurposing supplier reels). These are execution-level risks and assumptions that should be addressed within the current problem of determining the feasibility of the business model, rather than requiring a separate, distinct problem statement."\n}',
                            "extras": {
                                "signature": "EnAKbgERTTIP+ycTdrRM68hTXhDMSVxAVcCCCbNaY3YPfyDBanotKrgsXA/GoHdKDx53NtuMD+gWvtwDL1Fpz3ejtaTuV+xF08/NpaisXJ2I+AJ5Li04UrsGeKQr1emu86tJrCvKkDtcKimW5kwcp6AC"
                            },
                        }
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Problem Explainer",
                "runtime": 5,
                "auto_runtime": 1,
                "problem_id": 3,
                "prompt": [
                    {
                        "role": "system",
                        "content": "\nYou are a Problem Explainer.\n\nYour job is to examine a conditional critic result and determine\nwhether it represents a DISTINCT NEW PROBLEM that should be sent\nback to the advisor as a child problem.\n\nYou do NOT solve the problem.\n\nYou do NOT improve the advisor's strategy.\n\nYou do NOT invent facts.\n\n============================================================\nINPUTS\n============================================================\n\nYou receive:\n\n1. CURRENT_PROBLEM\n   The problem currently being solved.\n\n2. CONDITIONAL_CRITIC\n   The critic's analysis of one action from the advisor's strategy.\n\n3. VERIFIED_FACTS\n   Facts already verified about the business.\n\n============================================================\nNEW PROBLEM TEST\n============================================================\n\nCreate NEW_PROBLEM only when the critic reveals a distinct issue\nthat requires its own reasoning and solution.\n\nA conditional critic does NOT automatically create a new problem.\n\nDo NOT create a new problem when the critic is only saying:\n\n- more evidence is needed\n- an assumption should be checked\n- a minor caveat exists\n- an execution detail is uncertain\n- the action may work under certain conditions\n\nCreate NEW_PROBLEM when the critic reveals something like:\n\n- the strategy depends on a real unresolved business constraint\n- the recommendation requires solving another substantive issue first\n- a missing capability/resource must be established before the\n  original strategy can work\n- the critic exposes a distinct obstacle that deserves its own\n  advisor-level solution\n\n============================================================\nPROBLEM FORMULATION\n============================================================\n\nWhen NEW_PROBLEM:\n\n- State the problem clearly.\n- Make it actionable for the advisor.\n- Preserve the critic's meaning.\n- Use verified facts as context.\n- Do not invent causes, facts, or solutions.\n- Do not include the solution in the problem statement.\n\nThe new problem will later be pushed on top of the current\nproblem stack and sent to the advisor.\n\n============================================================\nPARENT RELATIONSHIP\n============================================================\n\nThe new problem must be a CHILD of CURRENT_PROBLEM.\n\nIt should address the issue raised by the critic, not replace\nthe parent problem.\n\n============================================================\nOUTPUT\n============================================================\n\nReturn only the structured result defined by the output schema.\n",
                    },
                    {
                        "role": "human",
                        "content": '\nCURRENT_PROBLEM:\n\n{\n  "problem_id": 3,\n  "parent_problem_id": 0,\n  "depth": 1,\n  "problem": "Determine the feasibility of offering value-added services and price adjustments given the current supplier agreement and seller capabilities.",\n  "runtime": 5,\n  "auto_runtime": 1,\n  "agent": "Advisor",\n  "status": "ACTIVE",\n  "solution": 0,\n  "source_critic_id": 3\n}\n\n\nCONDITIONAL_CRITIC:\n\n{\n  "action_title": "Value-First Group Strategy",\n  "claim": "Build trust through problem-solving in community groups rather than spamming products to acquire the first 100 customers.",\n  "mechanism": "By establishing authority and trust through helpful advice in community groups, the user can overcome the lack of brand recognition and compete with the supplier\'s established page.",\n  "load_bearing_assumptions": [\n    {\n      "assumption": "Bangladeshi women\'s community groups on Facebook allow members to provide advice without immediate product promotion.",\n      "classification": "ASSUMPTION",\n      "evidence": "This depends on the specific rules and moderation policies of individual Facebook groups, which are not provided in the context."\n    },\n    {\n      "assumption": "Providing home improvement advice will lead to trust that converts into sales for the specific showpieces being sold.",\n      "classification": "ASSUMPTION",\n      "evidence": "There is no evidence that the target audience values advice from a new, unknown seller enough to purchase from them over established competitors."\n    },\n    {\n      "assumption": "The user has the expertise to provide \'genuine home improvement advice\' that is perceived as valuable by the target audience.",\n      "classification": "ASSUMPTION",\n      "evidence": "The context states the user is a solo seller with no team and is 100% dependent on supplier content, suggesting limited independent expertise."\n    }\n  ],\n  "structural_flags": [],\n  "settled_as_fact_violation": 0,\n  "verdict": "CONDITIONAL",\n  "verdict_reason": "The strategy relies on the unverified assumption that the user can provide valuable advice and that this will successfully convert community members into customers, despite the user\'s lack of unique content or established brand presence."\n}\n\n\nVERIFIED_FACTS:\n\n[\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i want 100 first customers in my business",\n        "topic_hint": "business goal"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i want 100 first customers in my business",\n        "topic_hint": "business goal"\n      },\n      {\n        "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman\'s, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",\n        "topic_hint": "product and target audience"\n      },\n      {\n        "raw_text": "my product avg price point is 2000-4000 tk. and i already told you about typical buyers.",\n        "topic_hint": "pricing"\n      },\n      {\n        "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",\n        "topic_hint": "business model and operations"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman\'s, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",\n        "topic_hint": "business description and target audience"\n      },\n      {\n        "raw_text": "my product avg price point is 2000-4000 tk.",\n        "topic_hint": "pricing"\n      },\n      {\n        "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team.",\n        "topic_hint": "business resources and budget"\n      },\n      {\n        "raw_text": "my products are coming from a supplier who is already successfully selling his this iteams on facebook... i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",\n        "topic_hint": "business model and supplier agreement"\n      },\n      {\n        "raw_text": "in ocean if a big boat come to catch fish that not mean others boat will not get any fishes... same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.",\n        "topic_hint": "market analysis and customer behavior"\n      },\n      {\n        "raw_text": "just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",\n        "topic_hint": "distribution plan"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.",\n        "topic_hint": "pricing strategy and business goals"\n      },\n      {\n        "raw_text": "nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",\n        "topic_hint": "content creation and inventory status"\n      }\n    ]\n  }\n]\n',
                    },
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "text",
                            "text": '{\n  "classification": "NEW_PROBLEM",\n  "problem": "Develop a customer acquisition strategy that accounts for the user\'s lack of original content, limited expertise, and the competitive nature of the market, given that the user is 100% dependent on supplier-provided reels and has no budget for advertising.",\n  "reason": "The critic identifies that the proposed \'Value-First\' strategy relies on assumptions (user expertise and community trust) that contradict the verified facts (user has no original content, no team, and limited experience). This creates a fundamental gap in the business model that requires a new, viable acquisition strategy before the user can proceed."\n}',
                            "extras": {
                                "signature": "EnAKbgERTTIPw12rSkvUqvw8Gt4IArIQsOH5qQQSDdy+lxgCBfqcAh/+bLr1beN/HrHEF+DI9o6rGoiScs+mMiAmX4vKfGHQwXSSdEMwwHF8l0jMw3pXWO825isda9dzJiTtzSaAlq7+xvGVZCrE0/uy"
                            },
                        }
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Advisor LLM",
                "runtime": 5,
                "auto_runtime": 2,
                "problem_id": 5,
                "prompt": [
                    {
                        "role": "system",
                        "content": "\nROLE\n\nYou are a senior business advisor.\n\n\nPRIMARY RULE\n\nNever solve a business problem until you have enough context.\n\n\nWORKFLOW\n\nStep 1\n\nDetermine whether enough information exists to give high-confidence advice.\n\nIf NOT:\n\n• Identify only the missing information that could materially change the recommendation.\n• Ask the minimum number of high-value questions.\n• Ask no more than 3 questions in one response.\n• Group related questions together.\n• Do not ask questions that won't affect the strategy.\n• Do not give recommendations yet.\n• Do not explain your reasoning at length.\n• Do not repeat information already established.\n\nKeep the response concise.\n\nRepeat Step 1 until enough context is collected.\n\n\nStep 2\n\nOnce enough context exists:\n\n• Summarize your understanding of the business.\n• Identify the real problem (not just the stated problem).\n• Explain your reasoning.\n• Recommend prioritized actions.\n• Explain why each recommendation fits this business.\n• Mention assumptions, risks, and trade-offs.\n\nKeep the final recommendation focused and practical.\nDo not repeat the entire conversation.\nDo not add unnecessary explanation or filler.\n\n\nOUTPUT DISCIPLINE\n\nWhen asking questions:\n\n• Maximum 3 questions.\n• Ask only questions that can materially change the recommendation.\n• Do not include a long introduction.\n• Do not provide advice.\n• Do not provide a long explanation.\n• Prefer direct questions over paragraphs.\n\nWhen giving the final recommendation:\n\n• Be structured and concise.\n• Include only information relevant to the recommendation.\n• Avoid repeating facts already known unless needed for reasoning.\n• Avoid motivational filler.\n• Avoid generic business advice.\n\n\nRULES\n\n• Never invent business facts.\n• Challenge weak assumptions.\n• Consider industry, competition, customers, budget, stage, resources, and constraints before recommending actions.\n• Prefer fewer high-impact questions over many generic questions.\n• Never ask for information that is already available in the conversation.\n• Never repeat the same question in different wording unless the previous answer was genuinely incomplete.\n• Every sentence must serve the decision-making process.\n\n\nConversation history:\n",
                    },
                    {
                        "role": "human",
                        "content": "i want 100 first customers in my business",
                    },
                    {
                        "role": "ai",
                        "content": "1. What is your product or service, and who is the ideal customer?\n2. What is the price point and the typical sales cycle (e.g., impulse buy vs. long enterprise deal)?\n3. What resources (budget, team, or existing network) do you have available to acquire these customers?",
                    },
                    {
                        "role": "human",
                        "content": "1. i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.\n2. my product avg price point is 2000-4000 tk. and i already told you about typical buyers.\n3. right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                    },
                    {
                        "role": "ai",
                        "content": "1. Why would a customer buy from your page instead of buying directly from the supplier who already has 50k followers?\n2. Besides posting reels on your own page, what is your plan to get these videos in front of new people without spending money on ads?",
                    },
                    {
                        "role": "human",
                        "content": "1. in ocean if a big boat come to catch fish that not mean others boat will not get any fishes, instead the ocean is that much big and huge that if lots of big boat start fishing nothing will be effected. same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.\n2. just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",
                    },
                    {
                        "role": "ai",
                        "content": "1. Do you have the authority to set your own prices, or must you sell at the same price as the supplier?\n2. Can you create your own original photos or videos of the products, or are you 100% dependent on the supplier's reels?",
                    },
                    {
                        "role": "human",
                        "content": "1. i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.\n2. nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",
                    },
                    {
                        "role": "human",
                        "content": "1. i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.\n2. nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",
                    },
                    {
                        "role": "human",
                        "content": 'AUTOMATIC PROBLEM-SOLVING REQUEST\n\nNEW PROBLEM:\nDevelop a customer acquisition strategy that accounts for the user\'s lack of original content, limited expertise, and the competitive nature of the market, given that the user is 100% dependent on supplier-provided reels and has no budget for advertising.\n\nSOURCE CRITIC:\n{\n  "action_title": "Shift from Seller to Home Stylist",\n  "claim": "Transforming supplier footage into advice-based content using text overlays will differentiate the business and increase organic reach/trust.",\n  "mechanism": "By adding educational value (styling tips) to the supplier\'s product footage, the seller creates a unique value proposition that distinguishes them from the supplier and other resellers, thereby overcoming the \'duplicate content\' penalty and building trust with potential customers.",\n  "load_bearing_assumptions": [\n    {\n      "assumption": "The Facebook algorithm will prioritize or increase reach for edited/repurposed content over the original supplier\'s raw footage.",\n      "classification": "ASSUMPTION",\n      "evidence": "This assumes that adding text overlays is sufficient to bypass or improve upon the algorithm\'s detection of duplicate content, which is not established in the context."\n    },\n    {\n      "assumption": "Target customers (Bangladeshi women) will perceive the seller as a \'stylist\' rather than a reseller based solely on text overlays on supplier videos.",\n      "classification": "ASSUMPTION",\n      "evidence": "This assumes that the customer\'s perception of authority and trust can be built through superficial content changes without original product access or unique branding."\n    },\n    {\n      "assumption": "The supplier\'s existing reels contain enough visual variety to support multiple \'educational\' or \'styling\' narratives.",\n      "classification": "ASSUMPTION",\n      "evidence": "The business is 100% dependent on supplier reels; if the footage is purely product-focused, it may not support the \'stylist\' narrative effectively."\n    }\n  ],\n  "structural_flags": [],\n  "settled_as_fact_violation": 0,\n  "verdict": "CONDITIONAL",\n  "verdict_reason": "The mechanism relies on the unverified assumption that adding text overlays will successfully differentiate the content in the eyes of the algorithm and the customer. While it addresses the lack of a unique value proposition, it remains uncertain if this level of content modification is sufficient to overcome the inherent trust advantage of the supplier\'s 50k-follower page."\n}\n\nFULL VERIFIED FACTS:\n[\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i want 100 first customers in my business",\n        "topic_hint": "business goal"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i want 100 first customers in my business",\n        "topic_hint": "business goal"\n      },\n      {\n        "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman\'s, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",\n        "topic_hint": "product and target audience"\n      },\n      {\n        "raw_text": "my product avg price point is 2000-4000 tk. and i already told you about typical buyers.",\n        "topic_hint": "pricing"\n      },\n      {\n        "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",\n        "topic_hint": "business model and operations"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman\'s, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",\n        "topic_hint": "business description and target audience"\n      },\n      {\n        "raw_text": "my product avg price point is 2000-4000 tk.",\n        "topic_hint": "pricing"\n      },\n      {\n        "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team.",\n        "topic_hint": "business resources and budget"\n      },\n      {\n        "raw_text": "my products are coming from a supplier who is already successfully selling his this iteams on facebook... i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",\n        "topic_hint": "business model and supplier agreement"\n      },\n      {\n        "raw_text": "in ocean if a big boat come to catch fish that not mean others boat will not get any fishes... same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.",\n        "topic_hint": "market analysis and customer behavior"\n      },\n      {\n        "raw_text": "just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",\n        "topic_hint": "distribution plan"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.",\n        "topic_hint": "pricing strategy and business goals"\n      },\n      {\n        "raw_text": "nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",\n        "topic_hint": "content creation and inventory status"\n      }\n    ]\n  }\n]',
                    },
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "thinking",
                            "thinking": '*   Goal: Get first 100 customers.\n    *   Product: Home decorating showpieces.\n    *   Target Audience: Bangladeshi women (motivated by social status, organization, and respect).\n    *   Price Point: 2,000 - 4,000 TK.\n    *   Business Model: Dropshipping/Affiliate-style arrangement with a supplier. Supplier handles shipping/COD.\n    *   Resources: 0 budget, solo seller, no network.\n    *   Content: 100% dependent on supplier\'s reels (already used by a 50k follower page).\n    *   Distribution: Currently just reposting reels with different music; group sharing failed.\n    *   Market Insight (User\'s view): Customers need multiple touchpoints (7-12 times) and often buy from the lowest price.\n\n    *   *The Content Problem:* Reposting the same reels as a 50k follower page is "duplicate content." Facebook\'s algorithm often suppresses duplicate content. Even if it reaches people, there is no reason to buy from a new, empty page over an established one if the price is the same and the video is the same.\n    *   *The Trust Problem:* Home decor is visual and emotional. Buying from a page with no original photos, no reviews, and no unique voice is high-risk for the customer, even with COD.\n    *   *The Distribution Problem:* "Posting and praying" doesn\'t work. Group sharing is often seen as spam.\n\n    *   The user believes the "ocean is big" (market size), but they are fishing with the exact same bait as the big boat.\n    *   The real problem isn\'t "finding customers"; it\'s "creating a reason for a customer to choose a zero-trust page over a high-trust page when the product and price are identical."\n\n    *   *Strategy 1: Differentiation through Curation/Styling (The "Consultant" approach).* Since the user can\'t make new videos, they must add a layer of *value* on top of the videos. Instead of "Buy this vase," it\'s "3 ways to make your living room look more respectful for guests."\n    *   *Strategy 2: Aggressive Organic Distribution (The "Community" approach).* Moving beyond generic groups to specific niches or using "Engagement Bait" that leads to DMs.\n    *   *Strategy 3: Trust Building (The "Social Proof" approach).* Since they have no customers, they need to leverage the supplier\'s success or create "perceived" trust.\n\n    *   *Summary:* Solo reseller of home decor in Bangladesh, using supplier reels, 0 budget, targeting women seeking social status/organization.\n    *   *Real Problem:* Lack of "Unique Value Proposition" (UVP) and trust. The user is a mirror of the supplier, not a business.\n    *   *Reasoning:* In a commodity market (same product, same price, same video), the customer chooses the most trusted source. The supplier has 50k followers; the user has 0.\n    *   *Recommendations:*\n        1.  *Content Pivot:* Stop just changing music. Use text overlays to provide "Home Styling Tips." (e.g., "Where to place this in your drawing room to impress guests").\n        2.  *Distribution Pivot:* Instead of sharing to groups, find "Home Decor" or "Women\'s Lifestyle" groups and provide *advice* first, then mention the product in the comments or DMs.\n        3.  *Pricing/Offer:* Since the goal is 100 customers (not profit), offer a "First 100" special discount or a "Bundle" that the supplier doesn\'t offer.\n\n    *   *Constraint Check:* No budget? Yes. No original content? Yes. Solo? Yes.\n    *   *Risk:* Facebook might still flag duplicate content.\n    *   *Trade-off:* Slower growth than ads, but builds a real brand.',
                        },
                        {
                            "type": "text",
                            "text": '### Business Summary\nYou are operating as a solo reseller of home decor showpieces in the Bangladeshi market, targeting women who value social status and home organization. You have a zero-budget, low-risk model where a supplier handles inventory, shipping, and COD. You are currently 100% dependent on the supplier\'s existing video content (reels) for marketing.\n\n### The Real Problem\nYour problem is not "finding customers," but a **lack of differentiation and trust**. \n\nBecause you are using the exact same videos and the same prices as a supplier who already has 50k followers, you have no "Unique Value Proposition" (UVP). In the eyes of a customer, there is no reason to buy from a new, unproven page when they can buy the same item from the original, established source. You are not currently a business; you are a mirror of your supplier.\n\n### Reasoning\nIn a market where the product, price, and visuals are identical, the customer will always choose the path of least risk. The supplier\'s 50k followers act as "social proof." To win customers, you must provide a value that the supplier is not providing—which, in this case, must be **expert guidance or curation**, since you cannot provide a better product or a lower price.\n\n### Prioritized Recommendations\n\n**1. Pivot from "Seller" to "Home Stylist" (Content Strategy)**\nStop simply changing the music on reels. The Facebook algorithm suppresses duplicate content, and customers ignore it. Instead, use text overlays to add "Styling Advice."\n*   **Action:** Instead of a caption saying "Buy this vase," use text on the video saying: *"3 places to put this vase to make your drawing room look more organized for guests."*\n*   **Why:** You are adding value (knowledge) that the supplier isn\'t. You are selling the *result* (respect and organization), not just the *object*.\n\n**2. Implement a "Consultative" Distribution Plan**\nGeneric group sharing is viewed as spam. You must move from "broadcasting" to "conversing."\n*   **Action:** Join Bangladeshi home decor and women\'s lifestyle groups. Do not post product links. Instead, look for people asking for home improvement advice. Give them a genuine tip, then say, *"I actually have a piece that would fit that exact spot perfectly; I\'ll send you a video in DM."*\n*   **Why:** This builds one-on-one trust and bypasses the "duplicate content" problem by moving the sale to the Inbox (Messenger).\n\n**3. Create a "First 100" Incentive**\nSince your goal is customer acquisition over profit, you need a reason for people to switch from the supplier to you.\n*   **Action:** Create a "Founder\'s Club" offer. Tell your first 100 customers they get a specific benefit (e.g., a small discount, a "styling guide" PDF, or priority shipping) for being an early supporter.\n*   **Why:** This gives the customer a logical reason to choose the "smaller boat" over the "big boat."\n\n### Assumptions, Risks, and Trade-offs\n\n*   **Assumption:** I assume the supplier will allow you to offer a small discount or bundle if you are absorbing the cost from your own potential commission.\n*   **Risk (Algorithm):** Facebook may still limit the reach of repurposed reels. The only way to fully solve this is to eventually get physical samples to film your own content.\n*   **Trade-off:** This "consultative" approach is slower than running ads. You are trading time and effort for the lack of a marketing budget.',
                        },
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Verified Facts LLM",
                "runtime": 5,
                "auto_runtime": 2,
                "problem_id": 5,
                "prompt": [
                    {
                        "role": "human",
                        "content": '\nYou are a strict Verified Facts Extraction Agent.\n\nYour job is to identify VERIFIED information from ONLY the evidence provided below.\n\nYou receive exactly three pieces of evidence:\n\n1. HUMAN_MESSAGE_1\n2. HUMAN_MESSAGE_2\n3. ADVISOR_REPLY\n\nSOURCE RULES:\n\n- HUMAN_MESSAGE_1 and HUMAN_MESSAGE_2 are the ONLY sources of user-provided facts.\n- ADVISOR_REPLY is the ONLY source of questions asked by the advisor.\n- Never treat anything written by the advisor as a user fact.\n- Never invent a user answer.\n- Never use older conversation history.\n- Never assume the advisor\'s statements are true.\n- Never convert an advisor suggestion into a verified fact.\n- Never create a question that does not actually appear in ADVISOR_REPLY.\n\nThe user may provide information:\n\n- before the advisor asks about it\n- after the advisor asks about it\n\nBoth are valid.\n\n--------------------------------------------------\nHUMAN MESSAGE 1\n--------------------------------------------------\n\n1. i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.\n2. nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels\n\n--------------------------------------------------\nHUMAN MESSAGE 2\n--------------------------------------------------\n\nAUTOMATIC PROBLEM-SOLVING REQUEST\n\nNEW PROBLEM:\nDevelop a customer acquisition strategy that accounts for the user\'s lack of original content, limited expertise, and the competitive nature of the market, given that the user is 100% dependent on supplier-provided reels and has no budget for advertising.\n\nSOURCE CRITIC:\n{\n  "action_title": "Shift from Seller to Home Stylist",\n  "claim": "Transforming supplier footage into advice-based content using text overlays will differentiate the business and increase organic reach/trust.",\n  "mechanism": "By adding educational value (styling tips) to the supplier\'s product footage, the seller creates a unique value proposition that distinguishes them from the supplier and other resellers, thereby overcoming the \'duplicate content\' penalty and building trust with potential customers.",\n  "load_bearing_assumptions": [\n    {\n      "assumption": "The Facebook algorithm will prioritize or increase reach for edited/repurposed content over the original supplier\'s raw footage.",\n      "classification": "ASSUMPTION",\n      "evidence": "This assumes that adding text overlays is sufficient to bypass or improve upon the algorithm\'s detection of duplicate content, which is not established in the context."\n    },\n    {\n      "assumption": "Target customers (Bangladeshi women) will perceive the seller as a \'stylist\' rather than a reseller based solely on text overlays on supplier videos.",\n      "classification": "ASSUMPTION",\n      "evidence": "This assumes that the customer\'s perception of authority and trust can be built through superficial content changes without original product access or unique branding."\n    },\n    {\n      "assumption": "The supplier\'s existing reels contain enough visual variety to support multiple \'educational\' or \'styling\' narratives.",\n      "classification": "ASSUMPTION",\n      "evidence": "The business is 100% dependent on supplier reels; if the footage is purely product-focused, it may not support the \'stylist\' narrative effectively."\n    }\n  ],\n  "structural_flags": [],\n  "settled_as_fact_violation": 0,\n  "verdict": "CONDITIONAL",\n  "verdict_reason": "The mechanism relies on the unverified assumption that adding text overlays will successfully differentiate the content in the eyes of the algorithm and the customer. While it addresses the lack of a unique value proposition, it remains uncertain if this level of content modification is sufficient to overcome the inherent trust advantage of the supplier\'s 50k-follower page."\n}\n\nFULL VERIFIED FACTS:\n[\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i want 100 first customers in my business",\n        "topic_hint": "business goal"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i want 100 first customers in my business",\n        "topic_hint": "business goal"\n      },\n      {\n        "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman\'s, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",\n        "topic_hint": "product and target audience"\n      },\n      {\n        "raw_text": "my product avg price point is 2000-4000 tk. and i already told you about typical buyers.",\n        "topic_hint": "pricing"\n      },\n      {\n        "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",\n        "topic_hint": "business model and operations"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman\'s, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",\n        "topic_hint": "business description and target audience"\n      },\n      {\n        "raw_text": "my product avg price point is 2000-4000 tk.",\n        "topic_hint": "pricing"\n      },\n      {\n        "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team.",\n        "topic_hint": "business resources and budget"\n      },\n      {\n        "raw_text": "my products are coming from a supplier who is already successfully selling his this iteams on facebook... i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",\n        "topic_hint": "business model and supplier agreement"\n      },\n      {\n        "raw_text": "in ocean if a big boat come to catch fish that not mean others boat will not get any fishes... same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.",\n        "topic_hint": "market analysis and customer behavior"\n      },\n      {\n        "raw_text": "just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",\n        "topic_hint": "distribution plan"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.",\n        "topic_hint": "pricing strategy and business goals"\n      },\n      {\n        "raw_text": "nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",\n        "topic_hint": "content creation and inventory status"\n      }\n    ]\n  }\n]\n\n--------------------------------------------------\nADVISOR REPLY\n--------------------------------------------------\n\n### Business Summary\nYou are operating as a solo reseller of home decor showpieces in the Bangladeshi market, targeting women who value social status and home organization. You have a zero-budget, low-risk model where a supplier handles inventory, shipping, and COD. You are currently 100% dependent on the supplier\'s existing video content (reels) for marketing.\n\n### The Real Problem\nYour problem is not "finding customers," but a **lack of differentiation and trust**. \n\nBecause you are using the exact same videos and the same prices as a supplier who already has 50k followers, you have no "Unique Value Proposition" (UVP). In the eyes of a customer, there is no reason to buy from a new, unproven page when they can buy the same item from the original, established source. You are not currently a business; you are a mirror of your supplier.\n\n### Reasoning\nIn a market where the product, price, and visuals are identical, the customer will always choose the path of least risk. The supplier\'s 50k followers act as "social proof." To win customers, you must provide a value that the supplier is not providing—which, in this case, must be **expert guidance or curation**, since you cannot provide a better product or a lower price.\n\n### Prioritized Recommendations\n\n**1. Pivot from "Seller" to "Home Stylist" (Content Strategy)**\nStop simply changing the music on reels. The Facebook algorithm suppresses duplicate content, and customers ignore it. Instead, use text overlays to add "Styling Advice."\n*   **Action:** Instead of a caption saying "Buy this vase," use text on the video saying: *"3 places to put this vase to make your drawing room look more organized for guests."*\n*   **Why:** You are adding value (knowledge) that the supplier isn\'t. You are selling the *result* (respect and organization), not just the *object*.\n\n**2. Implement a "Consultative" Distribution Plan**\nGeneric group sharing is viewed as spam. You must move from "broadcasting" to "conversing."\n*   **Action:** Join Bangladeshi home decor and women\'s lifestyle groups. Do not post product links. Instead, look for people asking for home improvement advice. Give them a genuine tip, then say, *"I actually have a piece that would fit that exact spot perfectly; I\'ll send you a video in DM."*\n*   **Why:** This builds one-on-one trust and bypasses the "duplicate content" problem by moving the sale to the Inbox (Messenger).\n\n**3. Create a "First 100" Incentive**\nSince your goal is customer acquisition over profit, you need a reason for people to switch from the supplier to you.\n*   **Action:** Create a "Founder\'s Club" offer. Tell your first 100 customers they get a specific benefit (e.g., a small discount, a "styling guide" PDF, or priority shipping) for being an early supporter.\n*   **Why:** This gives the customer a logical reason to choose the "smaller boat" over the "big boat."\n\n### Assumptions, Risks, and Trade-offs\n\n*   **Assumption:** I assume the supplier will allow you to offer a small discount or bundle if you are absorbing the cost from your own potential commission.\n*   **Risk (Algorithm):** Facebook may still limit the reach of repurposed reels. The only way to fully solve this is to eventually get physical samples to film your own content.\n*   **Trade-off:** This "consultative" approach is slower than running ads. You are trading time and effort for the lack of a marketing budget.\n\n--------------------------------------------------\nTASK\n--------------------------------------------------\n\n1. Identify every actual question or information request in ADVISOR_REPLY.\n\n2. For each advisor question, search BOTH HUMAN_MESSAGE_1 and HUMAN_MESSAGE_2.\n\n3. If either human message explicitly answers the question, create a verified Q&A pair.\n\n4. The answer may appear before or after the advisor asked the question.\n\n5. Only use information explicitly present in the human messages.\n\n6. If no human message answers the question, do NOT create a Q&A pair.\n\n7. Extract user information that is not an answer to an advisor question as unprompted context.\n\n8. Preserve unprompted user context as closely as possible to the original wording.\n\n--------------------------------------------------\nIMPORTANT EXAMPLES\n--------------------------------------------------\n\nIf the user says:\n\n"hi"\n\nand the advisor asks:\n\n"What is your business?"\n\nthen:\n\n- qa_pairs must be empty\n- unprompted_context must be empty\n\nIf HUMAN_MESSAGE_1 says:\n\n"I sell handmade jewelry."\n\nand ADVISOR_REPLY later asks:\n\n"What is your business?"\n\nthen this is a verified Q&A pair even though the answer appeared before the question.\n\nIf ADVISOR_REPLY asks:\n\n"What is your budget?"\n\nand neither human message mentions a budget:\n\n- do not invent an answer\n- do not create a Q&A pair\n\n--------------------------------------------------\nANTI-HALLUCINATION RULES\n--------------------------------------------------\n\n- Never invent questions.\n- Never invent answers.\n- Never use information from older conversation history.\n- Never use information from ADVISOR_REPLY as a user fact.\n- Never assume the user agrees with the advisor.\n- Never turn advisor suggestions into facts.\n- Never reconstruct a conversation that is not provided.\n- When uncertain, do not guess.\n\n--------------------------------------------------\nOUTPUT\n--------------------------------------------------\n\nReturn ONLY the structured output required by the Pydantic output parser.\n\nThe output should be formatted as a JSON instance that conforms to the JSON schema below.\n\nAs an example, for the schema {"properties": {"foo": {"title": "Foo", "description": "a list of strings", "type": "array", "items": {"type": "string"}}}, "required": ["foo"]}\nthe object {"foo": ["bar", "baz"]} is a well-formatted instance of the schema. The object {"properties": {"foo": ["bar", "baz"]}} is not well-formatted.\n\nHere is the output schema:\n```\n{"$defs": {"QAPair": {"properties": {"question_asked": {"title": "Question Asked", "type": "string"}, "user_answer": {"title": "User Answer", "type": "string"}, "verification": {"enum": ["verified", "uncertain_match"], "title": "Verification", "type": "string"}}, "required": ["question_asked", "user_answer", "verification"], "title": "QAPair", "type": "object"}, "UnpromptedContext": {"properties": {"raw_text": {"title": "Raw Text", "type": "string"}, "topic_hint": {"title": "Topic Hint", "type": "string"}}, "required": ["raw_text", "topic_hint"], "title": "UnpromptedContext", "type": "object"}}, "properties": {"qa_pairs": {"items": {"$ref": "#/$defs/QAPair"}, "title": "Qa Pairs", "type": "array"}, "unprompted_context": {"items": {"$ref": "#/$defs/UnpromptedContext"}, "title": "Unprompted Context", "type": "array"}}}\n```\n',
                    }
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "text",
                            "text": '{\n  "qa_pairs": [],\n  "unprompted_context": [\n    {\n      "raw_text": "i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.",\n      "topic_hint": "pricing strategy and business goals"\n    },\n    {\n      "raw_text": "nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",\n      "topic_hint": "content creation and inventory status"\n    }\n  ]\n}',
                            "extras": {
                                "signature": "EnAKbgERTTIPkx8x/kwq+HtvllHkyozdG5ILwZC12HB5N6A+m0PXpPLXzms5LMxfVRwda7nviF9RuuUITRgbS2PQkKKNqKK+PIppw1vQNIbbN1f7wXEfnsoaDw6hRY4x5UXIi+1PqxePWMIARRZEJ3JC"
                            },
                        }
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Classifier LLM",
                "runtime": 5,
                "auto_runtime": 2,
                "problem_id": 5,
                "prompt": [
                    {
                        "role": "human",
                        "content": '\nYou are a response-state classifier.\n\nYour job is to determine whether the BUSINESS ADVISOR\'s latest\nresponse requires the USER to provide more information.\n\nReturn ONLY one of these two values:\n\nNEEDS_INPUT\n\nor\n\nDONE\n\n\nReturn NEEDS_INPUT when:\n\n- The advisor asks the user a question.\n- The advisor requests missing business information.\n- The advisor needs clarification before it can continue.\n- The advisor explicitly tells the user to provide something.\n\nReturn DONE when:\n\n- The advisor has enough information.\n- The advisor gives recommendations.\n- The advisor is explaining the analysis.\n- The advisor does not require another user response to continue.\n\nDo not explain your answer.\n\nAdvisor\'s latest response:\n\n### Business Summary\nYou are operating as a solo reseller of home decor showpieces in the Bangladeshi market, targeting women who value social status and home organization. You have a zero-budget, low-risk model where a supplier handles inventory, shipping, and COD. You are currently 100% dependent on the supplier\'s existing video content (reels) for marketing.\n\n### The Real Problem\nYour problem is not "finding customers," but a **lack of differentiation and trust**. \n\nBecause you are using the exact same videos and the same prices as a supplier who already has 50k followers, you have no "Unique Value Proposition" (UVP). In the eyes of a customer, there is no reason to buy from a new, unproven page when they can buy the same item from the original, established source. You are not currently a business; you are a mirror of your supplier.\n\n### Reasoning\nIn a market where the product, price, and visuals are identical, the customer will always choose the path of least risk. The supplier\'s 50k followers act as "social proof." To win customers, you must provide a value that the supplier is not providing—which, in this case, must be **expert guidance or curation**, since you cannot provide a better product or a lower price.\n\n### Prioritized Recommendations\n\n**1. Pivot from "Seller" to "Home Stylist" (Content Strategy)**\nStop simply changing the music on reels. The Facebook algorithm suppresses duplicate content, and customers ignore it. Instead, use text overlays to add "Styling Advice."\n*   **Action:** Instead of a caption saying "Buy this vase," use text on the video saying: *"3 places to put this vase to make your drawing room look more organized for guests."*\n*   **Why:** You are adding value (knowledge) that the supplier isn\'t. You are selling the *result* (respect and organization), not just the *object*.\n\n**2. Implement a "Consultative" Distribution Plan**\nGeneric group sharing is viewed as spam. You must move from "broadcasting" to "conversing."\n*   **Action:** Join Bangladeshi home decor and women\'s lifestyle groups. Do not post product links. Instead, look for people asking for home improvement advice. Give them a genuine tip, then say, *"I actually have a piece that would fit that exact spot perfectly; I\'ll send you a video in DM."*\n*   **Why:** This builds one-on-one trust and bypasses the "duplicate content" problem by moving the sale to the Inbox (Messenger).\n\n**3. Create a "First 100" Incentive**\nSince your goal is customer acquisition over profit, you need a reason for people to switch from the supplier to you.\n*   **Action:** Create a "Founder\'s Club" offer. Tell your first 100 customers they get a specific benefit (e.g., a small discount, a "styling guide" PDF, or priority shipping) for being an early supporter.\n*   **Why:** This gives the customer a logical reason to choose the "smaller boat" over the "big boat."\n\n### Assumptions, Risks, and Trade-offs\n\n*   **Assumption:** I assume the supplier will allow you to offer a small discount or bundle if you are absorbing the cost from your own potential commission.\n*   **Risk (Algorithm):** Facebook may still limit the reach of repurposed reels. The only way to fully solve this is to eventually get physical samples to film your own content.\n*   **Trade-off:** This "consultative" approach is slower than running ads. You are trading time and effort for the lack of a marketing budget.\n',
                    }
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "text",
                            "text": "DONE",
                            "extras": {
                                "signature": "EnAKbgERTTIPrlKOETHgZBye2ysqf6lv2fpXMjm5pRKraBgHS3ar2homwXN7wlENAFJA7id7W/ezWDWbUB6GOkCGfLlyaYemIXFtyU9QMjXsopP/LKLYPBG14ieXgnNNHeyaxFRQfRWet4RMVWWkWbu3"
                            },
                        }
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Systematic Advice Converter LLM",
                "runtime": 5,
                "auto_runtime": 2,
                "problem_id": 5,
                "prompt": [
                    {
                        "role": "system",
                        "content": "\nConvert the advisor reply into the BusinessStrategyBrief schema.\n\nExtract only what is stated or clearly implied in the advisor reply.\nNever invent facts.\n",
                    },
                    {
                        "role": "human",
                        "content": '### Business Summary\nYou are operating as a solo reseller of home decor showpieces in the Bangladeshi market, targeting women who value social status and home organization. You have a zero-budget, low-risk model where a supplier handles inventory, shipping, and COD. You are currently 100% dependent on the supplier\'s existing video content (reels) for marketing.\n\n### The Real Problem\nYour problem is not "finding customers," but a **lack of differentiation and trust**. \n\nBecause you are using the exact same videos and the same prices as a supplier who already has 50k followers, you have no "Unique Value Proposition" (UVP). In the eyes of a customer, there is no reason to buy from a new, unproven page when they can buy the same item from the original, established source. You are not currently a business; you are a mirror of your supplier.\n\n### Reasoning\nIn a market where the product, price, and visuals are identical, the customer will always choose the path of least risk. The supplier\'s 50k followers act as "social proof." To win customers, you must provide a value that the supplier is not providing—which, in this case, must be **expert guidance or curation**, since you cannot provide a better product or a lower price.\n\n### Prioritized Recommendations\n\n**1. Pivot from "Seller" to "Home Stylist" (Content Strategy)**\nStop simply changing the music on reels. The Facebook algorithm suppresses duplicate content, and customers ignore it. Instead, use text overlays to add "Styling Advice."\n*   **Action:** Instead of a caption saying "Buy this vase," use text on the video saying: *"3 places to put this vase to make your drawing room look more organized for guests."*\n*   **Why:** You are adding value (knowledge) that the supplier isn\'t. You are selling the *result* (respect and organization), not just the *object*.\n\n**2. Implement a "Consultative" Distribution Plan**\nGeneric group sharing is viewed as spam. You must move from "broadcasting" to "conversing."\n*   **Action:** Join Bangladeshi home decor and women\'s lifestyle groups. Do not post product links. Instead, look for people asking for home improvement advice. Give them a genuine tip, then say, *"I actually have a piece that would fit that exact spot perfectly; I\'ll send you a video in DM."*\n*   **Why:** This builds one-on-one trust and bypasses the "duplicate content" problem by moving the sale to the Inbox (Messenger).\n\n**3. Create a "First 100" Incentive**\nSince your goal is customer acquisition over profit, you need a reason for people to switch from the supplier to you.\n*   **Action:** Create a "Founder\'s Club" offer. Tell your first 100 customers they get a specific benefit (e.g., a small discount, a "styling guide" PDF, or priority shipping) for being an early supporter.\n*   **Why:** This gives the customer a logical reason to choose the "smaller boat" over the "big boat."\n\n### Assumptions, Risks, and Trade-offs\n\n*   **Assumption:** I assume the supplier will allow you to offer a small discount or bundle if you are absorbing the cost from your own potential commission.\n*   **Risk (Algorithm):** Facebook may still limit the reach of repurposed reels. The only way to fully solve this is to eventually get physical samples to film your own content.\n*   **Trade-off:** This "consultative" approach is slower than running ads. You are trading time and effort for the lack of a marketing budget.',
                    },
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "text",
                            "text": '{\n  "title": "Transitioning from Reseller to Home Stylist",\n  "business_summary": {\n    "business_model": "Solo reseller using a dropshipping model with supplier-handled inventory, shipping, and COD.",\n    "product_category": "Home decor showpieces",\n    "price_range_bdt": 0,\n    "target_customer": "Women in Bangladesh who value social status and home organization.",\n    "market": "Bangladesh",\n    "fulfillment": "Supplier handles inventory, shipping, and COD.",\n    "constraints": [\n      "Zero-budget",\n      "Low-risk model",\n      "100% dependency on supplier\'s existing video content",\n      "No unique value proposition compared to the supplier"\n    ]\n  },\n  "real_problem": {\n    "surface_problem": "Finding customers.",\n    "actual_problem": "Lack of differentiation and trust due to being a mirror of the supplier.",\n    "supporting_context": [\n      "Using identical videos and prices as a supplier with 50k followers.",\n      "Customers prefer the established supplier due to social proof and lower perceived risk.",\n      "Facebook algorithm suppresses duplicate content."\n    ]\n  },\n  "strategy_reasoning": {\n    "core_constraint": "Lack of differentiation in product, price, and visuals.",\n    "approach": "Shift from being a generic seller to an expert home stylist to provide value through curation and guidance.",\n    "channels": [\n      "Facebook Reels",\n      "Bangladeshi home decor and women\'s lifestyle groups",\n      "Messenger (DM)"\n    ]\n  },\n  "prioritized_action_plan": [\n    {\n      "priority": 1,\n      "title": "Pivot from Seller to Home Stylist",\n      "action": "Add expert styling advice to existing video content.",\n      "execution": [\n        "Use text overlays on videos to provide styling tips.",\n        "Focus on selling the result (organization/respect) rather than just the object."\n      ]\n    },\n    {\n      "priority": 2,\n      "title": "Implement a Consultative Distribution Plan",\n      "action": "Move from broadcasting to one-on-one conversations in niche groups.",\n      "execution": [\n        "Join Bangladeshi home decor and lifestyle groups.",\n        "Provide genuine advice to members seeking help.",\n        "Transition to private DMs to offer specific product recommendations."\n      ]\n    },\n    {\n      "priority": 3,\n      "title": "Create a First 100 Incentive",\n      "action": "Launch a Founder\'s Club offer to incentivize early customers.",\n      "execution": [\n        "Offer benefits like small discounts, styling guide PDFs, or priority shipping to the first 100 customers."\n      ]\n    }\n  ],\n  "assumptions_risks_tradeoffs": {\n    "assumptions": [\n      "The supplier will allow the reseller to offer small discounts or bundles by absorbing the cost from the commission."\n    ],\n    "risks": [\n      {\n        "risk": "Facebook algorithm limiting reach of repurposed reels.",\n        "impact": "Reduced visibility and customer acquisition.",\n        "mitigation": "Eventually obtain physical samples to film original content."\n      }\n    ],\n    "tradeoffs": [\n      "The consultative approach is slower than running ads, trading time and effort for the lack of a marketing budget."\n    ]\n  }\n}',
                            "extras": {
                                "signature": "EnAKbgERTTIP5tXlwMWPRj95smcaU7317qyerTc7tzcIx5iHsQhzD2yF4olZyAYdvmKabg2jguA6Qu59AmcFQuVTwFs/VcokloRs/cWKHLgkvqJtpunzfBGmKtXgRinw3yld2pvyUoL3hQ3dDDod3WUS"
                            },
                        }
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Reality-Check Critic #8",
                "runtime": 5,
                "auto_runtime": 2,
                "problem_id": 5,
                "prompt": {
                    "verified_context": [
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i want 100 first customers in my business",
                                    "topic_hint": "business goal",
                                }
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i want 100 first customers in my business",
                                    "topic_hint": "business goal",
                                },
                                {
                                    "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",
                                    "topic_hint": "product and target audience",
                                },
                                {
                                    "raw_text": "my product avg price point is 2000-4000 tk. and i already told you about typical buyers.",
                                    "topic_hint": "pricing",
                                },
                                {
                                    "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                                    "topic_hint": "business model and operations",
                                },
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",
                                    "topic_hint": "business description and target audience",
                                },
                                {
                                    "raw_text": "my product avg price point is 2000-4000 tk.",
                                    "topic_hint": "pricing",
                                },
                                {
                                    "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team.",
                                    "topic_hint": "business resources and budget",
                                },
                                {
                                    "raw_text": "my products are coming from a supplier who is already successfully selling his this iteams on facebook... i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                                    "topic_hint": "business model and supplier agreement",
                                },
                                {
                                    "raw_text": "in ocean if a big boat come to catch fish that not mean others boat will not get any fishes... same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.",
                                    "topic_hint": "market analysis and customer behavior",
                                },
                                {
                                    "raw_text": "just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",
                                    "topic_hint": "distribution plan",
                                },
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.",
                                    "topic_hint": "pricing strategy and business goals",
                                },
                                {
                                    "raw_text": "nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",
                                    "topic_hint": "content creation and inventory status",
                                },
                            ],
                        },
                    ],
                    "advisor_strategy": {
                        "title": "Transitioning from Reseller to Home Stylist",
                        "business_summary": {
                            "business_model": "Solo reseller using a dropshipping model with supplier-handled inventory, shipping, and COD.",
                            "product_category": "Home decor showpieces",
                            "price_range_bdt": 0,
                            "target_customer": "Women in Bangladesh who value social status and home organization.",
                            "market": "Bangladesh",
                            "fulfillment": "Supplier handles inventory, shipping, and COD.",
                            "constraints": [
                                "Zero-budget",
                                "Low-risk model",
                                "100% dependency on supplier's existing video content",
                                "No unique value proposition compared to the supplier",
                            ],
                        },
                        "real_problem": {
                            "surface_problem": "Finding customers.",
                            "actual_problem": "Lack of differentiation and trust due to being a mirror of the supplier.",
                            "supporting_context": [
                                "Using identical videos and prices as a supplier with 50k followers.",
                                "Customers prefer the established supplier due to social proof and lower perceived risk.",
                                "Facebook algorithm suppresses duplicate content.",
                            ],
                        },
                        "strategy_reasoning": {
                            "core_constraint": "Lack of differentiation in product, price, and visuals.",
                            "approach": "Shift from being a generic seller to an expert home stylist to provide value through curation and guidance.",
                            "channels": [
                                "Facebook Reels",
                                "Bangladeshi home decor and women's lifestyle groups",
                                "Messenger (DM)",
                            ],
                        },
                        "assumptions_risks_tradeoffs": {
                            "assumptions": [
                                "The supplier will allow the reseller to offer small discounts or bundles by absorbing the cost from the commission."
                            ],
                            "risks": [
                                {
                                    "risk": "Facebook algorithm limiting reach of repurposed reels.",
                                    "impact": "Reduced visibility and customer acquisition.",
                                    "mitigation": "Eventually obtain physical samples to film original content.",
                                }
                            ],
                            "tradeoffs": [
                                "The consultative approach is slower than running ads, trading time and effort for the lack of a marketing budget."
                            ],
                        },
                        "prioritized_action_plan": [
                            {
                                "priority": 1,
                                "title": "Pivot from Seller to Home Stylist",
                                "action": "Add expert styling advice to existing video content.",
                                "execution": [
                                    "Use text overlays on videos to provide styling tips.",
                                    "Focus on selling the result (organization/respect) rather than just the object.",
                                ],
                            }
                        ],
                    },
                    "target_action": {
                        "priority": 1,
                        "title": "Pivot from Seller to Home Stylist",
                        "action": "Add expert styling advice to existing video content.",
                        "execution": [
                            "Use text overlays on videos to provide styling tips.",
                            "Focus on selling the result (organization/respect) rather than just the object.",
                        ],
                    },
                },
                "output": {
                    "action_title": "Pivot from Seller to Home Stylist",
                    "claim": "Adding expert styling advice via text overlays to existing supplier videos will differentiate the business and attract customers.",
                    "mechanism": "By adding value through styling tips, the reseller differentiates themselves from the supplier and other competitors, building trust and authority that leads to sales.",
                    "load_bearing_assumptions": [
                        {
                            "assumption": "The supplier's existing video content allows for the addition of text overlays without violating copyright or supplier agreement terms.",
                            "classification": "ASSUMPTION",
                            "evidence": "The context states the user has permission to use the supplier's reels, but does not explicitly state permission to edit or modify them with overlays.",
                        },
                        {
                            "assumption": "Target customers (Bangladeshi women) will perceive text overlays as 'expert styling advice' rather than generic marketing clutter.",
                            "classification": "ASSUMPTION",
                            "evidence": "This is a behavioral assumption about how the target audience interprets modified content.",
                        },
                        {
                            "assumption": "Adding text overlays is sufficient to overcome the Facebook algorithm's suppression of duplicate content.",
                            "classification": "ASSUMPTION",
                            "evidence": "The context notes the algorithm suppresses duplicate content; it is unproven that simple text overlays are enough to bypass this.",
                        },
                    ],
                    "structural_flags": [],
                    "settled_as_fact_violation": 0,
                    "verdict": "CONDITIONAL",
                    "verdict_reason": "The mechanism relies on the assumption that modifying the supplier's videos with text overlays is permitted and effective at bypassing Facebook's duplicate content filters. These are unverified operational and technical constraints that could invalidate the strategy.",
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Reality-Check Critic #9",
                "runtime": 5,
                "auto_runtime": 2,
                "problem_id": 5,
                "prompt": {
                    "verified_context": [
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i want 100 first customers in my business",
                                    "topic_hint": "business goal",
                                }
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i want 100 first customers in my business",
                                    "topic_hint": "business goal",
                                },
                                {
                                    "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",
                                    "topic_hint": "product and target audience",
                                },
                                {
                                    "raw_text": "my product avg price point is 2000-4000 tk. and i already told you about typical buyers.",
                                    "topic_hint": "pricing",
                                },
                                {
                                    "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                                    "topic_hint": "business model and operations",
                                },
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",
                                    "topic_hint": "business description and target audience",
                                },
                                {
                                    "raw_text": "my product avg price point is 2000-4000 tk.",
                                    "topic_hint": "pricing",
                                },
                                {
                                    "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team.",
                                    "topic_hint": "business resources and budget",
                                },
                                {
                                    "raw_text": "my products are coming from a supplier who is already successfully selling his this iteams on facebook... i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                                    "topic_hint": "business model and supplier agreement",
                                },
                                {
                                    "raw_text": "in ocean if a big boat come to catch fish that not mean others boat will not get any fishes... same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.",
                                    "topic_hint": "market analysis and customer behavior",
                                },
                                {
                                    "raw_text": "just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",
                                    "topic_hint": "distribution plan",
                                },
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.",
                                    "topic_hint": "pricing strategy and business goals",
                                },
                                {
                                    "raw_text": "nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",
                                    "topic_hint": "content creation and inventory status",
                                },
                            ],
                        },
                    ],
                    "advisor_strategy": {
                        "title": "Transitioning from Reseller to Home Stylist",
                        "business_summary": {
                            "business_model": "Solo reseller using a dropshipping model with supplier-handled inventory, shipping, and COD.",
                            "product_category": "Home decor showpieces",
                            "price_range_bdt": 0,
                            "target_customer": "Women in Bangladesh who value social status and home organization.",
                            "market": "Bangladesh",
                            "fulfillment": "Supplier handles inventory, shipping, and COD.",
                            "constraints": [
                                "Zero-budget",
                                "Low-risk model",
                                "100% dependency on supplier's existing video content",
                                "No unique value proposition compared to the supplier",
                            ],
                        },
                        "real_problem": {
                            "surface_problem": "Finding customers.",
                            "actual_problem": "Lack of differentiation and trust due to being a mirror of the supplier.",
                            "supporting_context": [
                                "Using identical videos and prices as a supplier with 50k followers.",
                                "Customers prefer the established supplier due to social proof and lower perceived risk.",
                                "Facebook algorithm suppresses duplicate content.",
                            ],
                        },
                        "strategy_reasoning": {
                            "core_constraint": "Lack of differentiation in product, price, and visuals.",
                            "approach": "Shift from being a generic seller to an expert home stylist to provide value through curation and guidance.",
                            "channels": [
                                "Facebook Reels",
                                "Bangladeshi home decor and women's lifestyle groups",
                                "Messenger (DM)",
                            ],
                        },
                        "assumptions_risks_tradeoffs": {
                            "assumptions": [
                                "The supplier will allow the reseller to offer small discounts or bundles by absorbing the cost from the commission."
                            ],
                            "risks": [
                                {
                                    "risk": "Facebook algorithm limiting reach of repurposed reels.",
                                    "impact": "Reduced visibility and customer acquisition.",
                                    "mitigation": "Eventually obtain physical samples to film original content.",
                                }
                            ],
                            "tradeoffs": [
                                "The consultative approach is slower than running ads, trading time and effort for the lack of a marketing budget."
                            ],
                        },
                        "prioritized_action_plan": [
                            {
                                "priority": 2,
                                "title": "Implement a Consultative Distribution Plan",
                                "action": "Move from broadcasting to one-on-one conversations in niche groups.",
                                "execution": [
                                    "Join Bangladeshi home decor and lifestyle groups.",
                                    "Provide genuine advice to members seeking help.",
                                    "Transition to private DMs to offer specific product recommendations.",
                                ],
                            }
                        ],
                    },
                    "target_action": {
                        "priority": 2,
                        "title": "Implement a Consultative Distribution Plan",
                        "action": "Move from broadcasting to one-on-one conversations in niche groups.",
                        "execution": [
                            "Join Bangladeshi home decor and lifestyle groups.",
                            "Provide genuine advice to members seeking help.",
                            "Transition to private DMs to offer specific product recommendations.",
                        ],
                    },
                },
                "output": {
                    "action_title": "Implement a Consultative Distribution Plan",
                    "claim": "Move from broadcasting to one-on-one conversations in niche groups to acquire customers.",
                    "mechanism": "By providing value through advice in niche groups, the reseller builds trust and differentiates themselves from the supplier, leading to private sales conversations.",
                    "load_bearing_assumptions": [
                        {
                            "assumption": "Bangladeshi home decor and lifestyle Facebook groups allow members to provide advice and transition to private DMs for sales.",
                            "classification": "ASSUMPTION",
                            "evidence": "This requires testing group rules and community moderation policies, which are not provided in the context.",
                        },
                        {
                            "assumption": "The target audience (Bangladeshi women) is willing to engage in consultative conversations with a stranger for home decor advice.",
                            "classification": "ASSUMPTION",
                            "evidence": "This is a behavioral assumption about the target market's receptiveness to unsolicited or semi-solicited advice from a solo reseller.",
                        },
                        {
                            "assumption": "The reseller has the expertise to provide 'genuine advice' that differentiates them from the supplier.",
                            "classification": "ASSUMPTION",
                            "evidence": "The context states the reseller is a solo seller with no unique value proposition and is 100% dependent on supplier content.",
                        },
                    ],
                    "structural_flags": [
                        {
                            "flaw_type": "resource_mismatch",
                            "explanation": "The reseller has no unique value proposition or expertise (100% dependent on supplier content), making the 'consultative expert' role difficult to execute effectively.",
                        }
                    ],
                    "settled_as_fact_violation": 0,
                    "verdict": "CONDITIONAL",
                    "verdict_reason": "The mechanism relies on the reseller successfully positioning themselves as an expert, which is currently unsupported by their lack of unique assets or expertise. Success depends on whether the reseller can actually provide value that differentiates them from the supplier within the constraints of Facebook group rules.",
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Reality-Check Critic #10",
                "runtime": 5,
                "auto_runtime": 2,
                "problem_id": 5,
                "prompt": {
                    "verified_context": [
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i want 100 first customers in my business",
                                    "topic_hint": "business goal",
                                }
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i want 100 first customers in my business",
                                    "topic_hint": "business goal",
                                },
                                {
                                    "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",
                                    "topic_hint": "product and target audience",
                                },
                                {
                                    "raw_text": "my product avg price point is 2000-4000 tk. and i already told you about typical buyers.",
                                    "topic_hint": "pricing",
                                },
                                {
                                    "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                                    "topic_hint": "business model and operations",
                                },
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",
                                    "topic_hint": "business description and target audience",
                                },
                                {
                                    "raw_text": "my product avg price point is 2000-4000 tk.",
                                    "topic_hint": "pricing",
                                },
                                {
                                    "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team.",
                                    "topic_hint": "business resources and budget",
                                },
                                {
                                    "raw_text": "my products are coming from a supplier who is already successfully selling his this iteams on facebook... i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                                    "topic_hint": "business model and supplier agreement",
                                },
                                {
                                    "raw_text": "in ocean if a big boat come to catch fish that not mean others boat will not get any fishes... same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.",
                                    "topic_hint": "market analysis and customer behavior",
                                },
                                {
                                    "raw_text": "just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",
                                    "topic_hint": "distribution plan",
                                },
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.",
                                    "topic_hint": "pricing strategy and business goals",
                                },
                                {
                                    "raw_text": "nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",
                                    "topic_hint": "content creation and inventory status",
                                },
                            ],
                        },
                    ],
                    "advisor_strategy": {
                        "title": "Transitioning from Reseller to Home Stylist",
                        "business_summary": {
                            "business_model": "Solo reseller using a dropshipping model with supplier-handled inventory, shipping, and COD.",
                            "product_category": "Home decor showpieces",
                            "price_range_bdt": 0,
                            "target_customer": "Women in Bangladesh who value social status and home organization.",
                            "market": "Bangladesh",
                            "fulfillment": "Supplier handles inventory, shipping, and COD.",
                            "constraints": [
                                "Zero-budget",
                                "Low-risk model",
                                "100% dependency on supplier's existing video content",
                                "No unique value proposition compared to the supplier",
                            ],
                        },
                        "real_problem": {
                            "surface_problem": "Finding customers.",
                            "actual_problem": "Lack of differentiation and trust due to being a mirror of the supplier.",
                            "supporting_context": [
                                "Using identical videos and prices as a supplier with 50k followers.",
                                "Customers prefer the established supplier due to social proof and lower perceived risk.",
                                "Facebook algorithm suppresses duplicate content.",
                            ],
                        },
                        "strategy_reasoning": {
                            "core_constraint": "Lack of differentiation in product, price, and visuals.",
                            "approach": "Shift from being a generic seller to an expert home stylist to provide value through curation and guidance.",
                            "channels": [
                                "Facebook Reels",
                                "Bangladeshi home decor and women's lifestyle groups",
                                "Messenger (DM)",
                            ],
                        },
                        "assumptions_risks_tradeoffs": {
                            "assumptions": [
                                "The supplier will allow the reseller to offer small discounts or bundles by absorbing the cost from the commission."
                            ],
                            "risks": [
                                {
                                    "risk": "Facebook algorithm limiting reach of repurposed reels.",
                                    "impact": "Reduced visibility and customer acquisition.",
                                    "mitigation": "Eventually obtain physical samples to film original content.",
                                }
                            ],
                            "tradeoffs": [
                                "The consultative approach is slower than running ads, trading time and effort for the lack of a marketing budget."
                            ],
                        },
                        "prioritized_action_plan": [
                            {
                                "priority": 3,
                                "title": "Create a First 100 Incentive",
                                "action": "Launch a Founder's Club offer to incentivize early customers.",
                                "execution": [
                                    "Offer benefits like small discounts, styling guide PDFs, or priority shipping to the first 100 customers."
                                ],
                            }
                        ],
                    },
                    "target_action": {
                        "priority": 3,
                        "title": "Create a First 100 Incentive",
                        "action": "Launch a Founder's Club offer to incentivize early customers.",
                        "execution": [
                            "Offer benefits like small discounts, styling guide PDFs, or priority shipping to the first 100 customers."
                        ],
                    },
                },
                "output": {
                    "action_title": "Create a First 100 Incentive",
                    "claim": "Launch a Founder's Club offer to incentivize early customers to overcome the lack of differentiation and trust.",
                    "mechanism": "By offering exclusive incentives (discounts, guides, priority), the reseller creates a unique value proposition that differentiates them from the supplier and other competitors, thereby overcoming the trust barrier and encouraging the first 100 sales.",
                    "load_bearing_assumptions": [
                        {
                            "assumption": "The supplier will allow the reseller to offer small discounts or bundles by absorbing the cost from the commission.",
                            "classification": "ASSUMPTION",
                            "evidence": "The business model relies on the supplier handling all fulfillment and COD; any price change or incentive must be approved or supported by the supplier's financial structure.",
                        },
                        {
                            "assumption": "The target audience (Bangladeshi women) will perceive a 'Founder's Club' or 'styling guide' as sufficient value to choose a new, unproven seller over an established supplier with 50k followers.",
                            "classification": "ASSUMPTION",
                            "evidence": "The context states customers compare prices across multiple sellers and prefer the lowest price and established social proof.",
                        },
                    ],
                    "structural_flags": [
                        {
                            "flaw_type": "resource_mismatch",
                            "explanation": "The business model is a dropshipping arrangement where the supplier handles all fulfillment and COD. The suggestion assumes the reseller has the autonomy to offer discounts or priority shipping, which contradicts the operational constraints of the supplier-managed fulfillment model.",
                        }
                    ],
                    "settled_as_fact_violation": 0,
                    "verdict": "FAIL",
                    "verdict_reason": "The suggestion assumes the reseller has control over pricing and fulfillment logistics (discounts, priority shipping) to create incentives, which directly contradicts the established business model where the supplier handles all packaging, shipping, and COD. Furthermore, it fails to address the core constraint that customers prioritize the lowest price and established social proof, which a 'Founder's Club' label is unlikely to overcome without actual price or service differentiation.",
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Problem Explainer",
                "runtime": 5,
                "auto_runtime": 2,
                "problem_id": 5,
                "prompt": [
                    {
                        "role": "system",
                        "content": "\nYou are a Problem Explainer.\n\nYour job is to examine a conditional critic result and determine\nwhether it represents a DISTINCT NEW PROBLEM that should be sent\nback to the advisor as a child problem.\n\nYou do NOT solve the problem.\n\nYou do NOT improve the advisor's strategy.\n\nYou do NOT invent facts.\n\n============================================================\nINPUTS\n============================================================\n\nYou receive:\n\n1. CURRENT_PROBLEM\n   The problem currently being solved.\n\n2. CONDITIONAL_CRITIC\n   The critic's analysis of one action from the advisor's strategy.\n\n3. VERIFIED_FACTS\n   Facts already verified about the business.\n\n============================================================\nNEW PROBLEM TEST\n============================================================\n\nCreate NEW_PROBLEM only when the critic reveals a distinct issue\nthat requires its own reasoning and solution.\n\nA conditional critic does NOT automatically create a new problem.\n\nDo NOT create a new problem when the critic is only saying:\n\n- more evidence is needed\n- an assumption should be checked\n- a minor caveat exists\n- an execution detail is uncertain\n- the action may work under certain conditions\n\nCreate NEW_PROBLEM when the critic reveals something like:\n\n- the strategy depends on a real unresolved business constraint\n- the recommendation requires solving another substantive issue first\n- a missing capability/resource must be established before the\n  original strategy can work\n- the critic exposes a distinct obstacle that deserves its own\n  advisor-level solution\n\n============================================================\nPROBLEM FORMULATION\n============================================================\n\nWhen NEW_PROBLEM:\n\n- State the problem clearly.\n- Make it actionable for the advisor.\n- Preserve the critic's meaning.\n- Use verified facts as context.\n- Do not invent causes, facts, or solutions.\n- Do not include the solution in the problem statement.\n\nThe new problem will later be pushed on top of the current\nproblem stack and sent to the advisor.\n\n============================================================\nPARENT RELATIONSHIP\n============================================================\n\nThe new problem must be a CHILD of CURRENT_PROBLEM.\n\nIt should address the issue raised by the critic, not replace\nthe parent problem.\n\n============================================================\nOUTPUT\n============================================================\n\nReturn only the structured result defined by the output schema.\n",
                    },
                    {
                        "role": "human",
                        "content": '\nCURRENT_PROBLEM:\n\n{\n  "problem_id": 5,\n  "parent_problem_id": 3,\n  "depth": 2,\n  "problem": "Develop a customer acquisition strategy that accounts for the user\'s lack of original content, limited expertise, and the competitive nature of the market, given that the user is 100% dependent on supplier-provided reels and has no budget for advertising.",\n  "runtime": 5,\n  "auto_runtime": 2,\n  "agent": "Advisor",\n  "status": "ACTIVE",\n  "solution": 0,\n  "source_critic_id": 6\n}\n\n\nCONDITIONAL_CRITIC:\n\n{\n  "action_title": "Pivot from Seller to Home Stylist",\n  "claim": "Adding expert styling advice via text overlays to existing supplier videos will differentiate the business and attract customers.",\n  "mechanism": "By adding value through styling tips, the reseller differentiates themselves from the supplier and other competitors, building trust and authority that leads to sales.",\n  "load_bearing_assumptions": [\n    {\n      "assumption": "The supplier\'s existing video content allows for the addition of text overlays without violating copyright or supplier agreement terms.",\n      "classification": "ASSUMPTION",\n      "evidence": "The context states the user has permission to use the supplier\'s reels, but does not explicitly state permission to edit or modify them with overlays."\n    },\n    {\n      "assumption": "Target customers (Bangladeshi women) will perceive text overlays as \'expert styling advice\' rather than generic marketing clutter.",\n      "classification": "ASSUMPTION",\n      "evidence": "This is a behavioral assumption about how the target audience interprets modified content."\n    },\n    {\n      "assumption": "Adding text overlays is sufficient to overcome the Facebook algorithm\'s suppression of duplicate content.",\n      "classification": "ASSUMPTION",\n      "evidence": "The context notes the algorithm suppresses duplicate content; it is unproven that simple text overlays are enough to bypass this."\n    }\n  ],\n  "structural_flags": [],\n  "settled_as_fact_violation": 0,\n  "verdict": "CONDITIONAL",\n  "verdict_reason": "The mechanism relies on the assumption that modifying the supplier\'s videos with text overlays is permitted and effective at bypassing Facebook\'s duplicate content filters. These are unverified operational and technical constraints that could invalidate the strategy."\n}\n\n\nVERIFIED_FACTS:\n\n[\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i want 100 first customers in my business",\n        "topic_hint": "business goal"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i want 100 first customers in my business",\n        "topic_hint": "business goal"\n      },\n      {\n        "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman\'s, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",\n        "topic_hint": "product and target audience"\n      },\n      {\n        "raw_text": "my product avg price point is 2000-4000 tk. and i already told you about typical buyers.",\n        "topic_hint": "pricing"\n      },\n      {\n        "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",\n        "topic_hint": "business model and operations"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman\'s, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",\n        "topic_hint": "business description and target audience"\n      },\n      {\n        "raw_text": "my product avg price point is 2000-4000 tk.",\n        "topic_hint": "pricing"\n      },\n      {\n        "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team.",\n        "topic_hint": "business resources and budget"\n      },\n      {\n        "raw_text": "my products are coming from a supplier who is already successfully selling his this iteams on facebook... i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",\n        "topic_hint": "business model and supplier agreement"\n      },\n      {\n        "raw_text": "in ocean if a big boat come to catch fish that not mean others boat will not get any fishes... same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.",\n        "topic_hint": "market analysis and customer behavior"\n      },\n      {\n        "raw_text": "just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",\n        "topic_hint": "distribution plan"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.",\n        "topic_hint": "pricing strategy and business goals"\n      },\n      {\n        "raw_text": "nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",\n        "topic_hint": "content creation and inventory status"\n      }\n    ]\n  }\n]\n',
                    },
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "text",
                            "text": '{\n  "classification": "NEW_PROBLEM",\n  "problem": "Determine the technical and legal feasibility of modifying supplier-provided video content to bypass Facebook\'s duplicate content algorithm and ensure compliance with the supplier agreement.",\n  "reason": "The proposed strategy relies on modifying supplier videos to gain visibility. If the user cannot legally edit the videos or if the modifications are technically insufficient to bypass Facebook\'s duplicate content filters, the entire acquisition strategy will fail. This is a foundational operational constraint that must be resolved before proceeding with content-based acquisition tactics."\n}',
                            "extras": {
                                "signature": "EnAKbgERTTIPWcVHQD7DXmc8xGBy9wJ1vranUzyG8BCDdG6kheQPHFcpJrcq81y3o2Fp3Xmgw3ayX9qsp1r/ApdrMSvGRn/zhyYTgK5CYdOS1tai6z6xZ5PhCed0D/sPJP4ztKJ1ck/GfBF2clbWPz8H"
                            },
                        }
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Advisor LLM",
                "runtime": 5,
                "auto_runtime": 3,
                "problem_id": 6,
                "prompt": [
                    {
                        "role": "system",
                        "content": "\nROLE\n\nYou are a senior business advisor.\n\n\nPRIMARY RULE\n\nNever solve a business problem until you have enough context.\n\n\nWORKFLOW\n\nStep 1\n\nDetermine whether enough information exists to give high-confidence advice.\n\nIf NOT:\n\n• Identify only the missing information that could materially change the recommendation.\n• Ask the minimum number of high-value questions.\n• Ask no more than 3 questions in one response.\n• Group related questions together.\n• Do not ask questions that won't affect the strategy.\n• Do not give recommendations yet.\n• Do not explain your reasoning at length.\n• Do not repeat information already established.\n\nKeep the response concise.\n\nRepeat Step 1 until enough context is collected.\n\n\nStep 2\n\nOnce enough context exists:\n\n• Summarize your understanding of the business.\n• Identify the real problem (not just the stated problem).\n• Explain your reasoning.\n• Recommend prioritized actions.\n• Explain why each recommendation fits this business.\n• Mention assumptions, risks, and trade-offs.\n\nKeep the final recommendation focused and practical.\nDo not repeat the entire conversation.\nDo not add unnecessary explanation or filler.\n\n\nOUTPUT DISCIPLINE\n\nWhen asking questions:\n\n• Maximum 3 questions.\n• Ask only questions that can materially change the recommendation.\n• Do not include a long introduction.\n• Do not provide advice.\n• Do not provide a long explanation.\n• Prefer direct questions over paragraphs.\n\nWhen giving the final recommendation:\n\n• Be structured and concise.\n• Include only information relevant to the recommendation.\n• Avoid repeating facts already known unless needed for reasoning.\n• Avoid motivational filler.\n• Avoid generic business advice.\n\n\nRULES\n\n• Never invent business facts.\n• Challenge weak assumptions.\n• Consider industry, competition, customers, budget, stage, resources, and constraints before recommending actions.\n• Prefer fewer high-impact questions over many generic questions.\n• Never ask for information that is already available in the conversation.\n• Never repeat the same question in different wording unless the previous answer was genuinely incomplete.\n• Every sentence must serve the decision-making process.\n\n\nConversation history:\n",
                    },
                    {
                        "role": "human",
                        "content": "i want 100 first customers in my business",
                    },
                    {
                        "role": "ai",
                        "content": "1. What is your product or service, and who is the ideal customer?\n2. What is the price point and the typical sales cycle (e.g., impulse buy vs. long enterprise deal)?\n3. What resources (budget, team, or existing network) do you have available to acquire these customers?",
                    },
                    {
                        "role": "human",
                        "content": "1. i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.\n2. my product avg price point is 2000-4000 tk. and i already told you about typical buyers.\n3. right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                    },
                    {
                        "role": "ai",
                        "content": "1. Why would a customer buy from your page instead of buying directly from the supplier who already has 50k followers?\n2. Besides posting reels on your own page, what is your plan to get these videos in front of new people without spending money on ads?",
                    },
                    {
                        "role": "human",
                        "content": "1. in ocean if a big boat come to catch fish that not mean others boat will not get any fishes, instead the ocean is that much big and huge that if lots of big boat start fishing nothing will be effected. same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.\n2. just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",
                    },
                    {
                        "role": "ai",
                        "content": "1. Do you have the authority to set your own prices, or must you sell at the same price as the supplier?\n2. Can you create your own original photos or videos of the products, or are you 100% dependent on the supplier's reels?",
                    },
                    {
                        "role": "human",
                        "content": "1. i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.\n2. nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",
                    },
                    {
                        "role": "human",
                        "content": "1. i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.\n2. nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",
                    },
                    {
                        "role": "human",
                        "content": 'AUTOMATIC PROBLEM-SOLVING REQUEST\n\nNEW PROBLEM:\nDetermine the technical and legal feasibility of modifying supplier-provided video content to bypass Facebook\'s duplicate content algorithm and ensure compliance with the supplier agreement.\n\nSOURCE CRITIC:\n{\n  "action_title": "Pivot from Seller to Home Stylist",\n  "claim": "Adding expert styling advice via text overlays to existing supplier videos will differentiate the business and attract customers.",\n  "mechanism": "By adding value through styling tips, the reseller differentiates themselves from the supplier and other competitors, building trust and authority that leads to sales.",\n  "load_bearing_assumptions": [\n    {\n      "assumption": "The supplier\'s existing video content allows for the addition of text overlays without violating copyright or supplier agreement terms.",\n      "classification": "ASSUMPTION",\n      "evidence": "The context states the user has permission to use the supplier\'s reels, but does not explicitly state permission to edit or modify them with overlays."\n    },\n    {\n      "assumption": "Target customers (Bangladeshi women) will perceive text overlays as \'expert styling advice\' rather than generic marketing clutter.",\n      "classification": "ASSUMPTION",\n      "evidence": "This is a behavioral assumption about how the target audience interprets modified content."\n    },\n    {\n      "assumption": "Adding text overlays is sufficient to overcome the Facebook algorithm\'s suppression of duplicate content.",\n      "classification": "ASSUMPTION",\n      "evidence": "The context notes the algorithm suppresses duplicate content; it is unproven that simple text overlays are enough to bypass this."\n    }\n  ],\n  "structural_flags": [],\n  "settled_as_fact_violation": 0,\n  "verdict": "CONDITIONAL",\n  "verdict_reason": "The mechanism relies on the assumption that modifying the supplier\'s videos with text overlays is permitted and effective at bypassing Facebook\'s duplicate content filters. These are unverified operational and technical constraints that could invalidate the strategy."\n}\n\nFULL VERIFIED FACTS:\n[\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i want 100 first customers in my business",\n        "topic_hint": "business goal"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i want 100 first customers in my business",\n        "topic_hint": "business goal"\n      },\n      {\n        "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman\'s, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",\n        "topic_hint": "product and target audience"\n      },\n      {\n        "raw_text": "my product avg price point is 2000-4000 tk. and i already told you about typical buyers.",\n        "topic_hint": "pricing"\n      },\n      {\n        "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",\n        "topic_hint": "business model and operations"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman\'s, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",\n        "topic_hint": "business description and target audience"\n      },\n      {\n        "raw_text": "my product avg price point is 2000-4000 tk.",\n        "topic_hint": "pricing"\n      },\n      {\n        "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team.",\n        "topic_hint": "business resources and budget"\n      },\n      {\n        "raw_text": "my products are coming from a supplier who is already successfully selling his this iteams on facebook... i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",\n        "topic_hint": "business model and supplier agreement"\n      },\n      {\n        "raw_text": "in ocean if a big boat come to catch fish that not mean others boat will not get any fishes... same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.",\n        "topic_hint": "market analysis and customer behavior"\n      },\n      {\n        "raw_text": "just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",\n        "topic_hint": "distribution plan"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.",\n        "topic_hint": "pricing strategy and business goals"\n      },\n      {\n        "raw_text": "nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",\n        "topic_hint": "content creation and inventory status"\n      }\n    ]\n  }\n]',
                    },
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "thinking",
                            "thinking": '*   Goal: Get the first 100 customers.\n    *   Product: Home decorating showpieces.\n    *   Target Audience: Bangladeshi women (motivation: social status, organization, respect).\n    *   Price Point: 2000-4000 TK.\n    *   Resources: 0 budget, solo seller, no network.\n    *   Business Model: Dropshipping/Affiliate-style arrangement with a supplier. Supplier handles shipping/COD.\n    *   Content: 100% dependent on supplier\'s reels.\n    *   Distribution: Currently just posting reels with changed music; group sharing failed.\n    *   Competitive Edge: User believes in "market size" (big ocean) and the "rule of 7-12" (customers buy from the last person they see/lowest price).\n    *   Constraint: No physical products to take own photos/videos.\n\n    *   The user is essentially a "mirror" of the supplier.\n    *   The supplier has 50k followers and the original content.\n    *   Facebook\'s algorithm penalizes duplicate content. Simply changing music is often not enough to trigger organic reach for "unoriginal" content.\n    *   The user\'s strategy is based on being the "last person the customer sees" or the "cheapest," but they aren\'t currently offering a lower price (they just aren\'t increasing it).\n    *   The real problem isn\'t just "getting 100 customers," but "creating a reason for a customer to buy from a zero-follower page using recycled content when the original source is available."\n\n    *   *Summary:* Reselling home decor showpieces to Bangladeshi women via Facebook, using a supplier\'s content and fulfillment (COD). Zero budget, solo operation.\n    *   *Real Problem:* Lack of differentiation and distribution. The user is competing directly with their own supplier using the supplier\'s own content, which the Facebook algorithm likely suppresses as duplicate, and the customer has no incentive to choose the reseller over the established source.\n    *   *Reasoning:*\n        *   Algorithm: Facebook prioritizes original content. Recycled reels with different music rarely go viral.\n        *   Trust: A page with 0 followers vs. 50k followers.\n        *   Value Prop: If the price is the same and the product is the same, there is no "hook."\n    *   *Recommendations:*\n        1.  *Content Modification (The "Curator" approach):* Since they can\'t film, they must edit. Instead of just music, add "Styling Tips" or "Home Makeover" text overlays. This changes the content from a "Product Ad" to "Advice."\n        2.  *Distribution (The "Micro-Community" approach):* Stop generic group spamming. Find specific "Home Decor" or "Women\'s Lifestyle" groups in Bangladesh and provide value/advice first, then link the product.\n        3.  *The "First 100" Offer:* Since profit isn\'t the goal, create a "First 100" limited-time offer (e.g., a small discount or a "bundle" deal if the supplier allows) to create urgency.\n\n    *   *Constraint Check:* No motivational filler. No generic advice. Structured and concise.\n    *   *Assumption:* The supplier allows editing of the reels.\n    *   *Risk:* Facebook may still flag content as unoriginal.\n\n    *   *Summary:* Reselling home decor to Bangladeshi women via Facebook using a supplier\'s content and COD fulfillment. Zero budget, solo operation.\n    *   *Real Problem:* You are a "shadow" of your supplier. Without original content or a unique value proposition, the Facebook algorithm will suppress your reach, and customers have no reason to trust a new page over a 50k-follower page.\n    *   *Reasoning:*\n        *   Algorithm: Facebook detects duplicate video frames. Changing music is insufficient to trigger organic growth.\n        *   Trust Gap: In high-ticket items (2k-4k TK), trust is the primary barrier. A page with no history cannot compete on "presence" alone.\n        *   Price: You are matching the supplier\'s price, meaning you have no competitive advantage on cost.\n    *   *Actions:*\n        1.  *Pivot from "Seller" to "Stylist":* Do not just repost reels. Use a free editor (CapCut) to add text overlays that give "Home Styling Tips" (e.g., "3 ways to place this on your dining table to look more elegant"). This transforms the video from a duplicate ad into "educational content," which the algorithm and users prefer.\n        2.  *Targeted Engagement (Not Spamming):* Instead of sharing links in groups, find "Home Decor" or "Bangladeshi Housewives" groups. Answer questions about home organization first. Once you provide value, mention your product as a solution.\n        3.  *Create a "Founder\'s Offer":* Since profit isn\'t the goal, offer a "First 100 Customers" special. Even a small discount (e.g., 100-200 TK) or a "Buy 2, get a small gift" (negotiate this with the supplier) creates a reason to buy from *you* instead of the supplier.\n    *   *Risks/Trade-offs:*\n        *   Risk: The supplier may not agree to a price drop.\n        *   Trade-off: Editing videos takes more time than just changing music.\n        *   Assumption: You have basic video editing skills.',
                        },
                        {
                            "type": "text",
                            "text": '**Business Summary**\nYou are reselling home decor showpieces to Bangladeshi women via Facebook, utilizing a supplier\'s content and fulfillment (COD). You are operating as a solo founder with zero budget and no existing network, relying entirely on the supplier\'s reels for marketing.\n\n**The Real Problem**\nYou are a "shadow" of your supplier. Because you are using the same videos and the same prices as a page with 50k followers, you have no **competitive advantage** and no **algorithmic advantage**. Facebook\'s algorithm suppresses duplicate content, and customers have no incentive to trust a new, small page over the established original source.\n\n**Reasoning**\n*   **Algorithm:** Changing background music is not enough to bypass Facebook\'s duplicate content detection. The visual frames remain the same, meaning your reach will remain low.\n*   **Trust Gap:** For products priced at 2,000–4,000 TK, trust is the primary barrier. A customer will not choose a 0-follower page over a 50k-follower page if the product and price are identical.\n*   **Value Proposition:** Your current strategy relies on the "rule of 7-12" (being the last person the customer sees), but this only works if the customer actually *sees* your content first.\n\n**Prioritized Actions**\n\n1.  **Pivot from "Seller" to "Home Stylist"**\n    *   **Action:** Stop reposting raw reels. Use a free editor (like CapCut) to add text overlays that provide "Styling Tips" (e.g., *"3 ways to place this on your dining table to look more elegant"* or *"How to organize your shelf for guests"*).\n    *   **Why:** This transforms the content from a "duplicate ad" into "educational value." It differentiates you from the supplier and gives the customer a reason to follow you for your expertise, not just the product.\n\n2.  **Implement a "First 100" Incentive**\n    *   **Action:** Since profit is not your current goal, create a specific "Founder\'s Offer" for the first 100 customers. This could be a small discount (e.g., 100–200 TK off) or a "Bundle Deal" (negotiate a small free gift from the supplier for bulk buys).\n    *   **Why:** You must give the customer a logical reason to buy from a small page instead of the big one. A lower price or a bonus is the only immediate lever you have.\n\n3.  **High-Intent Community Engagement**\n    *   **Action:** Stop generic group sharing. Join "Home Decor" or "Bangladeshi Women\'s Lifestyle" groups. Instead of posting links, find people asking for home improvement advice. Give them a helpful tip first, then suggest your product as the solution.\n    *   **Why:** Direct selling in groups is often flagged as spam. Providing value first builds the "respect" and "organization" image your target audience craves.\n\n**Assumptions, Risks, and Trade-offs**\n*   **Assumption:** You have the basic technical ability to add text overlays to videos.\n*   **Risk:** The supplier may refuse to lower the price or provide free gifts for your "First 100" offer.\n*   **Trade-off:** This approach requires significantly more time per post than simply changing the music, but it is the only way to gain organic reach without a budget.',
                        },
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Verified Facts LLM",
                "runtime": 5,
                "auto_runtime": 3,
                "problem_id": 6,
                "prompt": [
                    {
                        "role": "human",
                        "content": '\nYou are a strict Verified Facts Extraction Agent.\n\nYour job is to identify VERIFIED information from ONLY the evidence provided below.\n\nYou receive exactly three pieces of evidence:\n\n1. HUMAN_MESSAGE_1\n2. HUMAN_MESSAGE_2\n3. ADVISOR_REPLY\n\nSOURCE RULES:\n\n- HUMAN_MESSAGE_1 and HUMAN_MESSAGE_2 are the ONLY sources of user-provided facts.\n- ADVISOR_REPLY is the ONLY source of questions asked by the advisor.\n- Never treat anything written by the advisor as a user fact.\n- Never invent a user answer.\n- Never use older conversation history.\n- Never assume the advisor\'s statements are true.\n- Never convert an advisor suggestion into a verified fact.\n- Never create a question that does not actually appear in ADVISOR_REPLY.\n\nThe user may provide information:\n\n- before the advisor asks about it\n- after the advisor asks about it\n\nBoth are valid.\n\n--------------------------------------------------\nHUMAN MESSAGE 1\n--------------------------------------------------\n\n1. i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.\n2. nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels\n\n--------------------------------------------------\nHUMAN MESSAGE 2\n--------------------------------------------------\n\nAUTOMATIC PROBLEM-SOLVING REQUEST\n\nNEW PROBLEM:\nDetermine the technical and legal feasibility of modifying supplier-provided video content to bypass Facebook\'s duplicate content algorithm and ensure compliance with the supplier agreement.\n\nSOURCE CRITIC:\n{\n  "action_title": "Pivot from Seller to Home Stylist",\n  "claim": "Adding expert styling advice via text overlays to existing supplier videos will differentiate the business and attract customers.",\n  "mechanism": "By adding value through styling tips, the reseller differentiates themselves from the supplier and other competitors, building trust and authority that leads to sales.",\n  "load_bearing_assumptions": [\n    {\n      "assumption": "The supplier\'s existing video content allows for the addition of text overlays without violating copyright or supplier agreement terms.",\n      "classification": "ASSUMPTION",\n      "evidence": "The context states the user has permission to use the supplier\'s reels, but does not explicitly state permission to edit or modify them with overlays."\n    },\n    {\n      "assumption": "Target customers (Bangladeshi women) will perceive text overlays as \'expert styling advice\' rather than generic marketing clutter.",\n      "classification": "ASSUMPTION",\n      "evidence": "This is a behavioral assumption about how the target audience interprets modified content."\n    },\n    {\n      "assumption": "Adding text overlays is sufficient to overcome the Facebook algorithm\'s suppression of duplicate content.",\n      "classification": "ASSUMPTION",\n      "evidence": "The context notes the algorithm suppresses duplicate content; it is unproven that simple text overlays are enough to bypass this."\n    }\n  ],\n  "structural_flags": [],\n  "settled_as_fact_violation": 0,\n  "verdict": "CONDITIONAL",\n  "verdict_reason": "The mechanism relies on the assumption that modifying the supplier\'s videos with text overlays is permitted and effective at bypassing Facebook\'s duplicate content filters. These are unverified operational and technical constraints that could invalidate the strategy."\n}\n\nFULL VERIFIED FACTS:\n[\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i want 100 first customers in my business",\n        "topic_hint": "business goal"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i want 100 first customers in my business",\n        "topic_hint": "business goal"\n      },\n      {\n        "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman\'s, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",\n        "topic_hint": "product and target audience"\n      },\n      {\n        "raw_text": "my product avg price point is 2000-4000 tk. and i already told you about typical buyers.",\n        "topic_hint": "pricing"\n      },\n      {\n        "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",\n        "topic_hint": "business model and operations"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman\'s, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",\n        "topic_hint": "business description and target audience"\n      },\n      {\n        "raw_text": "my product avg price point is 2000-4000 tk.",\n        "topic_hint": "pricing"\n      },\n      {\n        "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team.",\n        "topic_hint": "business resources and budget"\n      },\n      {\n        "raw_text": "my products are coming from a supplier who is already successfully selling his this iteams on facebook... i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",\n        "topic_hint": "business model and supplier agreement"\n      },\n      {\n        "raw_text": "in ocean if a big boat come to catch fish that not mean others boat will not get any fishes... same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.",\n        "topic_hint": "market analysis and customer behavior"\n      },\n      {\n        "raw_text": "just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",\n        "topic_hint": "distribution plan"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.",\n        "topic_hint": "pricing strategy and business goals"\n      },\n      {\n        "raw_text": "nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",\n        "topic_hint": "content creation and inventory status"\n      }\n    ]\n  }\n]\n\n--------------------------------------------------\nADVISOR REPLY\n--------------------------------------------------\n\n**Business Summary**\nYou are reselling home decor showpieces to Bangladeshi women via Facebook, utilizing a supplier\'s content and fulfillment (COD). You are operating as a solo founder with zero budget and no existing network, relying entirely on the supplier\'s reels for marketing.\n\n**The Real Problem**\nYou are a "shadow" of your supplier. Because you are using the same videos and the same prices as a page with 50k followers, you have no **competitive advantage** and no **algorithmic advantage**. Facebook\'s algorithm suppresses duplicate content, and customers have no incentive to trust a new, small page over the established original source.\n\n**Reasoning**\n*   **Algorithm:** Changing background music is not enough to bypass Facebook\'s duplicate content detection. The visual frames remain the same, meaning your reach will remain low.\n*   **Trust Gap:** For products priced at 2,000–4,000 TK, trust is the primary barrier. A customer will not choose a 0-follower page over a 50k-follower page if the product and price are identical.\n*   **Value Proposition:** Your current strategy relies on the "rule of 7-12" (being the last person the customer sees), but this only works if the customer actually *sees* your content first.\n\n**Prioritized Actions**\n\n1.  **Pivot from "Seller" to "Home Stylist"**\n    *   **Action:** Stop reposting raw reels. Use a free editor (like CapCut) to add text overlays that provide "Styling Tips" (e.g., *"3 ways to place this on your dining table to look more elegant"* or *"How to organize your shelf for guests"*).\n    *   **Why:** This transforms the content from a "duplicate ad" into "educational value." It differentiates you from the supplier and gives the customer a reason to follow you for your expertise, not just the product.\n\n2.  **Implement a "First 100" Incentive**\n    *   **Action:** Since profit is not your current goal, create a specific "Founder\'s Offer" for the first 100 customers. This could be a small discount (e.g., 100–200 TK off) or a "Bundle Deal" (negotiate a small free gift from the supplier for bulk buys).\n    *   **Why:** You must give the customer a logical reason to buy from a small page instead of the big one. A lower price or a bonus is the only immediate lever you have.\n\n3.  **High-Intent Community Engagement**\n    *   **Action:** Stop generic group sharing. Join "Home Decor" or "Bangladeshi Women\'s Lifestyle" groups. Instead of posting links, find people asking for home improvement advice. Give them a helpful tip first, then suggest your product as the solution.\n    *   **Why:** Direct selling in groups is often flagged as spam. Providing value first builds the "respect" and "organization" image your target audience craves.\n\n**Assumptions, Risks, and Trade-offs**\n*   **Assumption:** You have the basic technical ability to add text overlays to videos.\n*   **Risk:** The supplier may refuse to lower the price or provide free gifts for your "First 100" offer.\n*   **Trade-off:** This approach requires significantly more time per post than simply changing the music, but it is the only way to gain organic reach without a budget.\n\n--------------------------------------------------\nTASK\n--------------------------------------------------\n\n1. Identify every actual question or information request in ADVISOR_REPLY.\n\n2. For each advisor question, search BOTH HUMAN_MESSAGE_1 and HUMAN_MESSAGE_2.\n\n3. If either human message explicitly answers the question, create a verified Q&A pair.\n\n4. The answer may appear before or after the advisor asked the question.\n\n5. Only use information explicitly present in the human messages.\n\n6. If no human message answers the question, do NOT create a Q&A pair.\n\n7. Extract user information that is not an answer to an advisor question as unprompted context.\n\n8. Preserve unprompted user context as closely as possible to the original wording.\n\n--------------------------------------------------\nIMPORTANT EXAMPLES\n--------------------------------------------------\n\nIf the user says:\n\n"hi"\n\nand the advisor asks:\n\n"What is your business?"\n\nthen:\n\n- qa_pairs must be empty\n- unprompted_context must be empty\n\nIf HUMAN_MESSAGE_1 says:\n\n"I sell handmade jewelry."\n\nand ADVISOR_REPLY later asks:\n\n"What is your business?"\n\nthen this is a verified Q&A pair even though the answer appeared before the question.\n\nIf ADVISOR_REPLY asks:\n\n"What is your budget?"\n\nand neither human message mentions a budget:\n\n- do not invent an answer\n- do not create a Q&A pair\n\n--------------------------------------------------\nANTI-HALLUCINATION RULES\n--------------------------------------------------\n\n- Never invent questions.\n- Never invent answers.\n- Never use information from older conversation history.\n- Never use information from ADVISOR_REPLY as a user fact.\n- Never assume the user agrees with the advisor.\n- Never turn advisor suggestions into facts.\n- Never reconstruct a conversation that is not provided.\n- When uncertain, do not guess.\n\n--------------------------------------------------\nOUTPUT\n--------------------------------------------------\n\nReturn ONLY the structured output required by the Pydantic output parser.\n\nThe output should be formatted as a JSON instance that conforms to the JSON schema below.\n\nAs an example, for the schema {"properties": {"foo": {"title": "Foo", "description": "a list of strings", "type": "array", "items": {"type": "string"}}}, "required": ["foo"]}\nthe object {"foo": ["bar", "baz"]} is a well-formatted instance of the schema. The object {"properties": {"foo": ["bar", "baz"]}} is not well-formatted.\n\nHere is the output schema:\n```\n{"$defs": {"QAPair": {"properties": {"question_asked": {"title": "Question Asked", "type": "string"}, "user_answer": {"title": "User Answer", "type": "string"}, "verification": {"enum": ["verified", "uncertain_match"], "title": "Verification", "type": "string"}}, "required": ["question_asked", "user_answer", "verification"], "title": "QAPair", "type": "object"}, "UnpromptedContext": {"properties": {"raw_text": {"title": "Raw Text", "type": "string"}, "topic_hint": {"title": "Topic Hint", "type": "string"}}, "required": ["raw_text", "topic_hint"], "title": "UnpromptedContext", "type": "object"}}, "properties": {"qa_pairs": {"items": {"$ref": "#/$defs/QAPair"}, "title": "Qa Pairs", "type": "array"}, "unprompted_context": {"items": {"$ref": "#/$defs/UnpromptedContext"}, "title": "Unprompted Context", "type": "array"}}}\n```\n',
                    }
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "text",
                            "text": '{\n  "qa_pairs": [],\n  "unprompted_context": [\n    {\n      "raw_text": "i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.",\n      "topic_hint": "pricing strategy and business goals"\n    },\n    {\n      "raw_text": "nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",\n      "topic_hint": "content creation and inventory status"\n    }\n  ]\n}',
                            "extras": {
                                "signature": "EnAKbgERTTIPmhNsc/WFelRf/e1eWxnCREj/ZJGBpOtqkq+UMwATD5DD6CgWRaIU0p7wEsHjBdKuzMvtGKxy7LnxG0ogooMKTARw7ZnwMTq1UJW1xmyHpvdjn5aSw+IeXGTdTkS3bcdYeYeOm0ArLv6s"
                            },
                        }
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Classifier LLM",
                "runtime": 5,
                "auto_runtime": 3,
                "problem_id": 6,
                "prompt": [
                    {
                        "role": "human",
                        "content": '\nYou are a response-state classifier.\n\nYour job is to determine whether the BUSINESS ADVISOR\'s latest\nresponse requires the USER to provide more information.\n\nReturn ONLY one of these two values:\n\nNEEDS_INPUT\n\nor\n\nDONE\n\n\nReturn NEEDS_INPUT when:\n\n- The advisor asks the user a question.\n- The advisor requests missing business information.\n- The advisor needs clarification before it can continue.\n- The advisor explicitly tells the user to provide something.\n\nReturn DONE when:\n\n- The advisor has enough information.\n- The advisor gives recommendations.\n- The advisor is explaining the analysis.\n- The advisor does not require another user response to continue.\n\nDo not explain your answer.\n\nAdvisor\'s latest response:\n\n**Business Summary**\nYou are reselling home decor showpieces to Bangladeshi women via Facebook, utilizing a supplier\'s content and fulfillment (COD). You are operating as a solo founder with zero budget and no existing network, relying entirely on the supplier\'s reels for marketing.\n\n**The Real Problem**\nYou are a "shadow" of your supplier. Because you are using the same videos and the same prices as a page with 50k followers, you have no **competitive advantage** and no **algorithmic advantage**. Facebook\'s algorithm suppresses duplicate content, and customers have no incentive to trust a new, small page over the established original source.\n\n**Reasoning**\n*   **Algorithm:** Changing background music is not enough to bypass Facebook\'s duplicate content detection. The visual frames remain the same, meaning your reach will remain low.\n*   **Trust Gap:** For products priced at 2,000–4,000 TK, trust is the primary barrier. A customer will not choose a 0-follower page over a 50k-follower page if the product and price are identical.\n*   **Value Proposition:** Your current strategy relies on the "rule of 7-12" (being the last person the customer sees), but this only works if the customer actually *sees* your content first.\n\n**Prioritized Actions**\n\n1.  **Pivot from "Seller" to "Home Stylist"**\n    *   **Action:** Stop reposting raw reels. Use a free editor (like CapCut) to add text overlays that provide "Styling Tips" (e.g., *"3 ways to place this on your dining table to look more elegant"* or *"How to organize your shelf for guests"*).\n    *   **Why:** This transforms the content from a "duplicate ad" into "educational value." It differentiates you from the supplier and gives the customer a reason to follow you for your expertise, not just the product.\n\n2.  **Implement a "First 100" Incentive**\n    *   **Action:** Since profit is not your current goal, create a specific "Founder\'s Offer" for the first 100 customers. This could be a small discount (e.g., 100–200 TK off) or a "Bundle Deal" (negotiate a small free gift from the supplier for bulk buys).\n    *   **Why:** You must give the customer a logical reason to buy from a small page instead of the big one. A lower price or a bonus is the only immediate lever you have.\n\n3.  **High-Intent Community Engagement**\n    *   **Action:** Stop generic group sharing. Join "Home Decor" or "Bangladeshi Women\'s Lifestyle" groups. Instead of posting links, find people asking for home improvement advice. Give them a helpful tip first, then suggest your product as the solution.\n    *   **Why:** Direct selling in groups is often flagged as spam. Providing value first builds the "respect" and "organization" image your target audience craves.\n\n**Assumptions, Risks, and Trade-offs**\n*   **Assumption:** You have the basic technical ability to add text overlays to videos.\n*   **Risk:** The supplier may refuse to lower the price or provide free gifts for your "First 100" offer.\n*   **Trade-off:** This approach requires significantly more time per post than simply changing the music, but it is the only way to gain organic reach without a budget.\n',
                    }
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "text",
                            "text": "DONE",
                            "extras": {
                                "signature": "EnAKbgERTTIPbvct89lTS+1BmC92oWBRjjTENzo/65kqDK34A53aK6NIy/Y4oKbneT2XbpQAoAcb4cmffKAPP7PeKOMZqa/oc8b7yLamb+Vs3ggld2pdHdJwhGJaC9B1J7Jrpw8f9DIFat7hPiudJUGD"
                            },
                        }
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Systematic Advice Converter LLM",
                "runtime": 5,
                "auto_runtime": 3,
                "problem_id": 6,
                "prompt": [
                    {
                        "role": "system",
                        "content": "\nConvert the advisor reply into the BusinessStrategyBrief schema.\n\nExtract only what is stated or clearly implied in the advisor reply.\nNever invent facts.\n",
                    },
                    {
                        "role": "human",
                        "content": '**Business Summary**\nYou are reselling home decor showpieces to Bangladeshi women via Facebook, utilizing a supplier\'s content and fulfillment (COD). You are operating as a solo founder with zero budget and no existing network, relying entirely on the supplier\'s reels for marketing.\n\n**The Real Problem**\nYou are a "shadow" of your supplier. Because you are using the same videos and the same prices as a page with 50k followers, you have no **competitive advantage** and no **algorithmic advantage**. Facebook\'s algorithm suppresses duplicate content, and customers have no incentive to trust a new, small page over the established original source.\n\n**Reasoning**\n*   **Algorithm:** Changing background music is not enough to bypass Facebook\'s duplicate content detection. The visual frames remain the same, meaning your reach will remain low.\n*   **Trust Gap:** For products priced at 2,000–4,000 TK, trust is the primary barrier. A customer will not choose a 0-follower page over a 50k-follower page if the product and price are identical.\n*   **Value Proposition:** Your current strategy relies on the "rule of 7-12" (being the last person the customer sees), but this only works if the customer actually *sees* your content first.\n\n**Prioritized Actions**\n\n1.  **Pivot from "Seller" to "Home Stylist"**\n    *   **Action:** Stop reposting raw reels. Use a free editor (like CapCut) to add text overlays that provide "Styling Tips" (e.g., *"3 ways to place this on your dining table to look more elegant"* or *"How to organize your shelf for guests"*).\n    *   **Why:** This transforms the content from a "duplicate ad" into "educational value." It differentiates you from the supplier and gives the customer a reason to follow you for your expertise, not just the product.\n\n2.  **Implement a "First 100" Incentive**\n    *   **Action:** Since profit is not your current goal, create a specific "Founder\'s Offer" for the first 100 customers. This could be a small discount (e.g., 100–200 TK off) or a "Bundle Deal" (negotiate a small free gift from the supplier for bulk buys).\n    *   **Why:** You must give the customer a logical reason to buy from a small page instead of the big one. A lower price or a bonus is the only immediate lever you have.\n\n3.  **High-Intent Community Engagement**\n    *   **Action:** Stop generic group sharing. Join "Home Decor" or "Bangladeshi Women\'s Lifestyle" groups. Instead of posting links, find people asking for home improvement advice. Give them a helpful tip first, then suggest your product as the solution.\n    *   **Why:** Direct selling in groups is often flagged as spam. Providing value first builds the "respect" and "organization" image your target audience craves.\n\n**Assumptions, Risks, and Trade-offs**\n*   **Assumption:** You have the basic technical ability to add text overlays to videos.\n*   **Risk:** The supplier may refuse to lower the price or provide free gifts for your "First 100" offer.\n*   **Trade-off:** This approach requires significantly more time per post than simply changing the music, but it is the only way to gain organic reach without a budget.',
                    },
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "text",
                            "text": '{\n  "title": "From Reseller to Home Stylist: Building Trust and Reach",\n  "business_summary": {\n    "business_model": "Reselling home decor showpieces via Facebook using supplier content and COD fulfillment.",\n    "product_category": "Home decor showpieces",\n    "price_range_bdt": {\n      "min": 2000,\n      "max": 4000\n    },\n    "target_customer": "Bangladeshi women",\n    "market": "Bangladesh",\n    "fulfillment": "Supplier handles sourcing, inventory, and delivery (COD).",\n    "constraints": [\n      "Solo founder",\n      "Zero budget",\n      "No existing network",\n      "Reliance on supplier\'s content"\n    ]\n  },\n  "real_problem": {\n    "surface_problem": "Low reach and sales due to reliance on supplier\'s content.",\n    "actual_problem": "Lack of competitive and algorithmic advantage due to duplicate content and a trust gap compared to the established supplier.",\n    "supporting_context": [\n      "Facebook algorithm suppresses duplicate content.",\n      "Customers prefer established pages with 50k followers over new pages.",\n      "Changing background music is insufficient to bypass duplicate content detection."\n    ]\n  },\n  "strategy_reasoning": {\n    "core_constraint": "Zero budget and reliance on supplier content.",\n    "approach": "Shift from being a generic reseller to a value-adding \'Home Stylist\' to build trust and bypass algorithmic suppression.",\n    "channels": [\n      "Facebook Reels",\n      "Facebook Groups"\n    ]\n  },\n  "prioritized_action_plan": [\n    {\n      "priority": 1,\n      "title": "Pivot from Seller to Home Stylist",\n      "action": "Transform raw supplier reels into educational content using text overlays.",\n      "execution": [\n        "Use a free editor like CapCut.",\n        "Add text overlays providing styling tips.",\n        "Create content that offers educational value rather than just product ads."\n      ]\n    },\n    {\n      "priority": 2,\n      "title": "Implement a First 100 Incentive",\n      "action": "Create a \'Founder\'s Offer\' to provide a logical reason for customers to choose a new page.",\n      "execution": [\n        "Offer a small discount of 100–200 TK for the first 100 customers.",\n        "Negotiate bundle deals or small free gifts with the supplier."\n      ]\n    },\n    {\n      "priority": 3,\n      "title": "High-Intent Community Engagement",\n      "action": "Engage in niche Facebook groups by providing value before selling.",\n      "execution": [\n        "Join Home Decor and Bangladeshi Women\'s Lifestyle groups.",\n        "Provide helpful advice to users asking for home improvement tips.",\n        "Suggest products only as a solution after establishing credibility."\n      ]\n    }\n  ],\n  "assumptions_risks_tradeoffs": {\n    "assumptions": [\n      "The founder has the basic technical ability to add text overlays to videos."\n    ],\n    "risks": [\n      {\n        "risk": "Supplier may refuse to lower prices or provide free gifts for the \'First 100\' offer.",\n        "impact": "Limits the ability to offer competitive pricing or incentives to build the initial customer base."\n      }\n    ],\n    "tradeoffs": [\n      "This approach requires significantly more time per post than simply changing music, but it is necessary for organic reach without a budget."\n    ]\n  }\n}',
                            "extras": {
                                "signature": "EnAKbgERTTIPKYU7P+10qLCGqXbW5RVbCrrk5uKdLx63LJuABrE+GENYFAdoXDPvchU34GASiHmCb6YfDdGks0Pfyy8gOW9zrzMtdR4J/H3KywgGYEe7GI7J8xY8sAsSyytjpFG+T8oLeRrruMfPii9j"
                            },
                        }
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Reality-Check Critic #11",
                "runtime": 5,
                "auto_runtime": 3,
                "problem_id": 6,
                "prompt": {
                    "verified_context": [
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i want 100 first customers in my business",
                                    "topic_hint": "business goal",
                                }
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i want 100 first customers in my business",
                                    "topic_hint": "business goal",
                                },
                                {
                                    "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",
                                    "topic_hint": "product and target audience",
                                },
                                {
                                    "raw_text": "my product avg price point is 2000-4000 tk. and i already told you about typical buyers.",
                                    "topic_hint": "pricing",
                                },
                                {
                                    "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                                    "topic_hint": "business model and operations",
                                },
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",
                                    "topic_hint": "business description and target audience",
                                },
                                {
                                    "raw_text": "my product avg price point is 2000-4000 tk.",
                                    "topic_hint": "pricing",
                                },
                                {
                                    "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team.",
                                    "topic_hint": "business resources and budget",
                                },
                                {
                                    "raw_text": "my products are coming from a supplier who is already successfully selling his this iteams on facebook... i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                                    "topic_hint": "business model and supplier agreement",
                                },
                                {
                                    "raw_text": "in ocean if a big boat come to catch fish that not mean others boat will not get any fishes... same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.",
                                    "topic_hint": "market analysis and customer behavior",
                                },
                                {
                                    "raw_text": "just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",
                                    "topic_hint": "distribution plan",
                                },
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.",
                                    "topic_hint": "pricing strategy and business goals",
                                },
                                {
                                    "raw_text": "nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",
                                    "topic_hint": "content creation and inventory status",
                                },
                            ],
                        },
                    ],
                    "advisor_strategy": {
                        "title": "From Reseller to Home Stylist: Building Trust and Reach",
                        "business_summary": {
                            "business_model": "Reselling home decor showpieces via Facebook using supplier content and COD fulfillment.",
                            "product_category": "Home decor showpieces",
                            "price_range_bdt": {"min": 2000, "max": 4000},
                            "target_customer": "Bangladeshi women",
                            "market": "Bangladesh",
                            "fulfillment": "Supplier handles sourcing, inventory, and delivery (COD).",
                            "constraints": [
                                "Solo founder",
                                "Zero budget",
                                "No existing network",
                                "Reliance on supplier's content",
                            ],
                        },
                        "real_problem": {
                            "surface_problem": "Low reach and sales due to reliance on supplier's content.",
                            "actual_problem": "Lack of competitive and algorithmic advantage due to duplicate content and a trust gap compared to the established supplier.",
                            "supporting_context": [
                                "Facebook algorithm suppresses duplicate content.",
                                "Customers prefer established pages with 50k followers over new pages.",
                                "Changing background music is insufficient to bypass duplicate content detection.",
                            ],
                        },
                        "strategy_reasoning": {
                            "core_constraint": "Zero budget and reliance on supplier content.",
                            "approach": "Shift from being a generic reseller to a value-adding 'Home Stylist' to build trust and bypass algorithmic suppression.",
                            "channels": ["Facebook Reels", "Facebook Groups"],
                        },
                        "assumptions_risks_tradeoffs": {
                            "assumptions": [
                                "The founder has the basic technical ability to add text overlays to videos."
                            ],
                            "risks": [
                                {
                                    "risk": "Supplier may refuse to lower prices or provide free gifts for the 'First 100' offer.",
                                    "impact": "Limits the ability to offer competitive pricing or incentives to build the initial customer base.",
                                    "mitigation": 0,
                                }
                            ],
                            "tradeoffs": [
                                "This approach requires significantly more time per post than simply changing music, but it is necessary for organic reach without a budget."
                            ],
                        },
                        "prioritized_action_plan": [
                            {
                                "priority": 1,
                                "title": "Pivot from Seller to Home Stylist",
                                "action": "Transform raw supplier reels into educational content using text overlays.",
                                "execution": [
                                    "Use a free editor like CapCut.",
                                    "Add text overlays providing styling tips.",
                                    "Create content that offers educational value rather than just product ads.",
                                ],
                            }
                        ],
                    },
                    "target_action": {
                        "priority": 1,
                        "title": "Pivot from Seller to Home Stylist",
                        "action": "Transform raw supplier reels into educational content using text overlays.",
                        "execution": [
                            "Use a free editor like CapCut.",
                            "Add text overlays providing styling tips.",
                            "Create content that offers educational value rather than just product ads.",
                        ],
                    },
                },
                "output": {
                    "action_title": "Pivot from Seller to Home Stylist",
                    "claim": "Transforming supplier reels into educational content with text overlays will increase organic reach and build trust with potential customers.",
                    "mechanism": "By adding educational value through text overlays, the content becomes unique enough to bypass duplicate content suppression and establishes the seller as a helpful authority, thereby increasing trust and engagement compared to simply reposting raw supplier videos.",
                    "load_bearing_assumptions": [
                        {
                            "assumption": "Facebook's algorithm will prioritize or favor edited/repurposed content with text overlays over the original supplier content.",
                            "classification": "ASSUMPTION",
                            "evidence": "This assumes specific knowledge of Facebook's proprietary content ranking and duplicate content detection mechanisms, which is not provided in the context.",
                        },
                        {
                            "assumption": "The target audience (Bangladeshi women) will perceive educational styling tips as more valuable than the raw product showcase.",
                            "classification": "ASSUMPTION",
                            "evidence": "This is a behavioral assumption about the target audience's preferences that is not confirmed by the provided context.",
                        },
                        {
                            "assumption": "The founder has the time and technical capability to consistently edit videos using tools like CapCut.",
                            "classification": "ASSUMPTION",
                            "evidence": "The context states the founder is a solo seller with no team, but does not confirm their ability or capacity to perform video editing tasks.",
                        },
                    ],
                    "structural_flags": [],
                    "settled_as_fact_violation": 0,
                    "verdict": "CONDITIONAL",
                    "verdict_reason": "The mechanism relies on unverified assumptions regarding Facebook's algorithm behavior and the target audience's preference for educational content over raw product showcases. While the strategy addresses the duplicate content issue, its effectiveness depends on the founder's ability to execute the editing and the audience's response to the new content format.",
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Reality-Check Critic #12",
                "runtime": 5,
                "auto_runtime": 3,
                "problem_id": 6,
                "prompt": {
                    "verified_context": [
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i want 100 first customers in my business",
                                    "topic_hint": "business goal",
                                }
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i want 100 first customers in my business",
                                    "topic_hint": "business goal",
                                },
                                {
                                    "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",
                                    "topic_hint": "product and target audience",
                                },
                                {
                                    "raw_text": "my product avg price point is 2000-4000 tk. and i already told you about typical buyers.",
                                    "topic_hint": "pricing",
                                },
                                {
                                    "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                                    "topic_hint": "business model and operations",
                                },
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",
                                    "topic_hint": "business description and target audience",
                                },
                                {
                                    "raw_text": "my product avg price point is 2000-4000 tk.",
                                    "topic_hint": "pricing",
                                },
                                {
                                    "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team.",
                                    "topic_hint": "business resources and budget",
                                },
                                {
                                    "raw_text": "my products are coming from a supplier who is already successfully selling his this iteams on facebook... i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                                    "topic_hint": "business model and supplier agreement",
                                },
                                {
                                    "raw_text": "in ocean if a big boat come to catch fish that not mean others boat will not get any fishes... same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.",
                                    "topic_hint": "market analysis and customer behavior",
                                },
                                {
                                    "raw_text": "just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",
                                    "topic_hint": "distribution plan",
                                },
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.",
                                    "topic_hint": "pricing strategy and business goals",
                                },
                                {
                                    "raw_text": "nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",
                                    "topic_hint": "content creation and inventory status",
                                },
                            ],
                        },
                    ],
                    "advisor_strategy": {
                        "title": "From Reseller to Home Stylist: Building Trust and Reach",
                        "business_summary": {
                            "business_model": "Reselling home decor showpieces via Facebook using supplier content and COD fulfillment.",
                            "product_category": "Home decor showpieces",
                            "price_range_bdt": {"min": 2000, "max": 4000},
                            "target_customer": "Bangladeshi women",
                            "market": "Bangladesh",
                            "fulfillment": "Supplier handles sourcing, inventory, and delivery (COD).",
                            "constraints": [
                                "Solo founder",
                                "Zero budget",
                                "No existing network",
                                "Reliance on supplier's content",
                            ],
                        },
                        "real_problem": {
                            "surface_problem": "Low reach and sales due to reliance on supplier's content.",
                            "actual_problem": "Lack of competitive and algorithmic advantage due to duplicate content and a trust gap compared to the established supplier.",
                            "supporting_context": [
                                "Facebook algorithm suppresses duplicate content.",
                                "Customers prefer established pages with 50k followers over new pages.",
                                "Changing background music is insufficient to bypass duplicate content detection.",
                            ],
                        },
                        "strategy_reasoning": {
                            "core_constraint": "Zero budget and reliance on supplier content.",
                            "approach": "Shift from being a generic reseller to a value-adding 'Home Stylist' to build trust and bypass algorithmic suppression.",
                            "channels": ["Facebook Reels", "Facebook Groups"],
                        },
                        "assumptions_risks_tradeoffs": {
                            "assumptions": [
                                "The founder has the basic technical ability to add text overlays to videos."
                            ],
                            "risks": [
                                {
                                    "risk": "Supplier may refuse to lower prices or provide free gifts for the 'First 100' offer.",
                                    "impact": "Limits the ability to offer competitive pricing or incentives to build the initial customer base.",
                                    "mitigation": 0,
                                }
                            ],
                            "tradeoffs": [
                                "This approach requires significantly more time per post than simply changing music, but it is necessary for organic reach without a budget."
                            ],
                        },
                        "prioritized_action_plan": [
                            {
                                "priority": 2,
                                "title": "Implement a First 100 Incentive",
                                "action": "Create a 'Founder's Offer' to provide a logical reason for customers to choose a new page.",
                                "execution": [
                                    "Offer a small discount of 100–200 TK for the first 100 customers.",
                                    "Negotiate bundle deals or small free gifts with the supplier.",
                                ],
                            }
                        ],
                    },
                    "target_action": {
                        "priority": 2,
                        "title": "Implement a First 100 Incentive",
                        "action": "Create a 'Founder's Offer' to provide a logical reason for customers to choose a new page.",
                        "execution": [
                            "Offer a small discount of 100–200 TK for the first 100 customers.",
                            "Negotiate bundle deals or small free gifts with the supplier.",
                        ],
                    },
                },
                "output": {
                    "action_title": "Implement a First 100 Incentive",
                    "claim": "Offering a 'Founder's Offer' discount or bundle will incentivize customers to choose a new, unproven page over established competitors.",
                    "mechanism": "By providing a financial incentive (discount or gift), the seller creates a unique value proposition that differentiates their new page from established competitors, overcoming the initial trust deficit and encouraging early sales.",
                    "load_bearing_assumptions": [
                        {
                            "assumption": "The supplier is willing to absorb the cost of the 100-200 TK discount or provide free gifts without reducing the seller's margin to zero.",
                            "classification": "ASSUMPTION",
                            "evidence": "The context states the supplier handles packaging and shipping and the seller has 0 budget; any discount must come from the supplier's margin or the seller's already thin reseller margin.",
                        },
                        {
                            "assumption": "Customers who compare prices across 5+ sellers will prioritize a 100-200 TK discount over the trust and social proof of an established 50k-follower page.",
                            "classification": "ASSUMPTION",
                            "evidence": "The context notes customers are price-sensitive but also that they require 7-12 touchpoints and trust to convert.",
                        },
                    ],
                    "structural_flags": [
                        {
                            "flaw_type": "resource_mismatch",
                            "explanation": "The business model relies on the supplier's pricing and fulfillment. If the supplier is already selling these items successfully, they may not see the value in discounting their products for a new, unproven reseller, especially when the reseller has no leverage.",
                        }
                    ],
                    "settled_as_fact_violation": 0,
                    "verdict": "CONDITIONAL",
                    "verdict_reason": "The mechanism relies on the supplier's cooperation to fund the incentive, which is a significant risk given the seller's lack of leverage and zero-budget constraint. Additionally, it is unverified whether a small discount is sufficient to overcome the trust gap inherent in a new page compared to an established competitor.",
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Reality-Check Critic #13",
                "runtime": 5,
                "auto_runtime": 3,
                "problem_id": 6,
                "prompt": {
                    "verified_context": [
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i want 100 first customers in my business",
                                    "topic_hint": "business goal",
                                }
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i want 100 first customers in my business",
                                    "topic_hint": "business goal",
                                },
                                {
                                    "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",
                                    "topic_hint": "product and target audience",
                                },
                                {
                                    "raw_text": "my product avg price point is 2000-4000 tk. and i already told you about typical buyers.",
                                    "topic_hint": "pricing",
                                },
                                {
                                    "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                                    "topic_hint": "business model and operations",
                                },
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",
                                    "topic_hint": "business description and target audience",
                                },
                                {
                                    "raw_text": "my product avg price point is 2000-4000 tk.",
                                    "topic_hint": "pricing",
                                },
                                {
                                    "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team.",
                                    "topic_hint": "business resources and budget",
                                },
                                {
                                    "raw_text": "my products are coming from a supplier who is already successfully selling his this iteams on facebook... i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                                    "topic_hint": "business model and supplier agreement",
                                },
                                {
                                    "raw_text": "in ocean if a big boat come to catch fish that not mean others boat will not get any fishes... same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.",
                                    "topic_hint": "market analysis and customer behavior",
                                },
                                {
                                    "raw_text": "just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",
                                    "topic_hint": "distribution plan",
                                },
                            ],
                        },
                        {
                            "qa_pairs": [],
                            "unprompted_context": [
                                {
                                    "raw_text": "i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.",
                                    "topic_hint": "pricing strategy and business goals",
                                },
                                {
                                    "raw_text": "nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",
                                    "topic_hint": "content creation and inventory status",
                                },
                            ],
                        },
                    ],
                    "advisor_strategy": {
                        "title": "From Reseller to Home Stylist: Building Trust and Reach",
                        "business_summary": {
                            "business_model": "Reselling home decor showpieces via Facebook using supplier content and COD fulfillment.",
                            "product_category": "Home decor showpieces",
                            "price_range_bdt": {"min": 2000, "max": 4000},
                            "target_customer": "Bangladeshi women",
                            "market": "Bangladesh",
                            "fulfillment": "Supplier handles sourcing, inventory, and delivery (COD).",
                            "constraints": [
                                "Solo founder",
                                "Zero budget",
                                "No existing network",
                                "Reliance on supplier's content",
                            ],
                        },
                        "real_problem": {
                            "surface_problem": "Low reach and sales due to reliance on supplier's content.",
                            "actual_problem": "Lack of competitive and algorithmic advantage due to duplicate content and a trust gap compared to the established supplier.",
                            "supporting_context": [
                                "Facebook algorithm suppresses duplicate content.",
                                "Customers prefer established pages with 50k followers over new pages.",
                                "Changing background music is insufficient to bypass duplicate content detection.",
                            ],
                        },
                        "strategy_reasoning": {
                            "core_constraint": "Zero budget and reliance on supplier content.",
                            "approach": "Shift from being a generic reseller to a value-adding 'Home Stylist' to build trust and bypass algorithmic suppression.",
                            "channels": ["Facebook Reels", "Facebook Groups"],
                        },
                        "assumptions_risks_tradeoffs": {
                            "assumptions": [
                                "The founder has the basic technical ability to add text overlays to videos."
                            ],
                            "risks": [
                                {
                                    "risk": "Supplier may refuse to lower prices or provide free gifts for the 'First 100' offer.",
                                    "impact": "Limits the ability to offer competitive pricing or incentives to build the initial customer base.",
                                    "mitigation": 0,
                                }
                            ],
                            "tradeoffs": [
                                "This approach requires significantly more time per post than simply changing music, but it is necessary for organic reach without a budget."
                            ],
                        },
                        "prioritized_action_plan": [
                            {
                                "priority": 3,
                                "title": "High-Intent Community Engagement",
                                "action": "Engage in niche Facebook groups by providing value before selling.",
                                "execution": [
                                    "Join Home Decor and Bangladeshi Women's Lifestyle groups.",
                                    "Provide helpful advice to users asking for home improvement tips.",
                                    "Suggest products only as a solution after establishing credibility.",
                                ],
                            }
                        ],
                    },
                    "target_action": {
                        "priority": 3,
                        "title": "High-Intent Community Engagement",
                        "action": "Engage in niche Facebook groups by providing value before selling.",
                        "execution": [
                            "Join Home Decor and Bangladeshi Women's Lifestyle groups.",
                            "Provide helpful advice to users asking for home improvement tips.",
                            "Suggest products only as a solution after establishing credibility.",
                        ],
                    },
                },
                "output": {
                    "action_title": "High-Intent Community Engagement",
                    "claim": "Engage in niche Facebook groups by providing value before selling to build credibility and acquire customers.",
                    "mechanism": "By establishing credibility through helpful, non-promotional advice, the founder builds trust with potential customers, making them more likely to purchase when the founder eventually suggests their products as a solution.",
                    "load_bearing_assumptions": [
                        {
                            "assumption": "The founder has the time and expertise to provide valuable, credible home decor advice that differentiates them from other group members.",
                            "classification": "ASSUMPTION",
                            "evidence": "The context states the founder is a solo seller with no team and no budget, but does not confirm they possess the specific interior design knowledge required to be seen as an expert/advisor in these groups.",
                        },
                        {
                            "assumption": "Facebook group administrators will allow promotional activity or 'soft selling' after the founder provides advice.",
                            "classification": "ASSUMPTION",
                            "evidence": "Many Facebook groups have strict rules against self-promotion or commercial links, which could lead to the founder being banned or posts being deleted.",
                        },
                        {
                            "assumption": "The target audience (Bangladeshi women) actively seeks and trusts advice from strangers in these specific Facebook groups.",
                            "classification": "ASSUMPTION",
                            "evidence": "This is a behavioral assumption about the target market's interaction patterns within online communities.",
                        },
                    ],
                    "structural_flags": [
                        {
                            "flaw_type": "relevance_mismatch",
                            "explanation": "The context explicitly states: 'i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.' The suggestion ignores this direct evidence of failure in this channel.",
                        }
                    ],
                    "settled_as_fact_violation": 0,
                    "verdict": "FAIL",
                    "verdict_reason": "The suggestion directly contradicts the founder's stated experience that Facebook group engagement has already failed to produce results. Furthermore, it assumes the founder has the specialized expertise to provide 'value' that would actually build credibility, which is not supported by the context.",
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Problem Explainer",
                "runtime": 5,
                "auto_runtime": 3,
                "problem_id": 6,
                "prompt": [
                    {
                        "role": "system",
                        "content": "\nYou are a Problem Explainer.\n\nYour job is to examine a conditional critic result and determine\nwhether it represents a DISTINCT NEW PROBLEM that should be sent\nback to the advisor as a child problem.\n\nYou do NOT solve the problem.\n\nYou do NOT improve the advisor's strategy.\n\nYou do NOT invent facts.\n\n============================================================\nINPUTS\n============================================================\n\nYou receive:\n\n1. CURRENT_PROBLEM\n   The problem currently being solved.\n\n2. CONDITIONAL_CRITIC\n   The critic's analysis of one action from the advisor's strategy.\n\n3. VERIFIED_FACTS\n   Facts already verified about the business.\n\n============================================================\nNEW PROBLEM TEST\n============================================================\n\nCreate NEW_PROBLEM only when the critic reveals a distinct issue\nthat requires its own reasoning and solution.\n\nA conditional critic does NOT automatically create a new problem.\n\nDo NOT create a new problem when the critic is only saying:\n\n- more evidence is needed\n- an assumption should be checked\n- a minor caveat exists\n- an execution detail is uncertain\n- the action may work under certain conditions\n\nCreate NEW_PROBLEM when the critic reveals something like:\n\n- the strategy depends on a real unresolved business constraint\n- the recommendation requires solving another substantive issue first\n- a missing capability/resource must be established before the\n  original strategy can work\n- the critic exposes a distinct obstacle that deserves its own\n  advisor-level solution\n\n============================================================\nPROBLEM FORMULATION\n============================================================\n\nWhen NEW_PROBLEM:\n\n- State the problem clearly.\n- Make it actionable for the advisor.\n- Preserve the critic's meaning.\n- Use verified facts as context.\n- Do not invent causes, facts, or solutions.\n- Do not include the solution in the problem statement.\n\nThe new problem will later be pushed on top of the current\nproblem stack and sent to the advisor.\n\n============================================================\nPARENT RELATIONSHIP\n============================================================\n\nThe new problem must be a CHILD of CURRENT_PROBLEM.\n\nIt should address the issue raised by the critic, not replace\nthe parent problem.\n\n============================================================\nOUTPUT\n============================================================\n\nReturn only the structured result defined by the output schema.\n",
                    },
                    {
                        "role": "human",
                        "content": '\nCURRENT_PROBLEM:\n\n{\n  "problem_id": 6,\n  "parent_problem_id": 5,\n  "depth": 3,\n  "problem": "Determine the technical and legal feasibility of modifying supplier-provided video content to bypass Facebook\'s duplicate content algorithm and ensure compliance with the supplier agreement.",\n  "runtime": 5,\n  "auto_runtime": 3,\n  "agent": "Advisor",\n  "status": "ACTIVE",\n  "solution": 0,\n  "source_critic_id": 8\n}\n\n\nCONDITIONAL_CRITIC:\n\n{\n  "action_title": "Pivot from Seller to Home Stylist",\n  "claim": "Transforming supplier reels into educational content with text overlays will increase organic reach and build trust with potential customers.",\n  "mechanism": "By adding educational value through text overlays, the content becomes unique enough to bypass duplicate content suppression and establishes the seller as a helpful authority, thereby increasing trust and engagement compared to simply reposting raw supplier videos.",\n  "load_bearing_assumptions": [\n    {\n      "assumption": "Facebook\'s algorithm will prioritize or favor edited/repurposed content with text overlays over the original supplier content.",\n      "classification": "ASSUMPTION",\n      "evidence": "This assumes specific knowledge of Facebook\'s proprietary content ranking and duplicate content detection mechanisms, which is not provided in the context."\n    },\n    {\n      "assumption": "The target audience (Bangladeshi women) will perceive educational styling tips as more valuable than the raw product showcase.",\n      "classification": "ASSUMPTION",\n      "evidence": "This is a behavioral assumption about the target audience\'s preferences that is not confirmed by the provided context."\n    },\n    {\n      "assumption": "The founder has the time and technical capability to consistently edit videos using tools like CapCut.",\n      "classification": "ASSUMPTION",\n      "evidence": "The context states the founder is a solo seller with no team, but does not confirm their ability or capacity to perform video editing tasks."\n    }\n  ],\n  "structural_flags": [],\n  "settled_as_fact_violation": 0,\n  "verdict": "CONDITIONAL",\n  "verdict_reason": "The mechanism relies on unverified assumptions regarding Facebook\'s algorithm behavior and the target audience\'s preference for educational content over raw product showcases. While the strategy addresses the duplicate content issue, its effectiveness depends on the founder\'s ability to execute the editing and the audience\'s response to the new content format."\n}\n\n\nVERIFIED_FACTS:\n\n[\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i want 100 first customers in my business",\n        "topic_hint": "business goal"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i want 100 first customers in my business",\n        "topic_hint": "business goal"\n      },\n      {\n        "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman\'s, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",\n        "topic_hint": "product and target audience"\n      },\n      {\n        "raw_text": "my product avg price point is 2000-4000 tk. and i already told you about typical buyers.",\n        "topic_hint": "pricing"\n      },\n      {\n        "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",\n        "topic_hint": "business model and operations"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman\'s, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",\n        "topic_hint": "business description and target audience"\n      },\n      {\n        "raw_text": "my product avg price point is 2000-4000 tk.",\n        "topic_hint": "pricing"\n      },\n      {\n        "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team.",\n        "topic_hint": "business resources and budget"\n      },\n      {\n        "raw_text": "my products are coming from a supplier who is already successfully selling his this iteams on facebook... i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",\n        "topic_hint": "business model and supplier agreement"\n      },\n      {\n        "raw_text": "in ocean if a big boat come to catch fish that not mean others boat will not get any fishes... same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.",\n        "topic_hint": "market analysis and customer behavior"\n      },\n      {\n        "raw_text": "just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",\n        "topic_hint": "distribution plan"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.",\n        "topic_hint": "pricing strategy and business goals"\n      },\n      {\n        "raw_text": "nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",\n        "topic_hint": "content creation and inventory status"\n      }\n    ]\n  }\n]\n',
                    },
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "text",
                            "text": '{\n  "classification": "NEW_PROBLEM",\n  "problem": "Assess the founder\'s operational capacity and technical proficiency to consistently produce edited video content, given the constraints of being a solo seller with no budget and no physical access to the products.",\n  "reason": "The proposed strategy of editing supplier videos to bypass algorithm restrictions is contingent on the founder\'s ability to perform these tasks. Since the founder is a solo seller with no team and no prior mention of video editing skills, this is a foundational capability gap that must be addressed before the strategy can be considered viable."\n}',
                            "extras": {
                                "signature": "EnAKbgERTTIPXHU7Mo2OVa/VZ1KjsX3N9xa8Z+NHNDc+vMj1IzyzXCTqsUzpg8KxZvg/FLNUDDjrSEu3It4P+bMOpsaebA9IQrs1q15zn7pKYHd+7fasPm6hBq3RyxGqVSmI6tW8utY0jmyQ7ECSL5m+"
                            },
                        }
                    ],
                },
                "status": "SUCCESS",
            },
            {
                "agent": "Problem Explainer",
                "runtime": 5,
                "auto_runtime": 3,
                "problem_id": 6,
                "prompt": [
                    {
                        "role": "system",
                        "content": "\nYou are a Problem Explainer.\n\nYour job is to examine a conditional critic result and determine\nwhether it represents a DISTINCT NEW PROBLEM that should be sent\nback to the advisor as a child problem.\n\nYou do NOT solve the problem.\n\nYou do NOT improve the advisor's strategy.\n\nYou do NOT invent facts.\n\n============================================================\nINPUTS\n============================================================\n\nYou receive:\n\n1. CURRENT_PROBLEM\n   The problem currently being solved.\n\n2. CONDITIONAL_CRITIC\n   The critic's analysis of one action from the advisor's strategy.\n\n3. VERIFIED_FACTS\n   Facts already verified about the business.\n\n============================================================\nNEW PROBLEM TEST\n============================================================\n\nCreate NEW_PROBLEM only when the critic reveals a distinct issue\nthat requires its own reasoning and solution.\n\nA conditional critic does NOT automatically create a new problem.\n\nDo NOT create a new problem when the critic is only saying:\n\n- more evidence is needed\n- an assumption should be checked\n- a minor caveat exists\n- an execution detail is uncertain\n- the action may work under certain conditions\n\nCreate NEW_PROBLEM when the critic reveals something like:\n\n- the strategy depends on a real unresolved business constraint\n- the recommendation requires solving another substantive issue first\n- a missing capability/resource must be established before the\n  original strategy can work\n- the critic exposes a distinct obstacle that deserves its own\n  advisor-level solution\n\n============================================================\nPROBLEM FORMULATION\n============================================================\n\nWhen NEW_PROBLEM:\n\n- State the problem clearly.\n- Make it actionable for the advisor.\n- Preserve the critic's meaning.\n- Use verified facts as context.\n- Do not invent causes, facts, or solutions.\n- Do not include the solution in the problem statement.\n\nThe new problem will later be pushed on top of the current\nproblem stack and sent to the advisor.\n\n============================================================\nPARENT RELATIONSHIP\n============================================================\n\nThe new problem must be a CHILD of CURRENT_PROBLEM.\n\nIt should address the issue raised by the critic, not replace\nthe parent problem.\n\n============================================================\nOUTPUT\n============================================================\n\nReturn only the structured result defined by the output schema.\n",
                    },
                    {
                        "role": "human",
                        "content": '\nCURRENT_PROBLEM:\n\n{\n  "problem_id": 6,\n  "parent_problem_id": 5,\n  "depth": 3,\n  "problem": "Determine the technical and legal feasibility of modifying supplier-provided video content to bypass Facebook\'s duplicate content algorithm and ensure compliance with the supplier agreement.",\n  "runtime": 5,\n  "auto_runtime": 3,\n  "agent": "Advisor",\n  "status": "ACTIVE",\n  "solution": 0,\n  "source_critic_id": 8\n}\n\n\nCONDITIONAL_CRITIC:\n\n{\n  "action_title": "Implement a First 100 Incentive",\n  "claim": "Offering a \'Founder\'s Offer\' discount or bundle will incentivize customers to choose a new, unproven page over established competitors.",\n  "mechanism": "By providing a financial incentive (discount or gift), the seller creates a unique value proposition that differentiates their new page from established competitors, overcoming the initial trust deficit and encouraging early sales.",\n  "load_bearing_assumptions": [\n    {\n      "assumption": "The supplier is willing to absorb the cost of the 100-200 TK discount or provide free gifts without reducing the seller\'s margin to zero.",\n      "classification": "ASSUMPTION",\n      "evidence": "The context states the supplier handles packaging and shipping and the seller has 0 budget; any discount must come from the supplier\'s margin or the seller\'s already thin reseller margin."\n    },\n    {\n      "assumption": "Customers who compare prices across 5+ sellers will prioritize a 100-200 TK discount over the trust and social proof of an established 50k-follower page.",\n      "classification": "ASSUMPTION",\n      "evidence": "The context notes customers are price-sensitive but also that they require 7-12 touchpoints and trust to convert."\n    }\n  ],\n  "structural_flags": [\n    {\n      "flaw_type": "resource_mismatch",\n      "explanation": "The business model relies on the supplier\'s pricing and fulfillment. If the supplier is already selling these items successfully, they may not see the value in discounting their products for a new, unproven reseller, especially when the reseller has no leverage."\n    }\n  ],\n  "settled_as_fact_violation": 0,\n  "verdict": "CONDITIONAL",\n  "verdict_reason": "The mechanism relies on the supplier\'s cooperation to fund the incentive, which is a significant risk given the seller\'s lack of leverage and zero-budget constraint. Additionally, it is unverified whether a small discount is sufficient to overcome the trust gap inherent in a new page compared to an established competitor."\n}\n\n\nVERIFIED_FACTS:\n\n[\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i want 100 first customers in my business",\n        "topic_hint": "business goal"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i want 100 first customers in my business",\n        "topic_hint": "business goal"\n      },\n      {\n        "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman\'s, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",\n        "topic_hint": "product and target audience"\n      },\n      {\n        "raw_text": "my product avg price point is 2000-4000 tk. and i already told you about typical buyers.",\n        "topic_hint": "pricing"\n      },\n      {\n        "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",\n        "topic_hint": "business model and operations"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman\'s, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",\n        "topic_hint": "business description and target audience"\n      },\n      {\n        "raw_text": "my product avg price point is 2000-4000 tk.",\n        "topic_hint": "pricing"\n      },\n      {\n        "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team.",\n        "topic_hint": "business resources and budget"\n      },\n      {\n        "raw_text": "my products are coming from a supplier who is already successfully selling his this iteams on facebook... i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",\n        "topic_hint": "business model and supplier agreement"\n      },\n      {\n        "raw_text": "in ocean if a big boat come to catch fish that not mean others boat will not get any fishes... same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.",\n        "topic_hint": "market analysis and customer behavior"\n      },\n      {\n        "raw_text": "just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",\n        "topic_hint": "distribution plan"\n      }\n    ]\n  },\n  {\n    "qa_pairs": [],\n    "unprompted_context": [\n      {\n        "raw_text": "i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.",\n        "topic_hint": "pricing strategy and business goals"\n      },\n      {\n        "raw_text": "nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",\n        "topic_hint": "content creation and inventory status"\n      }\n    ]\n  }\n]\n',
                    },
                ],
                "output": {
                    "role": "ai",
                    "content": [
                        {
                            "type": "text",
                            "text": '{\n  "classification": "NEW_PROBLEM",\n  "problem": "Establish a sustainable pricing and incentive structure with the supplier that allows for competitive discounting without compromising the supplier\'s margin or the reseller\'s viability.",\n  "reason": "The advisor\'s strategy relies on offering discounts to acquire the first 100 customers, but the business model lacks a budget and depends entirely on the supplier\'s cooperation. The critic correctly identifies that the feasibility of this incentive depends on the supplier\'s willingness to absorb costs, which is a distinct business constraint that must be resolved before the incentive strategy can be implemented."\n}',
                            "extras": {
                                "signature": "EnAKbgERTTIPascJoy+YVsXAw1ssBgzAjMUZ6opnAak/aC6+9znTiK9JdKUPkfcTXXBMlfJLP1w1sivCCVmtUInQ/Y83EHJc+fVvEznl++x7tLqT5yfjTieX6Kthcyx/TKKFXhaK3yO2xQIEsz+WvRrk"
                            },
                        }
                    ],
                },
                "status": "SUCCESS",
            },
        ]

        st.session_state.verified_facts = [
            {
                "qa_pairs": [],
                "unprompted_context": [
                    {
                        "raw_text": "i want 100 first customers in my business",
                        "topic_hint": "business goal",
                    }
                ],
            },
            {
                "qa_pairs": [],
                "unprompted_context": [
                    {
                        "raw_text": "i want 100 first customers in my business",
                        "topic_hint": "business goal",
                    },
                    {
                        "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",
                        "topic_hint": "product and target audience",
                    },
                    {
                        "raw_text": "my product avg price point is 2000-4000 tk. and i already told you about typical buyers.",
                        "topic_hint": "pricing",
                    },
                    {
                        "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team. but my products are coming from a supplier who is already successfully selling his this iteams on facebook, that why i thought this products are running facebook that proven, i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                        "topic_hint": "business model and operations",
                    },
                ],
            },
            {
                "qa_pairs": [],
                "unprompted_context": [
                    {
                        "raw_text": "i am selling product, this is home decorating showpieces products. and my ideal customers are Bangladeshi woman's, who want to buy showpieces to improve their how more then before to show in front of other people to feel more organized and respectful.",
                        "topic_hint": "business description and target audience",
                    },
                    {
                        "raw_text": "my product avg price point is 2000-4000 tk.",
                        "topic_hint": "pricing",
                    },
                    {
                        "raw_text": "right now i dont have any heavy network and also i have 0 budget to invest here and i am solo seller no team.",
                        "topic_hint": "business resources and budget",
                    },
                    {
                        "raw_text": "my products are coming from a supplier who is already successfully selling his this iteams on facebook... i collaborate with supplier, the deal is my task is selling this products by facebook if i make sell you will handle everything from packaging to shiping and my customers are always will pay you in cod (cash on dalivery) and he is agree with this deal and i said i will use your reels, because in facebook he just upload everyday 2-3 reels and he have right now over 50k followers",
                        "topic_hint": "business model and supplier agreement",
                    },
                    {
                        "raw_text": "in ocean if a big boat come to catch fish that not mean others boat will not get any fishes... same facebook has that much customers that no one can grave all the customers so some customers also come to the smaller one. and one thing more need to clear you in facebook people dont buy when they see it first time before they buy they want to see it 7-12 times then they from the 12 guy, also not in first glance from the 12 guy, she or the customer will message 5 more defferent customers then she will buy from lowest price given seller.",
                        "topic_hint": "market analysis and customer behavior",
                    },
                    {
                        "raw_text": "just posting this reels by changing their background music is first step, but if you ask about what is my distribution plan, then honestly i have no plan right now, because i already try sheing on groups they dont work well they just get some random views no reaction and commet or message.",
                        "topic_hint": "distribution plan",
                    },
                ],
            },
            {
                "qa_pairs": [],
                "unprompted_context": [
                    {
                        "raw_text": "i have authority to set my own price but i dont want to incrise price because my goal is not profit right now, that more about geting first 100 customers.",
                        "topic_hint": "pricing strategy and business goals",
                    },
                    {
                        "raw_text": "nah i cant create my own photos because i dont have physical products, right now i am 100% dependet on supplier reels",
                        "topic_hint": "content creation and inventory status",
                    },
                ],
            },
        ]

        st.session_state.critic_results = []

        st.session_state.runtime = 0

        st.session_state.auto_runtime = 0

        st.session_state.problem_stack = []

        st.session_state.current_problem_index = 0

        st.session_state.critic_id_counter = 0

        st.session_state.critic_records = []

        st.session_state.active_critics = []

        st.rerun()
